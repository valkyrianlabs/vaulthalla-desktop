// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The WebAssembly reader in Node, through reader.ts only: the module's surface (read only, the imports it needs),
// every golden vector of VHF1 (positive, negative, ranged), the manifest (objects, negative, chain rules), KEV1, the
// recovery seed and object keys, then the end to end read of a vault the native library built
// (tests/reader_fixture.hpp, committed as fixture.json): head selection, tree, a file's bytes, a ranged read, a
// tampered chunk refused, a root from another vault refused, a stale root detected against the anchor.
//   node --test wasm/tests/reader.test.ts              the committed artifact
//   VF_WASM=/path/to/build.wasm node --test ...         another build of it
import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { EXPORTED, KIND_FILE_CONTENT, KIND_MANIFEST_ROOT, KIND_MANIFEST_SEGMENT, HEADER_SIZE, Reader, VaultfmtError } from "../reader.ts";
import type { Expectation, Keyring, Opener } from "../reader.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.join(here, "..", "..");
const wasmPath = process.env.VF_WASM ?? path.join(here, "..", "vl-vaultfmt-reader.wasm");
const wasm = fs.readFileSync(wasmPath);
const V = JSON.parse(fs.readFileSync(path.join(repo, "vectors", "vectors.json"), "utf8"));
const F = JSON.parse(fs.readFileSync(path.join(here, "fixture.json"), "utf8"));
const r = await Reader.instantiate(wasm);

const hex = (s: string) => Uint8Array.from(Buffer.from(s, "hex"));
const toHex = (b: Uint8Array) => Buffer.from(b).toString("hex");
const sha256 = (b: Uint8Array) => createHash("sha256").update(b).digest("hex");
const concat = (parts: Uint8Array[]) => Uint8Array.from(Buffer.concat(parts));
const code = (f: () => unknown): string => {
  try {
    f();
  } catch (e) {
    if (e instanceof VaultfmtError) return e.code;
    throw e;
  }
  return "ok";
};

function ring(held: number[] = []): Keyring {
  const k = r.keyring();
  for (const [v, key] of Object.entries(V.conventions.keys as Record<string, string>))
    if (!held.length || held.includes(Number(v))) k.add(Number(v), hex(key));
  return k;
}

function expectOf(params: Record<string, unknown>, override: Record<string, unknown> = {}): Expectation {
  return {
    kind: (override.kind ?? params.kind ?? 1) as number,
    vault_uid: hex((override.vault_uid_hex ?? params.vault_uid_hex) as string),
    object_uid: hex((override.object_uid_hex ?? params.object_uid_hex) as string),
  };
}

// Opens `object` as a stream in pseudo-random splits; the first failure's code, and the plaintext received.
function stream(object: Uint8Array, e: Expectation, held: number[], seed: number): { code: string; plaintext: Uint8Array } {
  const k = ring(held);
  const parts: Uint8Array[] = [];
  let o: Opener | null = null;
  try {
    const c = code(() => {
      o = r.openObject(object.subarray(0, HEADER_SIZE), e, k, BigInt(object.length));
      let x = seed * 7919 + 1;
      for (let at = HEADER_SIZE; at < object.length;) {
        x = (x * 1103515245 + 12345) % 2147483648;
        const n = Math.min(object.length - at, 1 + (x % 3000));
        parts.push((o as Opener).update(object.subarray(at, at + n)));
        at += n;
      }
      (o as Opener).finish();
    });
    return { code: c, plaintext: concat(parts) };
  } finally {
    (o as Opener | null)?.free();
    k.free();
  }
}

const positive = (name: string) => V.vhf1.positive.find((v: { name: string }) => v.name === name);
const manifestObject = (name: string) => V.manifest.objects.find((v: { name: string }) => v.name === name);
const vectorVault = hex(positive("empty").params.vault_uid_hex);

test("the module is the read-only reader, with the imports the binding supplies", () => {
  const m = new WebAssembly.Module(wasm);
  const exports = WebAssembly.Module.exports(m).map((e) => e.name);
  for (const name of EXPORTED) assert.ok(exports.includes(name), name);
  assert.deepEqual(exports.filter((n) => /seal|publish|delete|remove|put/i.test(n)), []);
  const imports = WebAssembly.Module.imports(m).map((i) => `${i.module}.${i.name}`).sort();
  for (const i of imports) assert.match(i, /^(wasi_snapshot_preview1\.(random_get|clock_time_get|environ_sizes_get|environ_get|fd_write|fd_read|fd_close|fd_seek|proc_exit)|env\.(emscripten_notify_memory_growth|__syscall_(get(e)?(u|g)id32|getdents64)))$/);
  const meson = fs.readFileSync(path.join(repo, "meson.build"), "utf8").match(/^ {2}version: '([0-9.]+)',$/m);
  assert.equal(r.version(), meson?.[1]);
  assert.equal(r.statusName(116), "vhf1_chunk_auth_failed");
  assert.equal(r.statusName(500), "reader_need_objects");
  assert.equal(r.statusName(-1), "unknown");
});

test("every VHF1 positive vector opens as a stream in any split", () => {
  let opened = 0;
  for (const v of V.vhf1.positive) {
    if (!v.object_hex) continue;
    for (let seed = 0; seed < 3; seed++) {
      const got = stream(hex(v.object_hex), expectOf(v.params), [], seed);
      assert.equal(got.code, "ok", v.name);
      assert.equal(toHex(got.plaintext), v.plaintext_hex, v.name);
    }
    opened++;
  }
  assert.ok(opened >= 6);
});

test("every VHF1 negative vector fails with its status", () => {
  assert.ok(V.vhf1.negative.length >= 19);
  for (const n of V.vhf1.negative) {
    const base = positive(n.base);
    const held = (n.expect_override?.keys ?? []) as number[];
    const got = stream(hex(n.object_hex), expectOf(base.params, n.expect_override ?? {}), held, 1);
    assert.equal(got.code, `vhf1_${n.expect.error}`, n.name);
  }
});

test("every range vector plans and reads authenticated chunks only", () => {
  for (const v of V.vhf1.range_reads) {
    const base = positive(v.object);
    const object = hex(base.object_hex);
    const k = ring();
    const o = r.openObject(object.subarray(0, HEADER_SIZE), expectOf(base.params), k, BigInt(object.length));
    const plan = o.rangePlan(BigInt(v.start), BigInt(v.end));
    if (v.object_range === null) assert.equal(plan.length, 0n);
    else assert.deepEqual([plan.offset, plan.offset + plan.length], v.object_range.map(BigInt));
    const window = object.subarray(Number(plan.offset), Number(plan.offset + plan.length));
    assert.equal(toHex(o.rangeRead(BigInt(v.start), BigInt(v.end), BigInt(object.length), window)), v.plaintext_hex);
    assert.equal(code(() => o.rangeRead(BigInt(v.start), BigInt(v.end), BigInt(object.length - 1), window)), "vhf1_size_mismatch");
    o.free();
    k.free();
  }
  // range_without_size can't be expressed through the C API: an opener always carries the object's size.
  const skipped = V.vhf1.range_negative.filter((n: { expected_object_size: number | null }) => n.expected_object_size === null);
  assert.deepEqual(skipped.map((n: { name: string }) => n.name), ["range_without_size"]);
  for (const n of V.vhf1.range_negative) {
    if (n.expected_object_size === null) continue;
    const base = positive("multi_chunk");
    const object = hex(n.object_hex);
    const k = ring();
    const o = r.openObject(object.subarray(0, HEADER_SIZE), expectOf(base.params), k, BigInt(n.expected_object_size));
    const got = code(() => {
      const plan = o.rangePlan(BigInt(n.start), BigInt(n.end));
      const window = object.subarray(Number(plan.offset), Number(plan.offset + plan.length));
      const plain = o.rangeRead(BigInt(n.start), BigInt(n.end), BigInt(object.length), window);
      if (n.expect.ok) assert.equal(toHex(plain), n.plaintext_hex, n.name);
    });
    assert.equal(got, n.expect.ok ? "ok" : `vhf1_${n.expect.error}`, n.name);
    o.free();
    k.free();
  }
});

test("every manifest object opens only as its kind, and the negative is refused", () => {
  for (const m of V.manifest.objects) {
    const object = hex(m.object_hex);
    if (m.kind === KIND_MANIFEST_ROOT) {
      const k = ring();
      const root = r.openRoot(object, vectorVault, k);
      assert.ok(root.info().epoch >= 1n, m.name);
      root.free();
      k.free();
      assert.equal(code(() => r.openRoot(object, vectorVault, ring([999]))), "vhf1_key_unavailable");
    }
    const e = { kind: m.kind, vault_uid: vectorVault, object_uid: hex(m.object_uid_hex) };
    const got = stream(object, e, [], 2);
    assert.equal(got.code, "ok", m.name);
    assert.equal(Buffer.from(got.plaintext).toString("utf8"), m.plaintext_utf8, m.name);
    assert.equal(stream(object, { ...e, kind: m.kind === KIND_MANIFEST_SEGMENT ? KIND_FILE_CONTENT : KIND_MANIFEST_SEGMENT }, [], 0).code,
                 "vhf1_kind_mismatch");
  }
  for (const n of V.manifest.negative) {
    const object = hex(n.object_hex);
    const k = ring();
    if (n.expect_kind === KIND_MANIFEST_ROOT) assert.equal(code(() => r.openRoot(object, vectorVault, k)), `vhf1_${n.expect.error}`);
    else assert.equal(stream(object, { kind: n.expect_kind, vault_uid: vectorVault, object_uid: hex(n.expect_object_uid_hex) }, [], 0).code,
                      `vhf1_${n.expect.error}`);
    k.free();
  }
});

test("every manifest chain case through the root and the tree", () => {
  const seg = manifestObject("segment_1");
  const segSid = (seg.object_key as string).split("/").pop() as string;
  let built = 0;
  for (const c of V.manifest.chain) {
    const rootBytes = c.root_hex ? hex(c.root_hex) : hex(manifestObject(c.root).object_hex);
    const k = ring();
    let root;
    try {
      root = r.openRoot(rootBytes, vectorVault, k, c.known);
    } catch (e) {
      assert.ok(e instanceof VaultfmtError, c.name);
      assert.equal(e.code, `chain_${c.expect.error}`, c.name);
      k.free();
      continue;
    }
    const objects = new Map<string, Uint8Array>(c.segments_override
      ? Object.entries(c.segments_override as Record<string, string>).map(([sid, h]) => [sid, hex(h)])
      : [[segSid, hex(seg.object_hex)]]);
    for (const ref of root.objects()) assert.equal(ref.key, `.vaulthalla/seg/${ref.sid}`);
    const got = code(() => {
      const tree = root.tree(objects, k);
      const info = root.info();
      assert.equal(info.epoch, BigInt(c.expect.epoch));
      assert.equal(info.root_sha256, c.expect.root_sha256);
      assert.equal(info.gap, "warning" in c.expect);
      assert.ok(tree.entries().length > 0);
      tree.free();
      built++;
    });
    assert.equal(got, c.expect.error ? `chain_${c.expect.error}` : "ok", c.name);
    root.free();
    k.free();
  }
  assert.ok(built >= 3);
});

test("every KEV1 vector through the recipient handle, the key checked by what it opens", () => {
  for (const v of V.kev1.positive) {
    const rcp = r.recipientFromSecret(v.suite, hex(v.recipient_sk_hex));
    assert.equal(toHex(rcp.id()), v.recipient_id_hex);
    const k = r.keyring();
    assert.equal(k.addEnvelope(rcp, hex(v.vault_uid_hex), hex(v.envelope_hex)), v.key_version, v.name);
    // The vectors' vault keys are the VHF1 vectors' keys of the same version: an object sealed under it opens.
    const object = V.vhf1.positive.find((p: { object_hex?: string; params: { key_version: number } }) =>
      p.object_hex && p.params.key_version === v.key_version);
    const o = r.openObject(hex(object.object_hex).subarray(0, HEADER_SIZE), expectOf(object.params), k,
                           BigInt(object.object_hex.length / 2));
    o.free();
    k.free();
    rcp.free();
  }
  for (const v of V.kev1.negative) {
    const rcp = r.recipientFromSecret(v.suite_expected, hex(v.recipient_sk_hex));
    const k = r.keyring();
    assert.equal(code(() => k.addEnvelope(rcp, hex(v.vault_uid_hex), hex(v.envelope_hex))), `kev1_${v.expect.error}`, v.name);
    k.free();
    rcp.free();
  }
  assert.equal(code(() => r.recipientFromSecret(3, new Uint8Array(32))), "invalid_argument");
});

test("every recovery seed vector as the account key, and the object keys", () => {
  for (const v of V.recovery_seed.positive) {
    const rcp = r.recipientFromSeed(v.seed_text);
    assert.equal(toHex(rcp.id()), v.recipient_id_hex);
    rcp.free();
  }
  for (const v of V.recovery_seed.negative) assert.equal(code(() => r.recipientFromSeed(v.seed_text)), `seed_${v.error}`);
  for (const v of V.object_ids.encode) {
    assert.equal(r.contentKey(hex(v.uid_hex)), v.content_key);
    assert.equal(toHex(r.contentKeyUid(v.content_key) as Uint8Array), v.uid_hex);
  }
  for (const v of V.object_ids.decode_negative) assert.equal(r.contentKeyUid(`o/${v.text}`), null, v.why);
});

// ---- the vault the native library built --------------------------------------------------------------------------

const vault = hex(F.vault_uid_hex);
const rootsById = new Map<string, Uint8Array>(F.roots.filter((x: { delete_marker: boolean }) => !x.delete_marker)
  .map((x: { version_id: string; hex: string }) => [x.version_id, hex(x.hex)]));
const pattern = (seed: number, size: number) => {
  const b = new Uint8Array(size);
  for (let i = 0; i < size; i++) b[i] = (i * 31 + seed * 7 + (i >> 8)) & 0xff;
  return b;
};

function accountRing(): Keyring {
  const k = r.keyring();
  const account = r.recipientFromSeed(F.seed_text);
  assert.equal(code(() => k.addEnvelope(account, vault, hex(F.decoy_envelope_hex))), "kev1_recipient_mismatch");
  assert.equal(k.addEnvelope(account, vault, hex(F.envelope_hex)), F.key_version);
  account.free();
  return k;
}

// A page's head choice: supply what is needed, decide, again while more is needed.
function choose(listing: unknown, anchor: { epoch: number; root_sha256: string; version_id?: string | null } | null, k: Keyring) {
  const h = r.head(vault, listing as string, anchor);
  for (let round = 0; round < 3; round++) {
    for (const id of h.needed()) h.supply(id, rootsById.get(id) as Uint8Array);
    if (h.decide(k)) return h;
  }
  throw new Error("undecided");
}

test("end to end: the head, with and without an anchor, a stale root and another vault's root", () => {
  const k = accountRing();
  // No anchor: every version needed, epoch 3, freshness unverified, the sibling ignored as a stray.
  const h = r.head(vault, F.listing);
  assert.equal(h.needed().length, F.roots.length);
  assert.equal(h.decide(k), false);
  for (const id of h.needed()) h.supply(id, rootsById.get(id) as Uint8Array);
  assert.deepEqual(h.needed(), []);
  assert.equal(h.decide(k), true);
  const d = h.decision();
  assert.equal(d.epoch, 3);
  assert.equal(d.version_id, F.epochs["3"].version_id);
  assert.equal(d.root_sha256, F.epochs["3"].root_sha256);
  assert.equal(d.freshness, "unverified");
  assert.equal(d.gap, false);
  assert.deepEqual(d.strays, [F.sibling_version]);
  assert.deepEqual(d.anchor, { epoch: 3, root_sha256: F.epochs["3"].root_sha256, version_id: F.epochs["3"].version_id });
  h.free();

  // Anchored at epoch 2: only versions from it on, verified.
  const anchor2 = { epoch: 2, ...F.epochs["2"] };
  const h2 = r.head(vault, F.listing, anchor2);
  assert.equal(h2.needed().length, F.roots.length - 1);
  assert.ok(!h2.needed().includes(F.epochs["1"].version_id));
  h2.free();
  const h3 = choose(F.listing, anchor2, k);
  assert.equal(h3.decision().freshness, "verified");
  assert.equal(h3.decision().epoch, 3);
  h3.free();

  // Stale: the bucket hides epoch 3 from a reader anchored there.
  const hidden = F.listing.filter((v: { version_id: string }) => v.version_id !== F.epochs["3"].version_id && v.version_id !== F.sibling_version);
  assert.equal(code(() => choose(hidden, { epoch: 3, root_sha256: F.epochs["3"].root_sha256 }, k)), "chain_rollback");

  // Another vault's root: not this vault's, so no head; and refused when opened directly.
  const other = r.head(vault, [{ version_id: "other-1" }]);
  other.supply("other-1", hex(F.other_root_hex));
  assert.equal(code(() => other.decide(k)), "reader_no_usable_root");
  other.free();
  assert.equal(code(() => r.openRoot(hex(F.other_root_hex), vault, k)), "vhf1_vault_mismatch");
  k.free();
});

test("end to end: the tree, listing and stat, a file's bytes, a ranged read, a tampered chunk", () => {
  const k = accountRing();
  const h = choose(F.listing, { epoch: 2, ...F.epochs["2"] }, k);
  const root = h.root(k);
  const objects = new Map<string, Uint8Array>();
  for (const ref of root.objects()) {
    const bytes = hex(F.segments[ref.sid]);
    assert.equal(sha256(bytes), ref.object_sha256);
    objects.set(ref.sid, bytes);
  }
  assert.ok(objects.size >= 2);
  const [first] = objects.keys();
  const missing = new Map(objects);
  missing.delete(first);
  assert.equal(code(() => root.tree(missing, k)), "chain_segment_missing");
  const swapped = new Map(objects);
  swapped.set(first, objects.get([...objects.keys()][1]) as Uint8Array);
  assert.equal(code(() => root.tree(swapped, k)), "chain_segment_mismatch");
  const tree = root.tree(objects, k);

  const top = tree.list(null);
  assert.equal(top.length, 1);
  assert.deepEqual(tree.list(top[0].uid).map((e) => e.name).sort(), ["docs", "notes.txt"]);
  const report = F.files[0];
  const st = tree.stat(report.uid);
  assert.equal(st?.name, "report.bin");
  assert.equal(st?.size, report.size);
  assert.equal(tree.stat("nope"), null);

  for (const f of F.files) {
    const object = hex(f.object_hex);
    const o = tree.openContent(vault, f.uid, object.subarray(0, HEADER_SIZE), k);
    assert.equal(o.info().plaintext_size, BigInt(f.size));
    const plain = concat([o.update(object.subarray(HEADER_SIZE))]);
    o.finish();
    assert.deepEqual(plain, pattern(f.pattern, f.size), f.name);
    o.free();
  }

  const ranged = (object: Uint8Array, start: number, end: number) => {
    const o = tree.openContent(vault, report.uid, object.subarray(0, HEADER_SIZE), k);
    try {
      const p = o.rangePlan(BigInt(start), BigInt(end));
      return o.rangeRead(BigInt(start), BigInt(end), BigInt(object.length),
                         object.subarray(Number(p.offset), Number(p.offset + p.length)));
    } finally {
      o.free();
    }
  };
  const reportObject = hex(report.object_hex);
  assert.deepEqual(ranged(reportObject, 3000, 9000), pattern(report.pattern, report.size).subarray(3000, 9000));
  const tampered = hex(F.tampered_hex);
  assert.equal(ranged(tampered, 0, 4096).length, 4096);
  assert.equal(code(() => ranged(tampered, 3000, 5000)), "vhf1_chunk_auth_failed");
  assert.equal(code(() => ranged(hex(F.files[2].object_hex), 0, 10)), "vhf1_object_mismatch");

  tree.free();
  root.free();
  h.free();
  k.free();
});

test("handles are released, and a freed one is refused", () => {
  const k = r.keyring();
  k.free();
  assert.equal(code(() => k.add(1, new Uint8Array(32))), "unusable");
  k.free();
});
