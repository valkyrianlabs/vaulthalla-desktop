#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 Valkyrian Labs LLC
#
# Builds the WebAssembly reader, wasm/vl-vaultfmt-reader.wasm, reproducibly: the pinned Emscripten image (by digest),
# OpenSSL and nlohmann_json from pinned, checksum-verified release tarballs, vl-keykit from its committed tarball, and
# this checkout; then compares the result with the committed artifact and wasm/vl-vaultfmt-reader.wasm.sha256.
#   wasm/build.sh            build and compare (exit 1 when the bytes differ)
#   wasm/build.sh --record   build and record the artifact and its checksum (after a deliberate change)
#   wasm/build.sh --out DIR  build into DIR only (measurements; VF_OPT, VF_LTO, VF_MALLOC, VF_RUNTIME, VF_NAMES)
#   wasm/build.sh --test     run the Node tests (wasm/tests) against the committed artifact, with the image's Node
# Needs podman (or docker) and, the first time, the network for the image and the two tarballs (cached in
# wasm/.cache/, verified on every use); the build itself runs with --network=none. VF_JOBS caps parallelism (6).
set -euo pipefail
cd "$(dirname "$0")/.."

# Emscripten 6.0.13 (clang 24, Node 24.19 inside), the multi-architecture image list: amd64 and arm64 hosts pull
# their own variant of the same release.
image=docker.io/emscripten/emsdk@sha256:fb7864e398acfda863dfcea78b8bc8adad359fa60c6a0bbeb845931de64aa68a
# OpenSSL 3.5 LTS (supported to 2030-04-08); its release signature was checked against the OpenSSL project key
# B146 647E 45A7 B339 47AB 226B 2A2C 87D1 6169 2D40 when this pin was taken.
openssl_version=3.5.9
openssl_sha256=603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a
openssl_url=https://github.com/openssl/openssl/releases/download/openssl-$openssl_version/openssl-$openssl_version.tar.gz
# nlohmann_json 3.11.3 (the version Ubuntu 24.04 and the native CI image carry), its release's json.tar.xz.
json_version=3.11.3
json_sha256=d6c65aca6b1ed68e7a182f4757257b107ae403032760ed6ef121c9d55e81757d
json_url=https://github.com/nlohmann/json/releases/download/v$json_version/json.tar.xz

artifact=wasm/vl-vaultfmt-reader.wasm
sumfile=wasm/vl-vaultfmt-reader.wasm.sha256
mode=compare
out=""
case "${1:-}" in
  --record) mode=record ;;
  --out) mode=out; out=$(mkdir -p "$2" && cd "$2" && pwd) ;;
  --test) mode=test ;;
  "") ;;
  *) echo "usage: wasm/build.sh [--record | --out DIR]" >&2; exit 2 ;;
esac

runtime=$(command -v podman || command -v docker) || { echo "needs podman or docker" >&2; exit 1; }
if [[ "$mode" == test ]]; then
  "$runtime" image exists "$image" 2>/dev/null || "$runtime" pull -q "$image" > /dev/null
  exec "$runtime" run --rm --network=none -v "$PWD:/src:ro" -w /src/wasm "$image" node --test tests/reader.test.ts
fi

sha256() { (sha256sum "$1" 2>/dev/null || shasum -a 256 "$1") | cut -d' ' -f1; }
cache=wasm/.cache
mkdir -p "$cache"
fetch() {   # url file sha256
  if [[ ! -f "$cache/$2" || "$(sha256 "$cache/$2")" != "$3" ]]; then
    curl -fsSL --retry 3 -o "$cache/$2.part" "$1"
    mv "$cache/$2.part" "$cache/$2"
  fi
  [[ "$(sha256 "$cache/$2")" == "$3" ]] || { echo "$2: checksum mismatch" >&2; rm -f "$cache/$2"; exit 1; }
}
fetch "$openssl_url" "openssl-$openssl_version.tar.gz" "$openssl_sha256"
fetch "$json_url" "json-$json_version.tar.xz" "$json_sha256"

"$runtime" image exists "$image" 2>/dev/null || "$runtime" pull -q "$image" > /dev/null
[[ -n "$out" ]] || out=$(mktemp -d)
"$runtime" run --rm --network=none \
  -v "$PWD:/src:ro" -v "$PWD/$cache:/cache:ro" -v "$out:/out" \
  -e VF_JOBS="${VF_JOBS:-6}" -e VF_OPT -e VF_LTO -e VF_MALLOC -e VF_RUNTIME -e VF_NAMES \
  -e VF_OPENSSL_VERSION="$openssl_version" -e VF_JSON_VERSION="$json_version" \
  "$image" bash /src/wasm/build-in-container.sh
cat "$out/sizes.txt"

case "$mode" in
  out) echo "built into $out" ;;
  record)
    cp "$out/vl-vaultfmt-reader.wasm" "$artifact"
    echo "$(sha256 "$artifact")  vl-vaultfmt-reader.wasm" > "$sumfile"
    echo "recorded $(cut -d' ' -f1 "$sumfile") ($(wc -c < "$artifact" | tr -d ' ') bytes)"
    rm -rf "$out" ;;
  compare)
    sum=$(sha256 "$out/vl-vaultfmt-reader.wasm")
    want=$(cut -d' ' -f1 "$sumfile")
    rm -rf "$out"
    [[ "$sum" == "$want" ]] || { echo "rebuilt $sum, recorded $want: not reproducible, or not the committed artifact" >&2; exit 1; }
    [[ "$(sha256 "$artifact")" == "$want" ]] || { echo "$artifact differs from $sumfile" >&2; exit 1; }
    echo "reproduced $sum" ;;
esac
