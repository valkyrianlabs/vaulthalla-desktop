# Golden vectors

`vectors.json` and `vh_crypto_vectors.py` are **verbatim copies** of vaulthalla-server's `design/encryption/vectors/`
(main at fc636330, v1.22.2), byte-identical with vl-keykit's copy as well, so every implementation of these formats is
checked against one file:

- **this library** (C++): the `vhf1` and `manifest` sections (`tests/test_vhf1.cpp`, `tests/test_manifest.cpp`,
  `tests/test_c_api.cpp`; `tests/vectors_contract.py` keeps them consuming every section);
- **vaulthalla-server**: its copy, checked identical through the `vectors_dir` variable of `vl_vaultfmt_dep`
  (`core/tests/unit/test_vaultfmt_vectors.cpp`), as it checks vl-keykit's;
- **vl-keykit**: the `kev1`, `recovery_seed` and `object_ids` sections;
- **Vaulthalla Desktop** (Swift): the same file.

The normative text is vaulthalla-server's `design/encryption/02-authenticated-file-format.md` (VHF1) and
`03-metadata-recovery.md` (the manifest). The `vhf1` and `manifest` sections live with this code (design decision 2):
a change to them lands here with the code, in one change with the spec, and is copied to vaulthalla-server and
vl-keykit, whose identical-copy tests fail until it is. It needs an independent check: `python3 vh_crypto_vectors.py
--check` regenerates the file, compares it byte for byte and runs its separate reader. Never "regenerate to green".
`meson test` runs the `--check` as `vectors-reference` where Python's `cryptography` package is installed (CI always).

`writer_floor.json` and `writer_floor_vectors.py` are this library's own (not part of the verbatim copy, which they
leave unchanged): roots carrying the manifest root's `writer_floor` member, sealed with the reference sealer above, and
the floor's decision table (`docs/engine.md`, "The writer floor"). `python3 writer_floor_vectors.py --check`
regenerates and checks them (`meson test`: `writer-floor-reference`); `tests/test_writer_floor.cpp` consumes them.
