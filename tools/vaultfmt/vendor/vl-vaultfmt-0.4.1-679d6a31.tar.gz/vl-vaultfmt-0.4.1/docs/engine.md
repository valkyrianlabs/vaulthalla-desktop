# The database-free engine

`vl::vaultfmt::engine` keeps one opaque_v1 vault in its bucket with no server and no database: what Vaulthalla
Desktop runs for a Desktop-only vault (vaulthalla-server `design/core/vault-format-library.md`, work item 9 and the
library half of item 12). The bucket is the database. What a server keeps in PostgreSQL the engine keeps in one state
blob per vault; everything else is the server's own code: `manifest::Session` publishes (both modes), verifies,
refuses, repairs and collects garbage; `manifest::reconcile` and `applyPlan` take another writer's root in by the
server applier's rules; the reader's `load`, base copy and blind rebuild open a vault.

| Header | What |
| --- | --- |
| `engine/Session.hpp` | `engine::Session`: open, the operations, refresh, publish, GC, status |
| `engine/State.hpp` | `StateBlob` (the seam), `FileStateBlob` (the reference file), `StateFile` (the format below; the manifest's `StateStore`) |
| `engine/Store.hpp` | `BucketStore`: the manifest's `ObjectStore` plus streamed content (`putContent`, `getContent` by version) |
| `vl_vaultfmt_engine.h` | the C API over all of it (store, keys and state callback tables) |
| `testing/engine_store.hpp` | `MemoryBucketStore`, `HookedBucketStore`, `MemoryStateBlob` |

## What the engine keeps

The design's table, as built:

| Fact | Server (PostgreSQL) | Engine (the state blob) |
| --- | --- | --- |
| Chain position: epoch, root hash, ETag, root and base version ids, settle window, own epoch | `remote_manifest_state` | `chain` |
| A refused root (reason, epoch, hash, time) | `remote_manifest_state.refused_*` | `chain.refused_*` |
| Sids of the last three roots; when a sid became unreferenced; last GC | `remote_manifest_root`, `remote_manifest_gc`, `gc_at` | `roots`, `gc`, `chain.gc_at` |
| What the last publish produced (the base of pending changes) | `remote_manifest_base` + `base_root` (migration 145) | `base_root` + `objects`: the sealed bytes of the recorded root and the segments it names |
| Roots PUT and not recorded, and the pending root's base copy | `publishing_roots`, `remote_manifest_pending` (146, 147) | `chain.publishing_roots`, `pending`, `objects` |
| An apply in progress | `applying_*` | not needed: an apply is one save (below) |
| The tree, versions, trash, key history, vault settings | `files`, `directories`, `files_trashed`, `upstream_object_version`, keys | `working`: the last settled content plus every local change since |
| The change journal clients read | `fs_change_log` | `revision`, `generation`, `changes`, `changes_floor` |
| Objects to delete after a purge | the purge's own DELETE | `purges`, deleted once a root without them settled |

"The last settled content plus a journal of local operations": the working content is a snapshot plus the journal
records appended after it, and every operation appends one record before it returns. The base copy is the content of
the recorded root (what our last publish produced, or the root last applied), so a cold start merges on it, never on
the bucket's head (spec 06 §5.5).

## The state file

One blob per vault: `StateBlob::load` returns it whole, `save` replaces it atomically and durably, `append` adds bytes
durably (optional). `FileStateBlob` is one file in the File Provider extension's app group container: `save` writes
`<path>.tmp` (mode 0600), flushes it with `F_FULLFSYNC` (fsync where that is refused), renames it over `<path>` and
fsyncs the directory; `append` writes with `O_APPEND` and flushes the same way.

```
blob    = magic version record+
magic   = "VLVFSTAT"                       8 bytes
version = u32 big-endian                   1 (StateFile::kFormatVersion)
record  = length type payload hash
length  = u32 big-endian                   the payload's bytes
type    = u8                               1 snapshot (first, exactly once), 2 journal
payload = CBOR (RFC 8949)                  a map, below
hash    = 32 bytes                         SHA-256(length ‖ type ‖ payload)
```

The **snapshot** map:

| Member | Type | What |
| --- | --- | --- |
| `v` | uint | 1 |
| `writer_revision` | uint | the writer revision that wrote it (the writer floor, below) |
| `vault_uid` | text | base32; a blob of another vault is never read or overwritten (`state_other_vault`) |
| `node_id` | text | the installation that wrote it; another one's is refused the same way |
| `chain` | map | `ChainState` member for member (`epoch`, `root_sha256`, `etag`, `refused_reason`, `refused_epoch`, `refused_root_sha256`, `refused_at`, `gc_at`, `root_version_id`, `base_version_id`, `settle_window`, `own_epoch`, `applying_epoch`, `applying_root_sha256`, `publishing_roots`, `writers`, `writers_change` as `{add, node}`), null where absent |
| `base_root` | bytes or null | the recorded root's sealed bytes |
| `objects` | map sid → bytes | sealed segments and snapshot segments: the base copy's and the pending roots' |
| `pending` | map sha → bytes | sealed roots PUT and not recorded (each noted before its PUT) |
| `roots` | array of `{epoch, sha, sids}` | the last three recorded roots, newest first |
| `gc` | map sid → int | when the sid was first seen unreferenced (version_log GC) |
| `generation`, `revision`, `published_revision`, `changes_floor`, `seq` | uint | the change log's generation and revision; the revision the bucket holds; the oldest revision an anchor may name; the last journal record folded in |
| `changes` | map uid → [revision, gone] | the change log: one row per entry, removals bounded by `kMaxRemovedInLog` (4096) |
| `purges` | array of `{uid, key, versions, revision}` | objects to delete |
| `working` | map | the working content in the manifest's own codec: `root` (a root document carrying `vault`, `keys`, `recovery_policy` and `producer`, with a placeholder segment list), `entries` (segment entries), `snapshots` (snapshot documents) |

A **journal** record: `{seq, put: [segment entry], remove: [uid], purges: [...], meta?: root document, has_keys?,
has_vault?}`: entries added or replaced by uid, uids gone, and the key history or vault settings after the change.
`seq` is the snapshot's `seq` + 1, + 2, ...; replaying a record also advances the revision and the change log, so a
replay is the operation's own effect.

Reading: no blob is **Fresh** (re-anchor or create). A bad magic, a first record that is not a snapshot or fails its
hash or its decoding, is **Damaged**: the engine re-anchors from the bucket and saves a new state over it. A version
or writer revision above this engine's is `StateTooNew`, never read or overwritten. A last record cut short or failing
its hash is a **torn tail** (a crash during an append: its operation never returned) and is dropped; a bad record with
more bytes after it is **journal truncated** (reported: what followed it is dropped). Either way the blob is rewritten
as one snapshot before the next append, so appends always follow valid bytes.

Writing: an operation appends its record (`StateBlob::append`, durable before it returns) and then applies it in
memory; a failed append throws `StateFailed` and changes nothing. Every `compact_after` (256) records, and whenever the
chain moves (every `StateStore` call: `notePublishing`, `recordRoot`, `recordRefused`, ...), the whole state is saved
as one snapshot, built on a copy that replaces the in-memory state only once the save returned. A blob without
`append` saves on every change.

The blob holds names and the tree in plaintext, as the server's database does (the base copy is sealed): it belongs
in the app group container under the system's data protection. It holds no key.

## Invariants

1. **A returned operation is durable**, and one that threw left no trace in memory or on disk.
2. **The working content is always at a root**: it is the recorded root's content plus local changes. The recorded
   root advances only by our own publish (`recordRoot`, own) or by an apply, which writes the new working content and
   the new record in one save, so no partial apply exists and none can be published.
3. **Nothing is published over** a refused root (until the chain moves on), a head this engine has not applied
   (`HeadMoved`: it refreshes first, at most `publish_rounds` times), or a root above its writer revision.
4. **A root is noted before its PUT** (`notePublishing`: its hash and pending base copy), so after any crash the root
   in the bucket is recognized as ours (adopted, never reconciled) and, when another writer built on it, used as the
   base of the apply (`Session::adoptBuiltOn`).
5. **Envelopes before keys**: a key version is recorded only after every envelope of it is in the bucket, and nothing
   is sealed under a version the working content doesn't list (`key_not_added`).
6. **Objects before names**: a file's version is recorded only after its upload finished; a purge deletes objects
   only after a root without the file settled, and only while this installation is the vault's only writer.
7. **Plaintext only from authenticated chunks**: reads go through `vhf1::RangeReader` with the generation and size the
   entry names, by the version it names.

## Guarantees and the tests that prove them

| Guarantee | Test (tests/) |
| --- | --- |
| An operation that returned survives a crash; one whose journal write failed or tore never happened | `EngineDurability.AnOperationThatReturnedSurvivesACrashAndOneThatThrewNeverHappened` |
| A lost Mac loses at most the names of unpublished changes: published names stay, unpublished file bytes come back under `/Recovered`, every key version's envelope is in the bucket (decision 8) | `EngineDurability.ALostMacLosesAtMostTheNamesOfUnpublishedChanges` |
| A damaged state re-anchors from the bucket; a state of another vault is refused | `EngineDurability.ADamagedStateReanchorsFromTheBucket` |
| A crash between a root's PUT and its record: adopted, nothing lost | `EngineCrash.BetweenARootsPutAndItsRecordTheRootIsAdoptedAndNothingIsLost` |
| A PUT whose outcome was unknown landing late (before or after the next publish): adopted or repaired | `EngineCrashVersionLog.APutThatLandsLateIsAdoptedOrRepairedAndNothingIsLost` |
| The same PUT landing where Backblaze puts it, at its start (below roots listed and recorded since), in every position (before the retry is sealed, between the retry's PUT and its listing, after the retry won, after a crash before its record, after its record, after roots on it), with and without a restart: adopted or removed as a stray, never `order_violation`, never adopted over a recorded root, nothing lost | `EngineLateLander.AnOwnRootLandingBelowRecordedOnesIsAdoptedOrRemovedNeverRefused` |
| A second Mac can't join a version_log vault (`writers_refused`, nothing recorded); the library refuses such a root too | `EngineTwoMacsVersionLog.ASecondMacCantJoinAVersionLogVaultAndNothingIsRecorded` |
| Another writer building on our unrecorded root: that root is the apply's base, our later change survives | `EngineCrashTwoMacs.AnotherWriterBuildingOnOurUnrecordedRootIsTheBaseOfTheApply` |
| A crash before every request of a publish, then a restart: nothing lost, the bucket converges | `EngineCrash.ACrashBeforeEveryRequestOfAPublishLosesNothing` |
| Edit beats delete in both directions | `EngineTwoMacs.AnEditBeatsADeleteInBothDirections` |
| A two-sided content change keeps both generations (ours current, theirs a readable version) | `EngineTwoMacsVersioned.ATwoSidedContentChangeKeepsBothGenerations` |
| The head's placement wins; a lost round applies, then publishes | `EngineTwoMacs.TheHeadsPlacementWinsAndAPublishThatLosesARoundAppliesFirst` |
| Refresh costs one HEAD while nothing moved | `EngineOps.ARefreshCostsOneHeadWhileNothingMoved` |
| Only authenticated chunks reach a read's sink | `EngineOps.OnlyAuthenticatedChunksReachTheSink` |
| Envelopes are PUT before a key version is used; a key that isn't the keychain's is refused | `EngineOps.KeysAreAddedWithTheirEnvelopesBeforeAnythingIsSealedUnderThem` |
| A head above the engine's writer revision is neither applied nor published over; a newer state is never read | `EngineFloor.AHeadAboveTheEnginesRevisionIsNeitherAppliedNorPublishedOver` |
| The state format: journalling, compaction, checksums, versions, the server's StateStore rules | `EngineStateFile.*` |
| The whole lifecycle through the C API alone, compiled as C | `CEngine.AWholeVaultLifecycleThroughTheCApiAlone` (`c_engine_lifecycle.c`) |

Each test that names a mode runs on a version_log bucket and a conditional one; the version_log bucket is Backblaze as
measured live on 2026-11-16 (`MemoryBucket::provider(Backblaze)`: conditional PUTs refused, versions ordered by upload
start). Tests of two Macs run on conditional buckets only: several writers on a version_log bucket are refused.

## Operations

- **Tree.** `mkdir`, `rename`, `move` (no cycles, no moving the root), `trash` (files into the trash with their path;
  a trashed directory's directories and symlinks removed, and trash names its folder only while that folder is
  live, the collector's form), `restore` (where it was, else the vault root), `purge` (a trashed file, or a live
  entry with everything below it). Names are 1-255 bytes of UTF-8 without `/` or NUL, compared byte for byte.
- **Writes.** `writeBegin` seals a VHF1 kind 1 object under the current key with a fresh generation and streams it to
  `putContent`; `finish` records size, generation, key version, content hash (SHA-256 of the sealed bytes), the
  object's ETag and version id, and on a versioned bucket prepends the version to the entry's `versions` (the previous
  one marked noncurrent). A write whose file's generation changed since it began (an applied remote edit) or isn't the
  caller's expected one reports a conflict; both generations stay (ours current, theirs a version).
- **Reads.** By the entry's version id when it has one, in pieces of at most 4 MiB, each checked against the
  authenticated object size.
- **Refresh.** The server applier's order: verify (`manifest::Session::verifyRemote`: one HEAD, or on version_log a
  listing for 15 minutes after a publish whose root PUT failed (`kLateRootWatchSeconds`: a lost reply can still land,
  below the current root), chain rules, writers,
  mode, repair of strays), stop on an own root that isn't ours to adopt (`manifest_own_unexplained`), on the writer
  floor, and on a head that didn't load completely (`manifest_head_incomplete`); the base copy as base (or a union
  when there is none); `reconcile(base, head, working)`; stop on key problems; two-sided content changes keep theirs
  as a version; one save of the result and the record.
- **Publish.** Only with unpublished changes (or a root to rebuild, or a join to carry); `HeadMoved` refreshes and
  retries; then purges.
- **Re-anchor.** No state or a damaged one: the canonical head without an anchor (C1 on version_log), "freshness
  unverified" (`OpenReport::freshness`), and a blind rebuild that places every authentic object no entry names under
  `/Recovered/<uid>`. A key version the bucket's root doesn't list yet must be added again (`keyAdd`; its envelope is
  already there) before the engine seals anything under it.

## The writer floor (design decision 7)

**In the format.** The root member `writer_floor` (unsigned integer; absent = 0, omitted on output, so every existing
root re-encodes unchanged) is the lowest writer revision allowed to publish over that root. A writer's revision names
the members its own store round-trips; revision 1 (`kBaselineWriterRevision`) is spec 03's vocabulary as of
vl-vaultfmt 0.3.0. The rules (`vectors/writer_floor.json`, checked by `writer_floor_vectors.py --check` and
`WriterFloor*`):

- A writer below the floor of the head it would build on, or of the root it recorded, publishes nothing
  (`WriterFloorRefused`, before any PUT; a root rebuilt over a missing head keeps the recorded floor).
- It does not take such a head into a store it publishes from (`RemoteHead::above_floor`): reading it there would
  drop the members it doesn't know, and a later update would publish that loss. The engine refuses the apply
  (`writer_floor`, `Status::update_needed`) and keeps its local changes unpublished until it is updated.
- A writer writes `max(base floor, recorded floor, its own need)`: a writer that writes a member introduced in
  revision N needs N, and declares N only once its store keeps every member of N. Nobody lowers the floor.
- A state written by a higher revision is never read (`StateTooNew`).

Writers before 0.3.0 (revision 0, today's servers) don't know the member: the floor binds revision 1 and later, which
is why it lands before a second kind of writer exists.

**What vaulthalla-server must do** (no server change is part of this library change):

1. Take vl-vaultfmt 0.3.0 or later before any writer of revision 2 exists. Its `Session::publish` then refuses below
   the floor by itself (`SessionHost::writerRevision` defaults to 1, right for its collector today).
2. In `vault_manifest::Applier::apply` (or `Service::applyRemote`), stop when `RemoteHead::above_floor` is set, before
   reconcile, as for `manifest_key_missing`: an `ApplyStopped` with a new code (`manifest_writer_floor`), recorded and
   alerted once per root, telling the operator to update. Applying it would drop the members its database doesn't
   store, and its next publish after an update would carry that loss.
3. Catch `WriterFloorRefused` from `publish`/`publishIfChanged` as a stall with that alert, not a retry.
4. Raise `writerRevision` only together with the migration that stores a new revision's members.

## Durability (design decision 8)

The journal record of an operation is durable before the operation returns, and Desktop publishes soon after each
change. A lost Mac therefore loses: the names, folders, moves, renames and trash state of changes not yet published,
and the content of a write that had not finished uploading. It never loses: anything a published root names; the
bytes of any write that finished (an authentic object no root names is recovered under `/Recovered/<uid>`, without
its name); a key version (its envelopes are in the bucket before it seals anything, and Desktop holds the key in its
keychain and the recovery kit). `EngineDurability.ALostMacLosesAtMostTheNamesOfUnpublishedChanges` proves the bound.

## The C API

`vl_vaultfmt_engine.h`, one call per row of the design's table, with `vl_vaultfmt_` for `vlvf_`:
`vault_open` (`vault_options`, `open_info`), `vault_refresh`, `vault_list` / `vault_stat` / `vault_trash` /
`vault_changes` into a `listing`, `vault_read` (sink), `write_begin` / `write_chunk` / `write_finish`, `vault_mkdir` /
`vault_rename` / `vault_move` / `vault_trash_entry` / `vault_restore` / `vault_purge`, `vault_key_add`,
`vault_publish`, `vault_gc_if_due`, `vault_join`, `vault_status_get`, `vault_last_error`, the frees. Callbacks reply
through a `vl_vaultfmt_reply` (`reply_body`, `reply_etag`, `reply_version_id`, `reply_total`, `reply_listed`,
`reply_version`). Statuses 600-612 (store, state, publish, apply) and 621-632 (620 + the refusal; "not found" is the
shared code 6) have stable names through `vl_vaultfmt_status_name`. `vl_vaultfmt_file_state_*` gives a state table over the
reference file.

## Limits (not built here)

- **Several Macs** only on a bucket with conditional writes. On a version_log bucket (every Desktop-only vault)
  `join` is refused (`writers_refused`, 632) and so is any root naming more than one writer
  (`PublishOptions::version_log_writers`): Backblaze orders a key's versions by when their upload started (measured
  2026-11-16), so another writer's slow root can land below one this Mac settled, which nothing in the protocol makes
  safe yet (vaulthalla-server spec 06 §11 has the proposal). Opening the vault on another Mac without a join takes it
  over (its first root names that Mac alone; the old one stops as `superseded`). On a conditional bucket several Macs
  work through `join` (writers named, the base copy and adoption as on servers), but nothing here
  hands keys between installations or verifies another writer's envelope kids (the server checks each one before
  carrying it); purges never delete while another writer is named, and no orphan collection exists for them.
- **Recovery grants** (`recovery_policy`) are not written by the engine; Desktop's grants come with the account key
  (work item 12 on the Desktop side).
- **Snapshots** are carried as the root has them; the engine makes none.
- **Buckets without versions** (conditional, unversioned): a two-sided content change can keep only the bucket's
  current object. Desktop-only vaults are always version_log (decision 9).
- **The state is one blob**: a snapshot rewrites the base copy and working content (about the manifest's size), at
  each publish and every 256 changes.
