// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include "vl/vaultfmt/manifest/Store.hpp"

#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <vector>

// The bucket as the database-free engine needs it: the manifest's ObjectStore (whole objects up to
// kMaxManifestObjectBytes: the root, segments, envelopes, the layout hint) plus a streamed seam for content objects
// (o/<uid>), which are any size. Desktop implements both over URLSession with the short-lived access of the cloud's
// device grants (through the C API's store callback table); the tests over the in-memory bucket
// (vl/vaultfmt/testing/engine_store.hpp).
namespace vl::vaultfmt::engine {

// One streamed upload of a content object: its sealed bytes in order, then finish. Always a PUT without conditions: a
// content object's name is its file's uid, its header binds that uid and a fresh generation, and the manifest names the
// version (or ETag) the upload produced, so another writer's object of the same key is never mistaken for ours.
class ContentUpload {
public:
    virtual ~ContentUpload() = default;
    virtual void write(std::span<const uint8_t> bytes) = 0;
    // The object is stored: its ETag (quoted) and, on a versioned bucket, its version id. PutOutcomeUnknown when it may
    // or may not have been stored (the engine then records nothing; the bytes are an orphan at worst).
    virtual manifest::PutResult finish() = 0;
    // Nothing more is sent; whatever was sent is the store's to discard. Never throws.
    virtual void abort() noexcept = 0;
};

// Bytes of a content object and the object's whole size as the provider reports it (the Content-Range total), which a
// ranged read checks against the manifest's authenticated size so a truncated object can't pass for a short file.
struct ContentRange {
    std::vector<uint8_t> bytes;
    uint64_t total{};
};

class BucketStore : public manifest::ObjectStore {
public:
    // `size`: the object's sealed size when the caller knows it (a hint for a single PUT versus multipart).
    [[nodiscard]] virtual std::unique_ptr<ContentUpload> putContent(const std::string& key,
                                                                    std::optional<uint64_t> size) = 0;
    // Bytes [offset, offset + length) of `key` at `versionId` (the current object when nullopt); fewer at the end of the
    // object. nullopt for 404 (or a delete marker).
    [[nodiscard]] virtual std::optional<ContentRange> getContent(const std::string& key,
                                                                 const std::optional<std::string>& versionId,
                                                                 uint64_t offset, uint64_t length) = 0;
};

}
