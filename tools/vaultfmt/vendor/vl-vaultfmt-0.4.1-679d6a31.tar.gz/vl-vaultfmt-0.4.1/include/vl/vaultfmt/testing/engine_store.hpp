// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// Test doubles for the database-free engine (vl/vaultfmt/engine/): the in-memory versioned bucket as an
// engine::BucketStore (content uploads and ranged reads by version), a hooking wrapper for crash and fault drills, and
// an in-memory state blob that can be copied (a "crash": a new engine opens what was durable) and torn.

#include "vl/vaultfmt/engine/State.hpp"
#include "vl/vaultfmt/engine/Store.hpp"
#include "vl/vaultfmt/testing/memory_store.hpp"

#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace vl::vaultfmt::test_support {

class MemoryBucketStore final : public engine::BucketStore {
public:
    MemoryBucketStore(std::shared_ptr<MemoryBucket> bucket, const manifest::WriteCapability mode)
        : bucket_(std::move(bucket)), inner_(bucket_, mode) {}

    std::optional<manifest::StoredObject> get(const std::string& key, const std::optional<std::string>& v) override {
        return inner_.get(key, v);
    }
    std::optional<std::vector<uint8_t>> getRange(const std::string& key, const uint64_t o, const uint64_t l) override {
        return inner_.getRange(key, o, l);
    }
    std::optional<std::string> headEtag(const std::string& key) override { return inner_.headEtag(key); }
    std::string putIfAbsent(const std::string& key, const std::vector<uint8_t>& b) override { return inner_.putIfAbsent(key, b); }
    std::string putIfMatch(const std::string& key, const std::vector<uint8_t>& b, const std::string& e) override {
        return inner_.putIfMatch(key, b, e);
    }
    manifest::PutResult put(const std::string& key, const std::vector<uint8_t>& b) override { return inner_.put(key, b); }
    std::vector<manifest::ListedObject> list(const std::string& prefix) override { return inner_.list(prefix); }
    std::vector<manifest::StoredVersion> versions(const std::string& key) override { return inner_.versions(key); }
    std::vector<manifest::StoredVersion> versionsUnder(const std::string& prefix) override {
        return inner_.versionsUnder(prefix);
    }
    void remove(const std::string& key) override { inner_.remove(key); }
    void removeVersion(const std::string& key, const std::string& v) override { inner_.removeVersion(key, v); }
    [[nodiscard]] manifest::WriteCapability mode() const override { return inner_.mode(); }

    class Upload final : public engine::ContentUpload {
    public:
        Upload(std::shared_ptr<MemoryBucket> bucket, std::string key) : bucket_(std::move(bucket)), key_(std::move(key)) {}
        void write(const std::span<const uint8_t> bytes) override { body_.insert(body_.end(), bytes.begin(), bytes.end()); }
        manifest::PutResult finish() override { return bucket_->write(key_, body_, std::nullopt, false); }
        void abort() noexcept override { body_.clear(); }

    private:
        std::shared_ptr<MemoryBucket> bucket_;
        std::string key_;
        std::vector<uint8_t> body_;
    };

    std::unique_ptr<engine::ContentUpload> putContent(const std::string& key, std::optional<uint64_t>) override {
        return std::make_unique<Upload>(bucket_, key);
    }
    std::optional<engine::ContentRange> getContent(const std::string& key, const std::optional<std::string>& versionId,
                                                   const uint64_t offset, const uint64_t length) override {
        const auto v = bucket_->read(key, versionId);
        if (!v) return std::nullopt;
        engine::ContentRange out;
        out.total = v->body.size();
        if (offset < v->body.size()) {
            const auto end = std::min<uint64_t>(v->body.size(), offset + length);
            out.bytes.assign(v->body.begin() + static_cast<std::ptrdiff_t>(offset),
                             v->body.begin() + static_cast<std::ptrdiff_t>(end));
        }
        return out;
    }

private:
    std::shared_ptr<MemoryBucket> bucket_;
    MemoryStore inner_;
};

// A BucketStore that calls `before` and `after` around every request: op names "get", "get_range", "head",
// "put_if_absent", "put_if_match", "put", "list", "versions", "versions_under", "remove", "remove_version",
// "content_put" (before: the upload starts; after: it finished), "content_get". A throw from `before` stops the request
// before it is sent (a crash or a refusal); from `after`, it was applied and its reply lost.
class HookedBucketStore final : public engine::BucketStore {
public:
    using Hook = std::function<void(std::string_view op, const std::string& key)>;
    explicit HookedBucketStore(std::shared_ptr<engine::BucketStore> inner) : inner_(std::move(inner)) {}
    Hook before;
    Hook after;

private:
    template <class F>
    auto around(const std::string_view op, const std::string& key, F&& call) {
        if (before) before(op, key);
        auto out = call();
        if (after) after(op, key);
        return out;
    }

public:
    std::optional<manifest::StoredObject> get(const std::string& key, const std::optional<std::string>& v) override {
        return around("get", key, [&] { return inner_->get(key, v); });
    }
    std::optional<std::vector<uint8_t>> getRange(const std::string& key, const uint64_t o, const uint64_t l) override {
        return around("get_range", key, [&] { return inner_->getRange(key, o, l); });
    }
    std::optional<std::string> headEtag(const std::string& key) override {
        return around("head", key, [&] { return inner_->headEtag(key); });
    }
    std::string putIfAbsent(const std::string& key, const std::vector<uint8_t>& b) override {
        return around("put_if_absent", key, [&] { return inner_->putIfAbsent(key, b); });
    }
    std::string putIfMatch(const std::string& key, const std::vector<uint8_t>& b, const std::string& e) override {
        return around("put_if_match", key, [&] { return inner_->putIfMatch(key, b, e); });
    }
    manifest::PutResult put(const std::string& key, const std::vector<uint8_t>& b) override {
        return around("put", key, [&] { return inner_->put(key, b); });
    }
    std::vector<manifest::ListedObject> list(const std::string& prefix) override {
        return around("list", prefix, [&] { return inner_->list(prefix); });
    }
    std::vector<manifest::StoredVersion> versions(const std::string& key) override {
        return around("versions", key, [&] { return inner_->versions(key); });
    }
    std::vector<manifest::StoredVersion> versionsUnder(const std::string& prefix) override {
        return around("versions_under", prefix, [&] { return inner_->versionsUnder(prefix); });
    }
    void remove(const std::string& key) override {
        around("remove", key, [&] {
            inner_->remove(key);
            return 0;
        });
    }
    void removeVersion(const std::string& key, const std::string& v) override {
        around("remove_version", key, [&] {
            inner_->removeVersion(key, v);
            return 0;
        });
    }
    [[nodiscard]] manifest::WriteCapability mode() const override { return inner_->mode(); }

    std::unique_ptr<engine::ContentUpload> putContent(const std::string& key, const std::optional<uint64_t> size) override {
        if (before) before("content_put", key);
        return std::make_unique<Upload>(*this, inner_->putContent(key, size), key);
    }
    std::optional<engine::ContentRange> getContent(const std::string& key, const std::optional<std::string>& versionId,
                                                   const uint64_t offset, const uint64_t length) override {
        return around("content_get", key, [&] { return inner_->getContent(key, versionId, offset, length); });
    }

private:
    class Upload final : public engine::ContentUpload {
    public:
        Upload(HookedBucketStore& store, std::unique_ptr<engine::ContentUpload> inner, std::string key)
            : store_(store), inner_(std::move(inner)), key_(std::move(key)) {}
        void write(const std::span<const uint8_t> bytes) override { inner_->write(bytes); }
        manifest::PutResult finish() override {
            auto r = inner_->finish();
            if (store_.after) store_.after("content_put", key_);
            return r;
        }
        void abort() noexcept override { inner_->abort(); }

    private:
        HookedBucketStore& store_;
        std::unique_ptr<engine::ContentUpload> inner_;
        std::string key_;
    };

    std::shared_ptr<engine::BucketStore> inner_;
};

// A state blob in memory. durable() is what a crash leaves; tearNextAppend(n) keeps only n bytes of the next append
// and then fails it (a crash during the append); failNext() makes the next save or append throw (nothing written).
class MemoryStateBlob final : public engine::StateBlob {
public:
    explicit MemoryStateBlob(const bool appendable = true) : appendable_(appendable) {}
    MemoryStateBlob(std::optional<std::vector<uint8_t>> bytes, const bool appendable)
        : bytes_(std::move(bytes)), appendable_(appendable) {}

    std::optional<std::vector<uint8_t>> load() override {
        std::scoped_lock lock(mutex_);
        return bytes_;
    }
    void save(const std::span<const uint8_t> bytes) override {
        std::scoped_lock lock(mutex_);
        if (std::exchange(fail_, false)) throw std::runtime_error("the state blob refused the save (test)");
        bytes_.emplace(bytes.begin(), bytes.end());
        ++saves_;
    }
    bool append(const std::span<const uint8_t> bytes) override {
        std::scoped_lock lock(mutex_);
        if (!appendable_) return false;
        if (std::exchange(fail_, false)) throw std::runtime_error("the state blob refused the append (test)");
        if (!bytes_) throw std::runtime_error("append without a saved blob (test)");
        if (const auto tear = std::exchange(tear_, std::nullopt)) {
            bytes_->insert(bytes_->end(), bytes.begin(), bytes.begin() + static_cast<std::ptrdiff_t>(std::min(*tear, bytes.size())));
            throw std::runtime_error("the append was torn (test)");
        }
        bytes_->insert(bytes_->end(), bytes.begin(), bytes.end());
        ++appends_;
        return true;
    }

    [[nodiscard]] std::optional<std::vector<uint8_t>> durable() const {
        std::scoped_lock lock(mutex_);
        return bytes_;
    }
    // A copy of what is durable now, as a new blob (the state a restarted engine finds).
    [[nodiscard]] std::shared_ptr<MemoryStateBlob> crash() const {
        std::scoped_lock lock(mutex_);
        return std::make_shared<MemoryStateBlob>(bytes_, appendable_);
    }
    void tearNextAppend(const std::size_t keep) {
        std::scoped_lock lock(mutex_);
        tear_ = keep;
    }
    void failNext() {
        std::scoped_lock lock(mutex_);
        fail_ = true;
    }
    void corrupt(const std::size_t at) {
        std::scoped_lock lock(mutex_);
        if (bytes_ && at < bytes_->size()) (*bytes_)[at] ^= 0xff;
    }
    [[nodiscard]] std::size_t saves() const {
        std::scoped_lock lock(mutex_);
        return saves_;
    }
    [[nodiscard]] std::size_t appends() const {
        std::scoped_lock lock(mutex_);
        return appends_;
    }

private:
    mutable std::mutex mutex_;
    std::optional<std::vector<uint8_t>> bytes_;
    bool appendable_;
    bool fail_{false};
    std::optional<std::size_t> tear_;
    std::size_t saves_{0};
    std::size_t appends_{0};
};

}
