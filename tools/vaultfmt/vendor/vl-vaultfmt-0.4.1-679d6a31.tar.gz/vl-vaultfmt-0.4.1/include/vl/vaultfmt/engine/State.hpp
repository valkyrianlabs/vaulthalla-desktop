// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include "vl/vaultfmt/manifest/Session.hpp"

#include <cstddef>
#include <cstdint>
#include <ctime>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

// What a database-free engine keeps between runs (vaulthalla-server design/core/vault-format-library.md, "State a
// database-free engine keeps"), in one blob per vault: the chain position, refusals, the retained roots' sids and GC
// bookkeeping, the base copy of the recorded root (what the last publish produced, or the last root applied), the
// roots PUT and not recorded with their pending base copies, and the working content (the last settled content and
// every local change made since) with its change log. docs/engine.md specifies the blob's format and invariants.
//
// The blob is a snapshot followed by journal records: an operation appends one record and returns only once the
// append is durable (design decision 8); anything that moves the chain position rewrites the whole blob atomically
// (a snapshot), and so does every `compactAfter`-th change. A torn last record (a crash during an append) is dropped:
// its operation never returned.
namespace vl::vaultfmt::engine {

// Where the blob lives. Desktop: the File Provider extension's app group container (the C API's state callbacks, or the
// reference FileStateBlob below); the tests: memory.
class StateBlob {
public:
    virtual ~StateBlob() = default;
    // The blob as last saved, with whatever was appended after it; nullopt when there is none.
    [[nodiscard]] virtual std::optional<std::vector<uint8_t>> load() = 0;
    // Replaces the blob atomically (the old bytes or the new ones, also across a crash), durable before it returns.
    virtual void save(std::span<const uint8_t> bytes) = 0;
    // Appends durably before it returns; a crash during it may leave part of `bytes` at the end, which a load drops.
    // false: not supported (every change is then a save).
    virtual bool append(std::span<const uint8_t> bytes) {
        (void)bytes;
        return false;
    }
};

// The reference file blob: one file, `path`. save writes `path`.tmp (mode 0600), flushes it (F_FULLFSYNC on Apple
// platforms, fsync elsewhere), renames it over `path` and flushes the directory; append opens with O_APPEND, writes
// and flushes the same way. The only POSIX file I/O in the library.
class FileStateBlob final : public StateBlob {
public:
    explicit FileStateBlob(std::string path);
    [[nodiscard]] std::optional<std::vector<uint8_t>> load() override;
    void save(std::span<const uint8_t> bytes) override;
    bool append(std::span<const uint8_t> bytes) override;

private:
    std::string path_;
};

// The blob could not be read or written. A change that throws it did not happen (in memory either).
class StateFailed : public std::runtime_error {
public:
    explicit StateFailed(const std::string& message) : std::runtime_error(message) {}
};

// The blob was written by a newer engine (a newer state format, or a writer revision above this engine's): never read
// into a store that would drop what it doesn't know, and never overwritten.
class StateTooNew : public std::runtime_error {
public:
    explicit StateTooNew(const std::string& message) : std::runtime_error(message) {}
};

// The blob is another vault's: never overwritten.
class StateOfAnotherVault : public std::runtime_error {
public:
    explicit StateOfAnotherVault(const std::string& message) : std::runtime_error(message) {}
};

enum class StateCondition {
    Fresh,     // no blob
    Loaded,    // a snapshot and its journal
    Damaged,   // no readable snapshot (bad magic, checksum or encoding): the engine re-anchors from the bucket
};

struct StateLoad {
    StateCondition condition{StateCondition::Fresh};
    std::size_t journal_records{};   // replayed on top of the snapshot
    bool torn_tail{false};           // a last record cut short or failing its checksum (a crash during an append)
    bool journal_truncated{false};   // a bad record with more bytes after it: what followed it was dropped
    std::string damage;              // what was wrong (Damaged, truncated, torn)
};

// An object to delete once a root without its entry is recorded (a purge; docs/engine.md "Purges").
struct Purge {
    std::string uid;
    std::string key;
    std::vector<std::string> version_ids;   // empty: DELETE by name (an unversioned bucket)
    uint64_t revision{};                    // the change that purged it
    [[nodiscard]] bool operator==(const Purge&) const = default;
};

// One change to the working content, journalled before the operation that made it returns.
struct Change {
    std::vector<manifest::Entry> put{};                       // entries added or replaced, by uid
    std::vector<std::string> remove{};                        // uids gone
    std::optional<std::vector<manifest::KeyRecord>> keys{};   // the key history after the change
    std::optional<manifest::VaultInfo> vault{};
    std::vector<Purge> purges{};
};

// What changed since a revision (File Provider's change enumeration).
struct ChangeLog {
    uint64_t generation{};    // a new one whenever the state starts over (creation, re-anchor): older anchors expire
    uint64_t revision{};      // now
    bool expired{false};      // the anchor is older than the log keeps, of another generation, or from the future
    std::vector<std::string> changed;   // uids whose entry was added or changed
    std::vector<std::string> removed;   // uids whose entry is gone
};

// The manifest's StateStore over a StateBlob, plus the engine's working content. Every call is durable before it
// returns. The engine serializes the working-content calls under its own lock; the StateStore calls (from the
// manifest session) and those may run on different threads.
class StateFile final : public manifest::StateStore {
public:
    StateFile(std::shared_ptr<StateBlob> blob, const manifest::Uid& vaultUid, std::function<std::time_t()> now,
              std::size_t compactAfter = 256);
    ~StateFile() override;

    // Reads the blob. Throws StateTooNew, StateOfAnotherVault, StateFailed (the blob could not be read). A torn or
    // truncated journal is rewritten as one snapshot before this returns.
    StateLoad load(uint32_t writerRevision);

    // A state starting over (a new vault, or a re-anchor from the bucket): the working content and, when the bucket
    // has one, the root it was read from (recorded as not ours), in one save. A new change-log generation.
    //
    // `settled`: the working content is the root's (nothing to publish).
    void reset(manifest::Content working, const std::optional<manifest::RootRecord>& root, const std::string& nodeId,
               uint32_t writerRevision, bool settled);

    // ---- the working content ---------------------------------------------------------------------------------------
    [[nodiscard]] const manifest::Content& working() const;
    // Journals `change` (an append, or a save every compactAfter changes) and applies it. Returns the new revision.
    uint64_t commit(const Change& change);
    // An apply (the engine's refresh): the working content becomes `result` and `root` is recorded, in one save.
    // `settled`: nothing of ours is left unpublished in `result`.
    void applyAndRecord(manifest::Content result, const manifest::RootRecord& root, bool settled);
    [[nodiscard]] uint64_t revision() const;
    [[nodiscard]] uint64_t publishedRevision() const;
    [[nodiscard]] ChangeLog changesSince(uint64_t generation, uint64_t after) const;
    [[nodiscard]] std::vector<Purge> purges() const;
    void dropPurges(const std::vector<std::string>& uids);
    // The next recordRoot of an own root settles revision `revision` (the one its collect saw).
    void noteCollected(uint64_t revision);
    // The collected revision is in the bucket without a new root (nothing to publish).
    void settleCollected();
    [[nodiscard]] std::string nodeId() const;
    // A join or leave every publish carries until a recorded root shows it (ChainState::writers_change).
    void setWritersChange(const std::optional<manifest::WritersChange>& change);

    // ---- manifest::StateStore --------------------------------------------------------------------------------------
    [[nodiscard]] manifest::ChainState state() override;
    void recordRoot(const manifest::RootRecord& record) override;
    [[nodiscard]] std::optional<manifest::BaseCopy> base() override;
    void markApplying(uint64_t epoch, const std::string& rootSha256) override;
    void notePublishing(const std::string& rootSha256, const manifest::BaseCopy& pending) override;
    [[nodiscard]] std::optional<manifest::BaseCopy> pendingBase(const std::string& rootSha256) override;
    [[nodiscard]] bool recordRefused(const std::string& reason, uint64_t epoch, const std::string& rootSha256) override;
    [[nodiscard]] std::set<std::string> retainedSids() override;
    void markCollected() override;
    [[nodiscard]] std::time_t firstUnreferenced(const std::string& sid) override;
    void forgetUnreferenced(const std::string& sid) override;

    // The format (docs/engine.md): "VLVFSTAT", the format version, then records.
    static constexpr uint32_t kFormatVersion = 1;
    // Gone uids the change log keeps before its oldest anchors expire.
    static constexpr std::size_t kMaxRemovedInLog = 4096;

    struct Data;   // the persisted state (src/engine/StateFile.cpp)

private:
    void saveLocked(const Data& data, const manifest::Content& working);
    template <class F>
    void mutate(F&& f);

    std::shared_ptr<StateBlob> blob_;
    manifest::Uid vaultUid_;
    std::function<std::time_t()> now_;
    std::size_t compactAfter_;
    mutable std::mutex mutex_;
    std::unique_ptr<Data> data_;        // replaced whole by each save (a failed save leaves it as it was)
    manifest::Content working_;         // changed only by reset, commit and applyAndRecord, under mutex_
    std::size_t journalRecords_{0};
    bool appendable_{true};
    std::optional<uint64_t> collected_;
};

}
