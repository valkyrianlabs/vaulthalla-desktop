// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
// libFuzzer entry point for the reader's byte-facing C API (vl_vaultfmt.h, "The reader"); the iteration itself is
// reader_fuzz_body.hpp. Build and run: fuzz/meson.build (-Dfuzz=true, clang).
#include "reader_fuzz_body.hpp"

#include <cstddef>
#include <cstdint>

extern "C" int LLVMFuzzerTestOneInput(const uint8_t* data, const std::size_t size) {
    vl::vaultfmt::reader_fuzz::runOne({data, size});
    return 0;
}
