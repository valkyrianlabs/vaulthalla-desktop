// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The reader's C API (vl_vaultfmt.h, "The reader"): what the portal's WebAssembly build adds to the C API. Everything
// here works on bytes the caller supplies and is read only: the head choice runs the library's own C1 code
// (manifest::loadCanonicalRoot) over a store that answers from those bytes and refuses every write, and asks for more
// bytes instead of fetching them. No exception leaves an extern "C" function.
#include "vl/vaultfmt/vl_vaultfmt.h"

#include "c_api_internal.hpp"

#include "vl/vaultfmt/manifest/Chain.hpp"
#include "vl/vaultfmt/manifest/Document.hpp"
#include "vl/vaultfmt/manifest/Objects.hpp"
#include "vl/vaultfmt/manifest/Reader.hpp"
#include "vl/vaultfmt/manifest/Store.hpp"
#include "vl/vaultfmt/vhf1/Format.hpp"

#include <vl/keykit/kev1.hpp>
#include <vl/keykit/secret.hpp>
#include <vl/keykit/seed.hpp>

#include <nlohmann/json.hpp>

#include <algorithm>
#include <cstddef>
#include <cstring>
#include <map>
#include <memory>
#include <new>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace vf = vl::vaultfmt;
namespace kk = vl::keykit;

struct vl_vaultfmt_buffer {
    std::vector<uint8_t> bytes;
};

struct vl_vaultfmt_recipient {
    kk::kev1::Suite suite{kk::kev1::Suite::X25519};
    kk::SecretBytes secret;
};

struct vl_vaultfmt_head {
    struct Version {
        std::string id;
        bool delete_marker{false};
        bool is_latest{false};
        uint64_t size{};
        std::string etag;
    };
    vf::vhf1::Uid vault{};
    std::vector<Version> listing;                 // newest first, as listed
    std::map<std::string, std::size_t> index;     // id -> position in listing
    std::optional<vf::manifest::Known> anchor;
    std::map<std::string, std::vector<uint8_t>> supplied;
    std::set<std::string> gone;
    std::size_t supplied_bytes{};
    bool full{false};                             // a decide needed a version outside the first set
    std::optional<vf::manifest::Loaded> decided;
};

// Its own namespace: a unity build puts this file and c_api.cpp in one unit, and each has file-local helpers.
namespace vl::vaultfmt::capi_reader {

namespace {

static_assert(VL_VAULTFMT_ERR_KEV1_BAD_KEY_VERSION == 400 + static_cast<int>(kk::kev1::ErrorCode::BadKeyVersion));
static_assert(VL_VAULTFMT_KEV1_SUITE_X25519 == static_cast<int>(kk::kev1::Suite::X25519) &&
              VL_VAULTFMT_KEV1_SUITE_P256 == static_cast<int>(kk::kev1::Suite::P256));

#if defined(__wasm32__)
// The struct layouts wasm/reader.ts reads and writes (wasm32: pointers and size_t are 4 bytes, uint64_t aligned 8).
static_assert(sizeof(vl_vaultfmt_anchor) == 16 && offsetof(vl_vaultfmt_anchor, root_sha256) == 8 &&
              offsetof(vl_vaultfmt_anchor, version_id) == 12);
static_assert(sizeof(vl_vaultfmt_known) == 16 && offsetof(vl_vaultfmt_known, root_sha256) == 8);
static_assert(sizeof(vl_vaultfmt_expectation) == 16 && offsetof(vl_vaultfmt_expectation, vault_uid) == 4 &&
              offsetof(vl_vaultfmt_expectation, object_uid) == 8 && offsetof(vl_vaultfmt_expectation, generation) == 12);
static_assert(sizeof(vl_vaultfmt_header_info) == 96 && offsetof(vl_vaultfmt_header_info, key_version) == 4 &&
              offsetof(vl_vaultfmt_header_info, vault_uid) == 8 && offsetof(vl_vaultfmt_header_info, object_uid) == 24 &&
              offsetof(vl_vaultfmt_header_info, salt) == 40 && offsetof(vl_vaultfmt_header_info, chunk_log2) == 72 &&
              offsetof(vl_vaultfmt_header_info, plaintext_size) == 80 && offsetof(vl_vaultfmt_header_info, chunk_count) == 88);
static_assert(sizeof(vl_vaultfmt_root_info) == 112 && offsetof(vl_vaultfmt_root_info, root_sha256) == 8 &&
              offsetof(vl_vaultfmt_root_info, gap) == 76 && offsetof(vl_vaultfmt_root_info, version_log) == 80 &&
              offsetof(vl_vaultfmt_root_info, files) == 88 && offsetof(vl_vaultfmt_root_info, dirs) == 96 &&
              offsetof(vl_vaultfmt_root_info, bytes) == 104);
static_assert(sizeof(vl_vaultfmt_object_ref) == 32 && offsetof(vl_vaultfmt_object_ref, key) == 4 &&
              offsetof(vl_vaultfmt_object_ref, object_sha256) == 8 && offsetof(vl_vaultfmt_object_ref, size) == 16 &&
              offsetof(vl_vaultfmt_object_ref, snapshot) == 24 && offsetof(vl_vaultfmt_object_ref, range_lo) == 28 &&
              offsetof(vl_vaultfmt_object_ref, range_hi) == 29);
static_assert(sizeof(vl_vaultfmt_object_bytes) == 12 && offsetof(vl_vaultfmt_object_bytes, bytes) == 4 &&
              offsetof(vl_vaultfmt_object_bytes, len) == 8);
#endif

// Control flow inside this file only.
struct InvalidArgument {};
struct Limit {};
struct BadListing {};
struct NotFound {};
// The decision needs the bytes of a version that was neither supplied nor reported gone. Not a std::exception, so no
// handler in the library that catches those (a provider without versions, an object that doesn't authenticate) can
// mistake it for one of its own cases.
struct NeedObjects {};

vl_vaultfmt_status seedStatus(const std::string& code) {
    if (code == "bad_symbol") return VL_VAULTFMT_ERR_SEED_BAD_SYMBOL;
    if (code == "bad_check") return VL_VAULTFMT_ERR_SEED_BAD_CHECK;
    return VL_VAULTFMT_ERR_SEED_BAD_LENGTH;
}

vl_vaultfmt_status formatStatus(const std::string& code) {
    if (code == "bad_segment") return VL_VAULTFMT_ERR_MANIFEST_BAD_SEGMENT;
    if (code == "bad_snapshot") return VL_VAULTFMT_ERR_MANIFEST_BAD_SNAPSHOT;
    return VL_VAULTFMT_ERR_MANIFEST_BAD_ROOT;
}

template <class F>
vl_vaultfmt_status guarded(F&& f) noexcept {
    try {
        return f();
    } catch (const InvalidArgument&) {
        return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    } catch (const Limit&) {
        return VL_VAULTFMT_ERR_READER_LIMIT;
    } catch (const BadListing&) {
        return VL_VAULTFMT_ERR_READER_BAD_LISTING;
    } catch (const NotFound&) {
        return VL_VAULTFMT_ERR_NOT_FOUND;
    } catch (const NeedObjects&) {
        return VL_VAULTFMT_ERR_READER_NEED_OBJECTS;
    } catch (const kk::kev1::Error& e) {
        return 400 + static_cast<vl_vaultfmt_status>(e.code());
    } catch (const kk::SeedError& e) {
        return seedStatus(e.code());
    } catch (const vhf1::Error& e) {
        return 100 + static_cast<vl_vaultfmt_status>(e.code());
    } catch (const manifest::ChainRejected& e) {
        return 300 + static_cast<vl_vaultfmt_status>(e.code());
    } catch (const manifest::NoUsableRoot&) {
        return VL_VAULTFMT_ERR_READER_NO_USABLE_ROOT;
    } catch (const manifest::FormatError& e) {
        return formatStatus(e.code());
    } catch (const std::invalid_argument&) {
        return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    } catch (const std::bad_alloc&) {
        return VL_VAULTFMT_ERR_OUT_OF_MEMORY;
    } catch (...) {
        return VL_VAULTFMT_ERR_INTERNAL;
    }
}

vl_vaultfmt_status writeOut(const std::string_view bytes, char* out, size_t* outLen) {
    if (!outLen) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (*outLen < bytes.size() || (!out && !bytes.empty())) {
        *outLen = bytes.size();
        return VL_VAULTFMT_ERR_BUFFER_TOO_SMALL;
    }
    if (!bytes.empty()) std::memcpy(out, bytes.data(), bytes.size());
    *outLen = bytes.size();
    return VL_VAULTFMT_OK;
}

std::span<const uint8_t> bytesOf(const uint8_t* p, const size_t n) {
    if (!p && n) throw InvalidArgument{};
    return {p, n};
}

std::string_view textOf(const char* p, const size_t n) {
    if (!p && n) throw InvalidArgument{};
    return {p ? p : "", n};
}

vhf1::Uid uidOf(const uint8_t* p) {
    if (!p) throw InvalidArgument{};
    vhf1::Uid u{};
    std::memcpy(u.data(), p, u.size());
    return u;
}

bool lowerHex(const std::string_view s, const std::size_t n) {
    return s.size() == n && std::ranges::all_of(s, [](const char c) { return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'); });
}

// ---- the listing ----------------------------------------------------------------------------------------------------

// Nesting deeper than the listing's own (array of objects of scalars) is refused before parsing, so the parser's work
// is bounded by the text and never by its shape.
constexpr int kMaxListingDepth = 4;

bool depthWithin(const std::string_view text, const int maxDepth) {
    int depth = 0;
    bool inString = false;
    bool escaped = false;
    for (const char c : text) {
        if (inString) {
            if (escaped) escaped = false;
            else if (c == '\\') escaped = true;
            else if (c == '"') inString = false;
            continue;
        }
        if (c == '"') inString = true;
        else if (c == '[' || c == '{') {
            if (++depth > maxDepth) return false;
        } else if (c == ']' || c == '}') --depth;
    }
    return true;
}

std::vector<vl_vaultfmt_head::Version> parseListing(const std::string_view text) {
    if (text.size() > VL_VAULTFMT_READER_MAX_LISTING_BYTES) throw Limit{};
    if (!depthWithin(text, kMaxListingDepth)) throw BadListing{};
    const auto j = nlohmann::json::parse(text, nullptr, false);
    if (j.is_discarded() || !j.is_array()) throw BadListing{};
    if (j.size() > VL_VAULTFMT_READER_MAX_VERSIONS) throw Limit{};
    std::vector<vl_vaultfmt_head::Version> out;
    out.reserve(j.size());
    for (const auto& v : j) {
        if (!v.is_object()) throw BadListing{};
        const auto id = v.find("version_id");
        if (id == v.end() || !id->is_string()) throw BadListing{};
        vl_vaultfmt_head::Version version;
        version.id = id->get<std::string>();
        if (version.id.empty()) throw BadListing{};
        if (version.id.size() > VL_VAULTFMT_READER_MAX_VERSION_ID) throw Limit{};
        if (const auto k = v.find("key"); k != v.end() && (!k->is_string() || k->get<std::string>() != manifest::kRootKey))
            throw BadListing{};
        if (const auto m = v.find("delete_marker"); m != v.end()) {
            if (!m->is_boolean()) throw BadListing{};
            version.delete_marker = m->get<bool>();
        }
        if (const auto l = v.find("is_latest"); l != v.end()) {
            if (!l->is_boolean()) throw BadListing{};
            version.is_latest = l->get<bool>();
        }
        if (const auto s = v.find("size"); s != v.end()) {
            if (!s->is_number_unsigned()) throw BadListing{};
            version.size = s->get<uint64_t>();
        }
        if (const auto e = v.find("etag"); e != v.end() && !e->is_null()) {
            if (!e->is_string()) throw BadListing{};
            version.etag = e->get<std::string>();
        }
        out.push_back(std::move(version));
    }
    return out;
}

// ---- a read-only store over the supplied versions -------------------------------------------------------------------

class SuppliedStore final : public manifest::ObjectStore {
public:
    explicit SuppliedStore(const vl_vaultfmt_head& head) : head_(head) {}

    std::optional<manifest::StoredObject> get(const std::string& key,
                                              const std::optional<std::string>& versionId) override {
        if (key != manifest::kRootKey || !versionId) throw std::logic_error("the reader reads root versions only");
        const auto at = head_.index.find(*versionId);
        if (at == head_.index.end() || head_.listing[at->second].delete_marker) return std::nullopt;
        if (head_.gone.contains(*versionId)) return std::nullopt;
        const auto it = head_.supplied.find(*versionId);
        if (it == head_.supplied.end()) throw NeedObjects{};
        const auto& v = head_.listing[at->second];
        return manifest::StoredObject{it->second, v.etag, v.id};
    }
    std::optional<std::vector<uint8_t>> getRange(const std::string&, uint64_t, uint64_t) override { refuse(); }
    std::optional<std::string> headEtag(const std::string&) override { refuse(); }
    std::string putIfAbsent(const std::string&, const std::vector<uint8_t>&) override { refuse(); }
    std::string putIfMatch(const std::string&, const std::vector<uint8_t>&, const std::string&) override { refuse(); }
    manifest::PutResult put(const std::string&, const std::vector<uint8_t>&) override { refuse(); }
    std::vector<manifest::ListedObject> list(const std::string&) override { refuse(); }
    std::vector<manifest::StoredVersion> versions(const std::string& key) override {
        if (key != manifest::kRootKey) refuse();
        std::vector<manifest::StoredVersion> out;
        out.reserve(head_.listing.size());
        for (const auto& v : head_.listing)
            out.push_back({key, v.id, v.size, std::nullopt, v.delete_marker, v.etag, v.is_latest});
        return out;
    }
    std::vector<manifest::StoredVersion> versionsUnder(const std::string&) override { refuse(); }
    void remove(const std::string&) override { refuse(); }
    void removeVersion(const std::string&, const std::string&) override { refuse(); }
    [[nodiscard]] manifest::WriteCapability mode() const override { return manifest::WriteCapability::VersionLog; }

private:
    [[noreturn]] static void refuse() { throw std::logic_error("the reader's store is read only"); }
    const vl_vaultfmt_head& head_;
};

std::vector<std::string> neededOf(const vl_vaultfmt_head& head) {
    std::vector<std::string> out;
    if (head.decided) return out;
    std::size_t last = head.listing.size();   // exclusive, newest first
    if (!head.full && head.anchor && head.anchor->version_id)
        if (const auto it = head.index.find(*head.anchor->version_id); it != head.index.end()) last = it->second + 1;
    for (std::size_t i = 0; i < last; ++i) {
        const auto& v = head.listing[i];
        if (v.delete_marker || head.supplied.contains(v.id) || head.gone.contains(v.id)) continue;
        out.push_back(v.id);
    }
    return out;
}

const vl_vaultfmt_head::Version& listed(const vl_vaultfmt_head& head, const std::string_view id) {
    const auto it = head.index.find(std::string(id));
    if (it == head.index.end() || head.listing[it->second].delete_marker) throw NotFound{};
    return head.listing[it->second];
}

nlohmann::json idsJson(const std::vector<std::string>& ids) {
    auto a = nlohmann::json::array();
    for (const auto& id : ids) a.push_back(id);
    return a;
}

const manifest::Entry* findEntry(const manifest::Content& content, const std::string_view uid) {
    const auto& entries = content.entries;
    const auto it = std::lower_bound(entries.begin(), entries.end(), uid,
                                     [](const manifest::Entry& e, const std::string_view u) { return e.uid < u; });
    return it == entries.end() || it->uid != uid ? nullptr : &*it;
}

vhf1::Salt saltOf(const std::string& hex) {
    if (!lowerHex(hex, 2 * vhf1::kSaltSize)) throw manifest::FormatError("bad_segment", "generation is not 32 bytes of hex");
    vhf1::Salt salt{};
    for (std::size_t i = 0; i < salt.size(); ++i) salt[i] = static_cast<uint8_t>(std::stoul(hex.substr(2 * i, 2), nullptr, 16));
    return salt;
}

}

}

namespace capi = vl::vaultfmt::capi;
namespace rd = vl::vaultfmt::capi_reader;

extern "C" {

// ---- buffers --------------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_buffer_new(vl_vaultfmt_buffer** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        *out = new vl_vaultfmt_buffer{};
        return VL_VAULTFMT_OK;
    });
}

int32_t vl_vaultfmt_buffer_sink(void* buffer, const uint8_t* bytes, const size_t len) {
    auto* b = static_cast<vl_vaultfmt_buffer*>(buffer);
    if (!b || (!bytes && len)) return 1;
    if (len == 0) return 0;
    auto& v = b->bytes;
    if (len > VL_VAULTFMT_READER_MAX_BUFFER_BYTES - v.size()) return 1;
    try {
        if (v.size() + len > v.capacity()) {
            // Grow by hand: the old storage held plaintext and is zeroed before it is released.
            std::vector<uint8_t> next;
            next.reserve(std::max<std::size_t>(v.size() + len, std::min<std::size_t>(2 * v.capacity(), VL_VAULTFMT_READER_MAX_BUFFER_BYTES)));
            next.assign(v.begin(), v.end());
            kk::wipe(v);
            v.swap(next);
        }
        v.insert(v.end(), bytes, bytes + len);
        return 0;
    } catch (...) {
        return 1;
    }
}

vl_vaultfmt_sink_fn vl_vaultfmt_buffer_sink_fn(void) { return &vl_vaultfmt_buffer_sink; }

const uint8_t* vl_vaultfmt_buffer_data(const vl_vaultfmt_buffer* buffer) {
    return buffer && !buffer->bytes.empty() ? buffer->bytes.data() : nullptr;
}

size_t vl_vaultfmt_buffer_size(const vl_vaultfmt_buffer* buffer) { return buffer ? buffer->bytes.size() : 0; }

void vl_vaultfmt_buffer_clear(vl_vaultfmt_buffer* buffer) {
    if (!buffer) return;
    buffer->bytes.resize(buffer->bytes.capacity());
    kk::wipe(buffer->bytes);
    buffer->bytes.clear();
}

void vl_vaultfmt_buffer_free(vl_vaultfmt_buffer* buffer) {
    vl_vaultfmt_buffer_clear(buffer);
    delete buffer;
}

// ---- KEV1 -----------------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_recipient_from_seed(const char* text, const size_t text_len, vl_vaultfmt_recipient** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        const auto seed = kk::RecoverySeed::parse(rd::textOf(text, text_len));
        *out = new vl_vaultfmt_recipient{kk::kev1::Suite::X25519, seed.x25519SecretKey()};
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_recipient_from_secret(const int32_t suite, const uint8_t* secret, const size_t secret_len,
                                                     vl_vaultfmt_recipient** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    if (!secret || secret_len != 32 || (suite != VL_VAULTFMT_KEV1_SUITE_X25519 && suite != VL_VAULTFMT_KEV1_SUITE_P256))
        return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        const auto s = static_cast<kk::kev1::Suite>(suite);
        auto r = std::make_unique<vl_vaultfmt_recipient>(vl_vaultfmt_recipient{s, kk::SecretBytes({secret, secret_len})});
        (void)kk::kev1::publicKeyOf(s, r->secret.bytes());   // a P-256 scalar out of range is refused here
        *out = r.release();
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_recipient_id(const vl_vaultfmt_recipient* recipient, uint8_t out[32]) {
    if (!recipient || !out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        const auto id = kk::kev1::recipientId(kk::kev1::publicKeyOf(recipient->suite, recipient->secret.bytes()));
        std::memcpy(out, id.data(), id.size());
        return VL_VAULTFMT_OK;
    });
}

void vl_vaultfmt_recipient_free(vl_vaultfmt_recipient* recipient) { delete recipient; }

vl_vaultfmt_status vl_vaultfmt_keyring_add_envelope(vl_vaultfmt_keyring* ring, const vl_vaultfmt_recipient* recipient,
                                                    const uint8_t vault_uid[16], const uint8_t* envelope,
                                                    const size_t envelope_len, uint32_t* key_version) {
    if (!ring || !recipient || !vault_uid) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        const auto unwrapped = kk::kev1::unwrap(rd::bytesOf(envelope, envelope_len), recipient->secret.bytes(),
                                                recipient->suite, rd::uidOf(vault_uid));
        const auto key = unwrapped.key.bytes();
        const auto status = vl_vaultfmt_keyring_add(ring, unwrapped.key_version, key.data(), key.size());
        if (status == VL_VAULTFMT_OK && key_version) *key_version = unwrapped.key_version;
        return status;
    });
}

// ---- the head -------------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_head_new(const uint8_t vault_uid[16], const char* listing, const size_t listing_len,
                                        const vl_vaultfmt_anchor* anchor, vl_vaultfmt_head** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    if (!vault_uid) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (anchor && (anchor->epoch == 0 || !anchor->root_sha256 ||
                   !rd::lowerHex({anchor->root_sha256, strnlen(anchor->root_sha256, VL_VAULTFMT_SHA256_HEX_SIZE + 1)},
                                   VL_VAULTFMT_SHA256_HEX_SIZE)))
        return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (anchor && anchor->version_id && strnlen(anchor->version_id, VL_VAULTFMT_READER_MAX_VERSION_ID + 1) >
                                            VL_VAULTFMT_READER_MAX_VERSION_ID)
        return VL_VAULTFMT_ERR_READER_LIMIT;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        auto h = std::make_unique<vl_vaultfmt_head>();
        h->vault = rd::uidOf(vault_uid);
        h->listing = rd::parseListing(rd::textOf(listing, listing_len));
        for (std::size_t i = 0; i < h->listing.size(); ++i)
            if (!h->index.emplace(h->listing[i].id, i).second) throw rd::BadListing{};
        if (anchor) {
            h->anchor = vf::manifest::Known{anchor->epoch, std::string(anchor->root_sha256, VL_VAULTFMT_SHA256_HEX_SIZE)};
            if (anchor->version_id && *anchor->version_id) h->anchor->version_id = std::string(anchor->version_id);
        }
        *out = h.release();
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_head_needed(const vl_vaultfmt_head* head, char* out, size_t* out_len) {
    if (!head) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return rd::guarded([&]() -> vl_vaultfmt_status { return rd::writeOut(rd::idsJson(rd::neededOf(*head)).dump(), out, out_len); });
}

vl_vaultfmt_status vl_vaultfmt_head_supply(vl_vaultfmt_head* head, const char* version_id, const size_t version_id_len,
                                           const uint8_t* bytes, const size_t len) {
    if (!head) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        const auto data = rd::bytesOf(bytes, len);
        const auto& v = rd::listed(*head, rd::textOf(version_id, version_id_len));
        if (head->decided || head->supplied.contains(v.id) || head->gone.contains(v.id)) return VL_VAULTFMT_OK;
        if (len > VL_VAULTFMT_READER_MAX_ROOT_BYTES || len > VL_VAULTFMT_READER_MAX_SUPPLIED_BYTES - head->supplied_bytes)
            throw rd::Limit{};
        head->supplied.emplace(v.id, std::vector<uint8_t>(data.begin(), data.end()));
        head->supplied_bytes += len;
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_head_gone(vl_vaultfmt_head* head, const char* version_id, const size_t version_id_len) {
    if (!head) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        const auto& v = rd::listed(*head, rd::textOf(version_id, version_id_len));
        if (!head->decided && !head->supplied.contains(v.id)) head->gone.insert(v.id);
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_head_decide(vl_vaultfmt_head* head, const vl_vaultfmt_keyring* ring) {
    if (!head || !ring) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (head->decided) return VL_VAULTFMT_OK;
    const auto status = rd::guarded([&]() -> vl_vaultfmt_status {
        rd::SuppliedStore store(*head);
        vf::manifest::LoadOptions options;
        options.known = head->anchor;
        head->decided = vf::manifest::loadCanonicalRoot(store, head->vault, capi::keyLookupOf(*ring), options);
        return VL_VAULTFMT_OK;
    });
    if (status == VL_VAULTFMT_ERR_READER_NEED_OBJECTS) head->full = true;
    return status;
}

vl_vaultfmt_status vl_vaultfmt_head_json(const vl_vaultfmt_head* head, char* out, size_t* out_len) {
    if (!head) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (!head->decided) return VL_VAULTFMT_ERR_UNUSABLE;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        const auto& d = *head->decided;
        nlohmann::json j;
        j["epoch"] = d.acceptance.epoch;
        j["root_sha256"] = d.acceptance.root_sha256;
        j["version_id"] = d.version_id ? nlohmann::json(*d.version_id) : nlohmann::json(nullptr);
        j["freshness"] = head->anchor ? "verified" : "unverified";
        j["gap"] = d.acceptance.gap;
        j["base_version_id"] = d.base_version_id ? nlohmann::json(*d.base_version_id) : nlohmann::json(nullptr);
        j["strays"] = rd::idsJson(d.strays);
        j["anchor"] = {{"epoch", d.acceptance.epoch},
                       {"root_sha256", d.acceptance.root_sha256},
                       {"version_id", j["version_id"]}};
        return rd::writeOut(vf::manifest::canonicalJson(j), out, out_len);
    });
}

vl_vaultfmt_status vl_vaultfmt_head_root(const vl_vaultfmt_head* head, const vl_vaultfmt_keyring* ring,
                                         vl_vaultfmt_root** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    if (!head || !ring) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (!head->decided) return VL_VAULTFMT_ERR_UNUSABLE;
    const auto& bytes = head->decided->root_bytes;
    return vl_vaultfmt_root_open(bytes.data(), bytes.size(), head->vault.data(), ring, nullptr, out);
}

void vl_vaultfmt_head_free(vl_vaultfmt_head* head) { delete head; }

// ---- the tree as JSON, and content ----------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_tree_list_json(const vl_vaultfmt_tree* tree, const char* parent, const size_t parent_len,
                                              char* out, size_t* out_len) {
    if (!tree) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        const auto want = rd::textOf(parent, parent_len);
        auto array = nlohmann::json::array();
        for (const auto& e : capi::treeContent(*tree).entries)
            if (parent ? (e.parent && *e.parent == want) : !e.parent) array.push_back(vf::manifest::toJson(e));
        return rd::writeOut(vf::manifest::canonicalJson(array), out, out_len);
    });
}

vl_vaultfmt_status vl_vaultfmt_tree_stat_json(const vl_vaultfmt_tree* tree, const char* uid, const size_t uid_len,
                                              char* out, size_t* out_len) {
    if (!tree) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        const auto* e = rd::findEntry(capi::treeContent(*tree), rd::textOf(uid, uid_len));
        if (!e) return VL_VAULTFMT_ERR_NOT_FOUND;
        return rd::writeOut(vf::manifest::canonicalJson(vf::manifest::toJson(*e)), out, out_len);
    });
}

vl_vaultfmt_status vl_vaultfmt_tree_open_content(const vl_vaultfmt_tree* tree, const uint8_t vault_uid[16],
                                                 const char* uid, const size_t uid_len, const char* version_id,
                                                 const size_t version_id_len, const uint8_t* header,
                                                 const size_t header_len, const vl_vaultfmt_keyring* ring,
                                                 vl_vaultfmt_opener** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    if (!tree || !vault_uid || !ring) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return rd::guarded([&]() -> vl_vaultfmt_status {
        const auto* e = rd::findEntry(capi::treeContent(*tree), rd::textOf(uid, uid_len));
        if (!e || e->kind != vf::manifest::EntryKind::File) return VL_VAULTFMT_ERR_NOT_FOUND;
        std::optional<std::string> generation;
        std::optional<uint64_t> size;
        if (!version_id) {
            if (version_id_len) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
            generation = e->generation;
            if (e->object) size = e->object->size;
        } else {
            const auto want = rd::textOf(version_id, version_id_len);
            const auto v = std::ranges::find_if(e->versions, [&](const vf::manifest::FileVersion& fv) {
                return fv.version_id == want && !fv.delete_marker;
            });
            if (v == e->versions.end()) return VL_VAULTFMT_ERR_NOT_FOUND;
            generation = v->generation;
            size = v->size;
        }
        if (!generation || !size) return VL_VAULTFMT_ERR_NOT_FOUND;
        const auto object = vf::manifest::parseUid(e->uid, "bad_segment", "entry uid");
        const auto salt = rd::saltOf(*generation);
        const vl_vaultfmt_expectation expect{VL_VAULTFMT_KIND_FILE_CONTENT, vault_uid, object.data(), salt.data()};
        return vl_vaultfmt_opener_new(header, header_len, &expect, ring, *size, out);
    });
}

}
