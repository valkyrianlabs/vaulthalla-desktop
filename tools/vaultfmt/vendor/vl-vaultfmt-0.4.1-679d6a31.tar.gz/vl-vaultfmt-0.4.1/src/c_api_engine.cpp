// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The engine's C API (include/vl/vaultfmt/vl_vaultfmt_engine.h) over engine::Session: the callback tables as the
// engine's store, keys and state, the handles, and the mapping of every exception to a status. No exception leaves an
// extern "C" function, and none crosses a callback (callbacks return statuses, which become the exceptions the library
// expects here).
#include "vl/vaultfmt/vl_vaultfmt_engine.h"

#include "vl/vaultfmt/engine/Session.hpp"
#include "vl/vaultfmt/manifest/Publisher.hpp"
#include "vl/vaultfmt/manifest/Reader.hpp"
#include "vl/vaultfmt/vhf1/Format.hpp"

#include <vl/keykit/secret.hpp>

#include <algorithm>
#include <cstring>
#include <memory>
#include <mutex>
#include <new>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace vf = vl::vaultfmt;
namespace en = vl::vaultfmt::engine;
namespace mf = vl::vaultfmt::manifest;

struct vl_vaultfmt_reply {
    std::vector<uint8_t> body;
    std::optional<std::string> etag;
    std::optional<std::string> version_id;
    std::optional<uint64_t> total;
    std::vector<mf::ListedObject> listed;
    std::vector<mf::StoredVersion> versions;
};

struct vl_vaultfmt_vault {
    std::unique_ptr<en::Session> engine;
    std::mutex error_mutex;
    std::string last_error;
};

struct vl_vaultfmt_listing {
    std::vector<mf::Entry> entries;
    std::vector<std::string> removed;
};

struct vl_vaultfmt_write {
    vl_vaultfmt_vault* vault{};
    std::unique_ptr<en::Writer> writer;
    bool done{false};
};

struct vl_vaultfmt_file_state {
    std::shared_ptr<en::FileStateBlob> blob;
};

namespace vl::vaultfmt::capi_engine {

namespace {

static_assert(VL_VAULTFMT_ERR_NOT_A_DIRECTORY == 620 + static_cast<int>(en::Refusal::NotADirectory) &&
              VL_VAULTFMT_ERR_BUSY == 620 + static_cast<int>(en::Refusal::Busy));

// A store callback's status other than the ones the manifest maps to its own exceptions.
struct StoreFailed : std::runtime_error {
    explicit StoreFailed(const vl_vaultfmt_status s)
        : std::runtime_error(std::string("a store callback failed: ") + vl_vaultfmt_status_name(s)) {}
};
// A keys callback failed (not "not held"), or a read's sink returned non-zero.
struct CallbackFailed : std::runtime_error {
    explicit CallbackFailed(const std::string& what) : std::runtime_error(what) {}
};
struct InvalidArgument {};

vl_vaultfmt_status statusOf(const std::exception_ptr& error, std::string& message) {
    try {
        std::rethrow_exception(error);
    } catch (const InvalidArgument&) {
        message = "invalid argument";
        return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    } catch (const std::exception& e) {
        message = e.what();
    } catch (...) {
        message = "unknown failure";
        return VL_VAULTFMT_ERR_INTERNAL;
    }
    try {
        std::rethrow_exception(error);
    } catch (const en::Refused& e) {
        return e.why() == en::Refusal::NotFound ? VL_VAULTFMT_ERR_NOT_FOUND
                                                : 620 + static_cast<vl_vaultfmt_status>(e.why());
    } catch (const en::StateFailed&) {
        return VL_VAULTFMT_ERR_STATE_FAILED;
    } catch (const en::StateTooNew&) {
        return VL_VAULTFMT_ERR_STATE_TOO_NEW;
    } catch (const en::StateOfAnotherVault&) {
        return VL_VAULTFMT_ERR_STATE_OTHER_VAULT;
    } catch (const en::ApplyStopped&) {
        return VL_VAULTFMT_ERR_APPLY_STOPPED;
    } catch (const mf::WriterFloorRefused&) {
        return VL_VAULTFMT_ERR_WRITER_FLOOR;
    } catch (const mf::WritersRefused&) {
        return VL_VAULTFMT_ERR_WRITERS_REFUSED;
    } catch (const mf::PublishConflict&) {
        return VL_VAULTFMT_ERR_PUBLISH_CONFLICT;
    } catch (const mf::PublishUnsettled&) {
        return VL_VAULTFMT_ERR_PUBLISH_UNSETTLED;
    } catch (const mf::PublishUnsupported&) {
        return VL_VAULTFMT_ERR_PUBLISH_UNSUPPORTED;
    } catch (const mf::NoUsableRoot&) {
        return VL_VAULTFMT_ERR_NO_USABLE_ROOT;
    } catch (const mf::PreconditionFailed&) {
        return VL_VAULTFMT_ERR_STORE_PRECONDITION_FAILED;
    } catch (const mf::ConditionsUnsupported&) {
        return VL_VAULTFMT_ERR_STORE_CONDITIONS_UNSUPPORTED;
    } catch (const mf::PutOutcomeUnknown&) {
        return VL_VAULTFMT_ERR_STORE_OUTCOME_UNKNOWN;
    } catch (const StoreFailed&) {
        return VL_VAULTFMT_ERR_STORE_FAILED;
    } catch (const CallbackFailed&) {
        return VL_VAULTFMT_ERR_CALLBACK_FAILED;
    } catch (const vhf1::Error& e) {
        return 100 + static_cast<vl_vaultfmt_status>(e.code());
    } catch (const mf::ChainRejected& e) {
        return 300 + static_cast<vl_vaultfmt_status>(e.code());
    } catch (const mf::FormatError& e) {
        if (e.code() == "bad_segment") return VL_VAULTFMT_ERR_MANIFEST_BAD_SEGMENT;
        if (e.code() == "bad_snapshot") return VL_VAULTFMT_ERR_MANIFEST_BAD_SNAPSHOT;
        return VL_VAULTFMT_ERR_MANIFEST_BAD_ROOT;
    } catch (const std::invalid_argument&) {
        return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    } catch (const std::bad_alloc&) {
        return VL_VAULTFMT_ERR_OUT_OF_MEMORY;
    } catch (...) {
        return VL_VAULTFMT_ERR_INTERNAL;
    }
}

// Runs `f`; a failure's message goes to `vault` (when there is one).
template <class F>
vl_vaultfmt_status guarded(vl_vaultfmt_vault* vault, F&& f) noexcept {
    try {
        return f();
    } catch (...) {
        std::string message;
        const auto status = statusOf(std::current_exception(), message);
        if (vault) {
            try {
                std::scoped_lock lock(vault->error_mutex);
                vault->last_error = std::move(message);
            } catch (...) {
            }
        }
        return status;
    }
}

std::string_view text(const char* p, const size_t n) {
    if (!p && n) throw InvalidArgument{};
    return {p ? p : "", n};
}

std::optional<std::string> optText(const char* p, const size_t n) {
    if (!p) return std::nullopt;
    return std::string(text(p, n));
}

vl_vaultfmt_status writeOut(const std::string_view bytes, char* out, size_t* outLen) {
    if (!outLen) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (*outLen < bytes.size() || (!out && !bytes.empty())) {
        *outLen = bytes.size();
        return VL_VAULTFMT_ERR_BUFFER_TOO_SMALL;
    }
    if (!bytes.empty()) std::memcpy(out, bytes.data(), bytes.size());
    *outLen = bytes.size();
    return VL_VAULTFMT_OK;
}

void copyHex(char (&out)[65], const std::string& hex) {
    std::memset(out, 0, sizeof out);
    std::memcpy(out, hex.data(), std::min<std::size_t>(hex.size(), 64));
}

const char* cstr(const std::optional<std::string>& s) { return s ? s->c_str() : nullptr; }

// ---- the store over its callback table ------------------------------------------------------------------------------

class CUpload final : public en::ContentUpload {
public:
    CUpload(const vl_vaultfmt_store_table& t, void* upload) : t_(t), upload_(upload) {}
    ~CUpload() override { abort(); }
    void write(const std::span<const uint8_t> bytes) override {
        if (const auto s = t_.content_write(t_.ctx, upload_, bytes.data(), bytes.size()); s != VL_VAULTFMT_OK) fail(s);
    }
    mf::PutResult finish() override {
        vl_vaultfmt_reply reply;
        const auto s = t_.content_finish(t_.ctx, upload_, &reply);
        upload_ = nullptr;   // finished (or failed): the callback owns nothing more
        if (s != VL_VAULTFMT_OK) fail(s);
        return {reply.etag.value_or(""), reply.version_id};
    }
    void abort() noexcept override {
        if (upload_ && t_.content_abort) t_.content_abort(t_.ctx, upload_);
        upload_ = nullptr;
    }

private:
    [[noreturn]] static void fail(const vl_vaultfmt_status s) {
        if (s == VL_VAULTFMT_ERR_STORE_OUTCOME_UNKNOWN) throw mf::PutOutcomeUnknown("the content upload's outcome is unknown");
        throw StoreFailed(s);
    }
    vl_vaultfmt_store_table t_;
    void* upload_;
};

class CStore final : public en::BucketStore {
public:
    explicit CStore(const vl_vaultfmt_store_table& t) : t_(t) {
        if (!t_.get || !t_.get_range || !t_.head || !t_.put || !t_.list || !t_.versions || !t_.remove ||
            !t_.content_begin || !t_.content_write || !t_.content_finish || !t_.content_abort)
            throw std::invalid_argument("the store table needs every callback");
        if (t_.mode != VL_VAULTFMT_MODE_CONDITIONAL && t_.mode != VL_VAULTFMT_MODE_VERSION_LOG)
            throw std::invalid_argument("the store table needs the vault's publish mode");
    }

    std::optional<mf::StoredObject> get(const std::string& key, const std::optional<std::string>& v) override {
        vl_vaultfmt_reply r;
        const auto s = t_.get(t_.ctx, key.data(), key.size(), v ? v->data() : nullptr, v ? v->size() : 0, &r);
        if (s == VL_VAULTFMT_ERR_NOT_FOUND) return std::nullopt;
        check(s);
        if (r.body.size() > mf::kMaxManifestObjectBytes) throw StoreFailed(VL_VAULTFMT_ERR_STORE_FAILED);
        return mf::StoredObject{std::move(r.body), std::move(r.etag), v ? v : r.version_id};
    }
    std::optional<std::vector<uint8_t>> getRange(const std::string& key, const uint64_t o, const uint64_t l) override {
        auto r = range(key, std::nullopt, o, l);
        if (!r) return std::nullopt;
        return std::move(r->bytes);
    }
    std::optional<std::string> headEtag(const std::string& key) override {
        vl_vaultfmt_reply r;
        if (t_.head(t_.ctx, key.data(), key.size(), &r) != VL_VAULTFMT_OK) return std::nullopt;   // then a GET decides
        return r.etag.value_or("");
    }
    std::string putIfAbsent(const std::string& key, const std::vector<uint8_t>& b) override {
        return putWith(key, b, VL_VAULTFMT_PUT_IF_ABSENT, {}).etag;
    }
    std::string putIfMatch(const std::string& key, const std::vector<uint8_t>& b, const std::string& e) override {
        return putWith(key, b, VL_VAULTFMT_PUT_IF_MATCH, e).etag;
    }
    mf::PutResult put(const std::string& key, const std::vector<uint8_t>& b) override {
        return putWith(key, b, VL_VAULTFMT_PUT_PLAIN, {});
    }
    std::vector<mf::ListedObject> list(const std::string& prefix) override {
        vl_vaultfmt_reply r;
        check(t_.list(t_.ctx, prefix.data(), prefix.size(), &r));
        return std::move(r.listed);
    }
    std::vector<mf::StoredVersion> versions(const std::string& key) override { return listVersions(key, std::nullopt, false); }
    std::vector<mf::StoredVersion> versionsSince(const std::string& key, const std::optional<std::string>& stopAt) override {
        auto all = listVersions(key, stopAt, false);
        if (stopAt)
            if (const auto it = std::ranges::find(all, *stopAt, &mf::StoredVersion::version_id); it != all.end())
                all.erase(it + 1, all.end());
        return all;
    }
    std::vector<mf::StoredVersion> versionsUnder(const std::string& prefix) override {
        return listVersions(prefix, std::nullopt, true);
    }
    void remove(const std::string& key) override {
        const auto s = t_.remove(t_.ctx, key.data(), key.size(), nullptr, 0);
        if (s != VL_VAULTFMT_ERR_NOT_FOUND) check(s);
    }
    void removeVersion(const std::string& key, const std::string& v) override {
        const auto s = t_.remove(t_.ctx, key.data(), key.size(), v.data(), v.size());
        if (s != VL_VAULTFMT_ERR_NOT_FOUND) check(s);
    }
    [[nodiscard]] mf::WriteCapability mode() const override {
        return t_.mode == VL_VAULTFMT_MODE_VERSION_LOG ? mf::WriteCapability::VersionLog : mf::WriteCapability::Conditional;
    }

    std::unique_ptr<en::ContentUpload> putContent(const std::string& key, const std::optional<uint64_t> size) override {
        void* upload = nullptr;
        check(t_.content_begin(t_.ctx, key.data(), key.size(), size.value_or(VL_VAULTFMT_SIZE_UNKNOWN), &upload));
        return std::make_unique<CUpload>(t_, upload);
    }
    std::optional<en::ContentRange> getContent(const std::string& key, const std::optional<std::string>& versionId,
                                               const uint64_t offset, const uint64_t length) override {
        return range(key, versionId, offset, length);
    }

private:
    static void check(const vl_vaultfmt_status s) {
        switch (s) {
        case VL_VAULTFMT_OK: return;
        case VL_VAULTFMT_ERR_STORE_PRECONDITION_FAILED: throw mf::PreconditionFailed("412 (store callback)");
        case VL_VAULTFMT_ERR_STORE_CONDITIONS_UNSUPPORTED:
            throw mf::ConditionsUnsupported("the bucket refused a condition (store callback)");
        case VL_VAULTFMT_ERR_STORE_OUTCOME_UNKNOWN: throw mf::PutOutcomeUnknown("the write's outcome is unknown (store callback)");
        default: throw StoreFailed(s);
        }
    }
    mf::PutResult putWith(const std::string& key, const std::vector<uint8_t>& b, const int32_t condition,
                          const std::string& ifMatch) {
        vl_vaultfmt_reply r;
        check(t_.put(t_.ctx, key.data(), key.size(), b.data(), b.size(), condition,
                     condition == VL_VAULTFMT_PUT_IF_MATCH ? ifMatch.data() : nullptr,
                     condition == VL_VAULTFMT_PUT_IF_MATCH ? ifMatch.size() : 0, &r));
        return {r.etag.value_or(""), r.version_id};
    }
    std::vector<mf::StoredVersion> listVersions(const std::string& key, const std::optional<std::string>& stopAt,
                                                const bool under) {
        vl_vaultfmt_reply r;
        check(t_.versions(t_.ctx, key.data(), key.size(), stopAt ? stopAt->data() : nullptr, stopAt ? stopAt->size() : 0,
                          under ? 1 : 0, &r));
        return std::move(r.versions);
    }
    std::optional<en::ContentRange> range(const std::string& key, const std::optional<std::string>& v,
                                          const uint64_t offset, const uint64_t length) {
        vl_vaultfmt_reply r;
        const auto s = t_.get_range(t_.ctx, key.data(), key.size(), v ? v->data() : nullptr, v ? v->size() : 0, offset,
                                    length, &r);
        if (s == VL_VAULTFMT_ERR_NOT_FOUND) return std::nullopt;
        check(s);
        if (r.body.size() > length) throw StoreFailed(VL_VAULTFMT_ERR_STORE_FAILED);
        return en::ContentRange{std::move(r.body), r.total.value_or(offset + r.body.size())};
    }

    vl_vaultfmt_store_table t_;
};

class CState final : public en::StateBlob {
public:
    explicit CState(const vl_vaultfmt_state_table& t) : t_(t) {
        if (!t_.load || !t_.save) throw std::invalid_argument("the state table needs load and save");
    }
    std::optional<std::vector<uint8_t>> load() override {
        vl_vaultfmt_reply r;
        const auto s = t_.load(t_.ctx, &r);
        if (s == VL_VAULTFMT_ERR_NOT_FOUND) return std::nullopt;
        if (s != VL_VAULTFMT_OK) throw en::StateFailed(std::string("the state callback failed to load: ") + vl_vaultfmt_status_name(s));
        return std::move(r.body);
    }
    void save(const std::span<const uint8_t> bytes) override {
        if (const auto s = t_.save(t_.ctx, bytes.data(), bytes.size()); s != VL_VAULTFMT_OK)
            throw en::StateFailed(std::string("the state callback failed to save: ") + vl_vaultfmt_status_name(s));
    }
    bool append(const std::span<const uint8_t> bytes) override {
        if (!t_.append) return false;
        if (const auto s = t_.append(t_.ctx, bytes.data(), bytes.size()); s != VL_VAULTFMT_OK)
            throw en::StateFailed(std::string("the state callback failed to append: ") + vl_vaultfmt_status_name(s));
        return true;
    }

private:
    vl_vaultfmt_state_table t_;
};

en::Keys keysOf(const vl_vaultfmt_keys_table& t) {
    if (!t.lookup || !t.current) throw std::invalid_argument("the keys table needs lookup and current");
    return {[t](const uint32_t version) -> vhf1::KeyPtr {
                uint8_t key[32] = {};
                const auto s = t.lookup(t.ctx, version, key);
                std::shared_ptr<const vhf1::Key> out;
                try {
                    if (s == VL_VAULTFMT_OK) out = std::make_shared<const vhf1::Key>(std::span<const uint8_t>(key, 32));
                } catch (...) {
                    vl::keykit::wipe(std::span<uint8_t>(key, 32));
                    throw;
                }
                vl::keykit::wipe(std::span<uint8_t>(key, 32));
                if (s == VL_VAULTFMT_OK) return out;
                if (s == VL_VAULTFMT_ERR_NOT_FOUND) return nullptr;
                throw CallbackFailed(std::string("the keys callback failed: ") + vl_vaultfmt_status_name(s));
            },
            [t] {
                uint32_t v = 0;
                if (const auto s = t.current(t.ctx, &v); s != VL_VAULTFMT_OK)
                    throw CallbackFailed(std::string("the keys callback failed: ") + vl_vaultfmt_status_name(s));
                return v;
            }};
}

vl_vaultfmt_entry entryOf(const mf::Entry& e) {
    vl_vaultfmt_entry r{};
    r.uid = e.uid.c_str();
    r.kind = static_cast<int32_t>(e.kind);
    r.parent = cstr(e.parent);
    r.name = e.name.c_str();
    r.name_len = e.name.size();
    r.trashed = e.trashed ? 1 : 0;
    r.has_size = e.size ? 1 : 0;
    r.size = e.size.value_or(0);
    r.mode = e.mode.value_or(0);
    r.key_version = e.key_version.value_or(0);
    r.mtime = cstr(e.mtime);
    r.generation = cstr(e.generation);
    r.target = cstr(e.target);
    r.has_object = e.object ? 1 : 0;
    r.object_size = e.object ? e.object->size : 0;
    r.version_id = e.object ? cstr(e.object->version_id) : nullptr;
    return r;
}

vl_vaultfmt_listing* listingOf(std::vector<mf::Entry> entries) {
    auto l = std::make_unique<vl_vaultfmt_listing>();
    l->entries = std::move(entries);
    return l.release();
}

en::Session& engineOf(vl_vaultfmt_vault* vault) {
    if (!vault || !vault->engine) throw InvalidArgument{};
    return *vault->engine;
}

}

}

namespace ce = vl::vaultfmt::capi_engine;

extern "C" {

// ---- replies --------------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_reply_body(vl_vaultfmt_reply* reply, const uint8_t* bytes, const size_t len) {
    if (!reply || (!bytes && len)) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return ce::guarded(nullptr, [&] {
        reply->body.insert(reply->body.end(), bytes, bytes + len);
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_reply_etag(vl_vaultfmt_reply* reply, const char* etag, const size_t len) {
    if (!reply) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return ce::guarded(nullptr, [&] {
        reply->etag = std::string(ce::text(etag, len));
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_reply_version_id(vl_vaultfmt_reply* reply, const char* version_id, const size_t len) {
    if (!reply) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return ce::guarded(nullptr, [&] {
        reply->version_id = std::string(ce::text(version_id, len));
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_reply_total(vl_vaultfmt_reply* reply, const uint64_t total) {
    if (!reply) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    reply->total = total;
    return VL_VAULTFMT_OK;
}

vl_vaultfmt_status vl_vaultfmt_reply_listed(vl_vaultfmt_reply* reply, const char* key, const size_t key_len,
                                            const uint64_t size, const int64_t last_modified, const char* etag,
                                            const size_t etag_len) {
    if (!reply) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return ce::guarded(nullptr, [&] {
        mf::ListedObject o;
        o.key = std::string(ce::text(key, key_len));
        o.size = size;
        if (last_modified != VL_VAULTFMT_TIME_UNKNOWN) o.last_modified = static_cast<std::time_t>(last_modified);
        o.etag = ce::optText(etag, etag_len);
        reply->listed.push_back(std::move(o));
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_reply_version(vl_vaultfmt_reply* reply, const char* key, const size_t key_len,
                                             const char* version_id, const size_t version_id_len, const uint64_t size,
                                             const int64_t last_modified, const int32_t delete_marker, const char* etag,
                                             const size_t etag_len, const int32_t is_latest) {
    if (!reply) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return ce::guarded(nullptr, [&] {
        mf::StoredVersion v;
        v.key = std::string(ce::text(key, key_len));
        v.version_id = std::string(ce::text(version_id, version_id_len));
        v.size = size;
        if (last_modified != VL_VAULTFMT_TIME_UNKNOWN) v.last_modified = static_cast<std::time_t>(last_modified);
        v.delete_marker = delete_marker != 0;
        v.etag = std::string(ce::text(etag, etag_len));
        v.is_latest = is_latest != 0;
        reply->versions.push_back(std::move(v));
        return VL_VAULTFMT_OK;
    });
}

// ---- the file state -------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_file_state_new(const char* path, const size_t path_len, vl_vaultfmt_file_state** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    if (!path || path_len == 0) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return ce::guarded(nullptr, [&] {
        auto s = std::make_unique<vl_vaultfmt_file_state>();
        s->blob = std::make_shared<en::FileStateBlob>(std::string(path, path_len));
        *out = s.release();
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_file_state_table(vl_vaultfmt_file_state* state, vl_vaultfmt_state_table* out) {
    if (!state || !out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = {};
    out->ctx = state;
    out->load = [](void* ctx, vl_vaultfmt_reply* reply) -> vl_vaultfmt_status {
        return ce::guarded(nullptr, [&] {
            auto bytes = static_cast<vl_vaultfmt_file_state*>(ctx)->blob->load();
            if (!bytes) return VL_VAULTFMT_ERR_NOT_FOUND;
            reply->body = std::move(*bytes);
            return VL_VAULTFMT_OK;
        });
    };
    out->save = [](void* ctx, const uint8_t* bytes, const size_t len) -> vl_vaultfmt_status {
        return ce::guarded(nullptr, [&] {
            static_cast<vl_vaultfmt_file_state*>(ctx)->blob->save({bytes, len});
            return VL_VAULTFMT_OK;
        });
    };
    out->append = [](void* ctx, const uint8_t* bytes, const size_t len) -> vl_vaultfmt_status {
        return ce::guarded(nullptr, [&] {
            (void)static_cast<vl_vaultfmt_file_state*>(ctx)->blob->append({bytes, len});
            return VL_VAULTFMT_OK;
        });
    };
    return VL_VAULTFMT_OK;
}

void vl_vaultfmt_file_state_free(vl_vaultfmt_file_state* state) { delete state; }

// ---- opening ------------------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_vault_open(const uint8_t vault_uid[16], const vl_vaultfmt_store_table* store,
                                          const vl_vaultfmt_keys_table* keys, const vl_vaultfmt_state_table* state,
                                          const vl_vaultfmt_vault_options* options, vl_vaultfmt_open_info* info,
                                          vl_vaultfmt_vault** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    if (info) *info = {};
    if (!vault_uid || !store || !keys || !state || !options || !options->node_id || options->node_id_len == 0)
        return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    auto vault = std::make_unique<vl_vaultfmt_vault>();
    const auto status = ce::guarded(vault.get(), [&] {
        mf::Uid uid{};
        std::memcpy(uid.data(), vault_uid, uid.size());
        en::Options o;
        o.node_id = std::string(ce::text(options->node_id, options->node_id_len));
        if (options->software) o.software = std::string(ce::text(options->software, options->software_len));
        o.create_name = ce::optText(options->create_name, options->create_name_len);
        o.recover_unnamed = options->skip_recovery == 0;
        if (options->now)
            o.now = [fn = options->now, ctx = options->now_ctx] { return static_cast<std::time_t>(fn(ctx)); };
        en::OpenReport report;
        vault->engine = en::Session::open(uid, std::make_shared<ce::CStore>(*store), ce::keysOf(*keys),
                                          std::make_shared<ce::CState>(*state), std::move(o), &report);
        if (info) {
            info->anchor = static_cast<int32_t>(report.anchor);
            info->state = static_cast<int32_t>(report.state.condition);
            info->torn_tail = report.state.torn_tail ? 1 : 0;
            info->journal_truncated = report.state.journal_truncated ? 1 : 0;
            info->freshness_verified = report.freshness == mf::Freshness::Verified ? 1 : 0;
            info->recovered = report.recovered;
            if (report.known) {
                info->has_known = 1;
                info->epoch = report.known->epoch;
                ce::copyHex(info->root_sha256, report.known->root_sha256);
            }
        }
        return VL_VAULTFMT_OK;
    });
    if (status != VL_VAULTFMT_OK) {
        if (info) {
            const auto n = std::min(vault->last_error.size(), sizeof info->message - 1);
            std::memcpy(info->message, vault->last_error.data(), n);
            info->message[n] = '\0';
        }
        return status;
    }
    *out = vault.release();
    return VL_VAULTFMT_OK;
}

vl_vaultfmt_status vl_vaultfmt_vault_last_error(vl_vaultfmt_vault* vault, char* out, size_t* out_len) {
    if (!vault) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return ce::guarded(nullptr, [&] {
        std::scoped_lock lock(vault->error_mutex);
        return ce::writeOut(vault->last_error, out, out_len);
    });
}

void vl_vaultfmt_vault_free(vl_vaultfmt_vault* vault) { delete vault; }

// ---- listings -----------------------------------------------------------------------------------------------------------

size_t vl_vaultfmt_listing_count(const vl_vaultfmt_listing* listing) { return listing ? listing->entries.size() : 0; }

vl_vaultfmt_status vl_vaultfmt_listing_entry(const vl_vaultfmt_listing* listing, const size_t index,
                                             vl_vaultfmt_entry* out) {
    if (!listing || !out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (index >= listing->entries.size()) return VL_VAULTFMT_ERR_NOT_FOUND;
    *out = ce::entryOf(listing->entries[index]);
    return VL_VAULTFMT_OK;
}

size_t vl_vaultfmt_listing_version_count(const vl_vaultfmt_listing* listing, const size_t entry) {
    return listing && entry < listing->entries.size() ? listing->entries[entry].versions.size() : 0;
}

vl_vaultfmt_status vl_vaultfmt_listing_version(const vl_vaultfmt_listing* listing, const size_t entry, const size_t index,
                                               vl_vaultfmt_file_version* out) {
    if (!listing || !out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (entry >= listing->entries.size() || index >= listing->entries[entry].versions.size())
        return VL_VAULTFMT_ERR_NOT_FOUND;
    const auto& v = listing->entries[entry].versions[index];
    vl_vaultfmt_file_version r{};
    r.version_id = v.version_id.c_str();
    r.generation = ce::cstr(v.generation);
    r.key_version = v.key_version.value_or(0);
    r.size = v.size.value_or(0);
    r.last_modified = ce::cstr(v.last_modified);
    r.noncurrent_at = ce::cstr(v.noncurrent_at);
    r.delete_marker = v.delete_marker ? 1 : 0;
    *out = r;
    return VL_VAULTFMT_OK;
}

size_t vl_vaultfmt_listing_removed_count(const vl_vaultfmt_listing* listing) {
    return listing ? listing->removed.size() : 0;
}

vl_vaultfmt_status vl_vaultfmt_listing_removed(const vl_vaultfmt_listing* listing, const size_t index, const char** uid) {
    if (!listing || !uid) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (index >= listing->removed.size()) return VL_VAULTFMT_ERR_NOT_FOUND;
    *uid = listing->removed[index].c_str();
    return VL_VAULTFMT_OK;
}

void vl_vaultfmt_listing_free(vl_vaultfmt_listing* listing) { delete listing; }

// ---- reading ------------------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_vault_root(vl_vaultfmt_vault* vault, char* out, size_t* out_len) {
    return ce::guarded(vault, [&] { return ce::writeOut(ce::engineOf(vault).rootUid(), out, out_len); });
}

vl_vaultfmt_status vl_vaultfmt_vault_list(vl_vaultfmt_vault* vault, const char* dir_uid, const size_t dir_uid_len,
                                          vl_vaultfmt_listing** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    return ce::guarded(vault, [&] {
        *out = ce::listingOf(ce::engineOf(vault).list(std::string(ce::text(dir_uid, dir_uid_len))));
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_stat(vl_vaultfmt_vault* vault, const char* uid, const size_t uid_len,
                                          vl_vaultfmt_listing** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    return ce::guarded(vault, [&] {
        auto e = ce::engineOf(vault).stat(std::string(ce::text(uid, uid_len)));
        if (!e) return VL_VAULTFMT_ERR_NOT_FOUND;
        *out = ce::listingOf({std::move(*e)});
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_trash(vl_vaultfmt_vault* vault, vl_vaultfmt_listing** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    return ce::guarded(vault, [&] {
        *out = ce::listingOf(ce::engineOf(vault).trash());
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_changes(vl_vaultfmt_vault* vault, const uint64_t generation, const uint64_t after,
                                             vl_vaultfmt_changes_info* info, vl_vaultfmt_listing** out) {
    if (!out || !info) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    *info = {};
    return ce::guarded(vault, [&] {
        auto& e = ce::engineOf(vault);
        const auto c = e.changes(generation, after);
        info->generation = c.generation;
        info->revision = c.revision;
        info->expired = c.expired ? 1 : 0;
        auto l = std::make_unique<vl_vaultfmt_listing>();
        for (const auto& uid : c.changed)
            if (auto x = e.stat(uid)) l->entries.push_back(std::move(*x));
            else l->removed.push_back(uid);
        l->removed.insert(l->removed.end(), c.removed.begin(), c.removed.end());
        *out = l.release();
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_read(vl_vaultfmt_vault* vault, const char* uid, const size_t uid_len,
                                          const char* version_id, const size_t version_id_len, const uint64_t offset,
                                          const uint64_t length, const vl_vaultfmt_sink_fn sink, void* ctx) {
    if (!sink) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return ce::guarded(vault, [&] {
        ce::engineOf(vault).read(std::string(ce::text(uid, uid_len)), ce::optText(version_id, version_id_len), offset,
                                 length, [&](const std::span<const uint8_t> bytes) {
                                     if (sink(ctx, bytes.data(), bytes.size()) != 0)
                                         throw ce::CallbackFailed("the read's sink returned non-zero");
                                 });
        return VL_VAULTFMT_OK;
    });
}

// ---- writing ------------------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_write_begin(vl_vaultfmt_vault* vault, const char* parent_uid, const size_t parent_uid_len,
                                           const char* name, const size_t name_len, const char* uid, const size_t uid_len,
                                           const char* expected_generation, const size_t expected_generation_len,
                                           const uint64_t size, vl_vaultfmt_write** out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = nullptr;
    return ce::guarded(vault, [&] {
        auto w = std::make_unique<vl_vaultfmt_write>();
        w->vault = vault;
        w->writer = ce::engineOf(vault).writeBegin(
            std::string(ce::text(parent_uid, parent_uid_len)), std::string(ce::text(name, name_len)),
            ce::optText(uid, uid_len), ce::optText(expected_generation, expected_generation_len),
            size == VL_VAULTFMT_SIZE_UNKNOWN ? std::nullopt : std::optional<uint64_t>(size));
        *out = w.release();
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_write_chunk(vl_vaultfmt_write* write, const uint8_t* plaintext, const size_t len) {
    if (!write || (!plaintext && len)) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (write->done) return VL_VAULTFMT_ERR_UNUSABLE;
    const auto s = ce::guarded(write->vault, [&] {
        write->writer->write({plaintext, len});
        return VL_VAULTFMT_OK;
    });
    if (s != VL_VAULTFMT_OK) write->done = true;
    return s;
}

vl_vaultfmt_status vl_vaultfmt_write_finish(vl_vaultfmt_write* write, int32_t* conflict, vl_vaultfmt_listing** entry) {
    if (!write) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    if (entry) *entry = nullptr;
    if (write->done) return VL_VAULTFMT_ERR_UNUSABLE;
    write->done = true;
    return ce::guarded(write->vault, [&] {
        auto r = write->writer->finish();
        if (conflict) *conflict = r.conflict ? 1 : 0;
        if (entry) *entry = ce::listingOf({std::move(r.entry)});
        return VL_VAULTFMT_OK;
    });
}

void vl_vaultfmt_write_free(vl_vaultfmt_write* write) { delete write; }

// ---- tree changes -------------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_vault_mkdir(vl_vaultfmt_vault* vault, const char* parent_uid, const size_t parent_uid_len,
                                           const char* name, const size_t name_len, vl_vaultfmt_listing** entry) {
    if (entry) *entry = nullptr;
    return ce::guarded(vault, [&] {
        auto e = ce::engineOf(vault).mkdir(std::string(ce::text(parent_uid, parent_uid_len)),
                                           std::string(ce::text(name, name_len)));
        if (entry) *entry = ce::listingOf({std::move(e)});
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_rename(vl_vaultfmt_vault* vault, const char* uid, const size_t uid_len,
                                            const char* name, const size_t name_len) {
    return ce::guarded(vault, [&] {
        (void)ce::engineOf(vault).rename(std::string(ce::text(uid, uid_len)), std::string(ce::text(name, name_len)));
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_move(vl_vaultfmt_vault* vault, const char* uid, const size_t uid_len,
                                          const char* parent_uid, const size_t parent_uid_len, const char* name,
                                          const size_t name_len) {
    return ce::guarded(vault, [&] {
        (void)ce::engineOf(vault).move(std::string(ce::text(uid, uid_len)),
                                       std::string(ce::text(parent_uid, parent_uid_len)), ce::optText(name, name_len));
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_trash_entry(vl_vaultfmt_vault* vault, const char* uid, const size_t uid_len) {
    return ce::guarded(vault, [&] {
        ce::engineOf(vault).trash(std::string(ce::text(uid, uid_len)));
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_restore(vl_vaultfmt_vault* vault, const char* uid, const size_t uid_len,
                                             const char* parent_uid, const size_t parent_uid_len, const char* name,
                                             const size_t name_len) {
    return ce::guarded(vault, [&] {
        (void)ce::engineOf(vault).restore(std::string(ce::text(uid, uid_len)), ce::optText(parent_uid, parent_uid_len),
                                          ce::optText(name, name_len));
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_purge(vl_vaultfmt_vault* vault, const char* uid, const size_t uid_len) {
    return ce::guarded(vault, [&] {
        ce::engineOf(vault).purge(std::string(ce::text(uid, uid_len)));
        return VL_VAULTFMT_OK;
    });
}

// ---- keys ---------------------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_vault_key_add(vl_vaultfmt_vault* vault, const uint32_t version, const uint8_t* key,
                                             const size_t key_len, const vl_vaultfmt_bytes* envelopes,
                                             const size_t envelope_count, const char* key_check,
                                             const size_t key_check_len) {
    if (!key || key_len != VL_VAULTFMT_KEY_SIZE || (!envelopes && envelope_count)) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    return ce::guarded(vault, [&] {
        std::vector<std::vector<uint8_t>> envs;
        for (size_t i = 0; i < envelope_count; ++i) {
            if (!envelopes[i].bytes && envelopes[i].len) throw ce::InvalidArgument{};
            envs.emplace_back(envelopes[i].bytes, envelopes[i].bytes + envelopes[i].len);
        }
        ce::engineOf(vault).keyAdd(version, {key, key_len}, envs, ce::optText(key_check, key_check_len));
        return VL_VAULTFMT_OK;
    });
}

// ---- the bucket ---------------------------------------------------------------------------------------------------------

vl_vaultfmt_status vl_vaultfmt_vault_refresh(vl_vaultfmt_vault* vault, vl_vaultfmt_refresh_info* info) {
    if (info) *info = {};
    return ce::guarded(vault, [&] {
        const auto r = ce::engineOf(vault).refresh();
        if (info) {
            info->moved = r.moved ? 1 : 0;
            info->applied = r.applied ? 1 : 0;
            info->adopted = r.adopted ? 1 : 0;
            info->root_missing = r.root_missing ? 1 : 0;
            info->union_base = r.union_base ? 1 : 0;
            if (r.known) {
                info->epoch = r.known->epoch;
                ce::copyHex(info->root_sha256, r.known->root_sha256);
            }
            info->changed = r.changed;
            info->conflicts = r.conflicts.size();
            info->content_conflicts = static_cast<uint64_t>(std::ranges::count_if(
                r.conflicts, [](const mf::Conflict& c) { return c.kind == mf::ConflictKind::ContentEditEdit; }));
        }
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_publish(vl_vaultfmt_vault* vault, vl_vaultfmt_publish_info* info) {
    if (info) *info = {};
    return ce::guarded(vault, [&] {
        const auto r = ce::engineOf(vault).publish();
        if (info) {
            info->published = r.published ? 1 : 0;
            info->epoch = r.known.epoch;
            ce::copyHex(info->root_sha256, r.known.root_sha256);
            info->rounds = r.rounds;
            info->segments_written = r.segments_written;
            info->segments_reused = r.segments_reused;
            info->purged = r.purged;
        }
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_gc_if_due(vl_vaultfmt_vault* vault, const int64_t now, vl_vaultfmt_gc_info* info) {
    if (info) *info = {};
    return ce::guarded(vault, [&] {
        const auto r = ce::engineOf(vault).gcIfDue(static_cast<std::time_t>(now));
        if (info && r) {
            info->ran = 1;
            info->deleted = r->deleted.size();
            info->retained = r->retained;
            info->young = r->young;
        }
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_join(vl_vaultfmt_vault* vault) {
    return ce::guarded(vault, [&] {
        ce::engineOf(vault).join();
        return VL_VAULTFMT_OK;
    });
}

vl_vaultfmt_status vl_vaultfmt_vault_status_get(vl_vaultfmt_vault* vault, vl_vaultfmt_vault_status* out) {
    if (!out) return VL_VAULTFMT_ERR_INVALID_ARGUMENT;
    *out = {};
    return ce::guarded(vault, [&] {
        const auto s = ce::engineOf(vault).status();
        if (s.known) {
            out->has_known = 1;
            out->epoch = s.known->epoch;
            ce::copyHex(out->root_sha256, s.known->root_sha256);
        }
        if (s.refused) {
            out->refused = 1;
            const auto n = std::min(s.refused->size(), sizeof out->refused_reason - 1);
            std::memcpy(out->refused_reason, s.refused->data(), n);
        }
        out->update_needed = s.update_needed ? 1 : 0;
        out->unpublished = s.unpublished ? 1 : 0;
        out->generation = s.generation;
        out->revision = s.revision;
        out->pending_purges = s.pending_purges;
        return VL_VAULTFMT_OK;
    });
}

}
