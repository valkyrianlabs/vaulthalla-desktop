// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// What one C API source needs of the handles another defines (c_api.cpp defines vl_vaultfmt_keyring and
// vl_vaultfmt_tree). Not installed: no C++ type crosses the C API.

#include "vl/vaultfmt/vl_vaultfmt.h"

#include "vl/vaultfmt/manifest/Content.hpp"
#include "vl/vaultfmt/vhf1/Format.hpp"

namespace vl::vaultfmt::capi {

// The ring's keys, valid while the ring lives and isn't being added to.
[[nodiscard]] vhf1::KeyLookup keyLookupOf(const vl_vaultfmt_keyring& ring);
[[nodiscard]] const manifest::Content& treeContent(const vl_vaultfmt_tree& tree);

}
