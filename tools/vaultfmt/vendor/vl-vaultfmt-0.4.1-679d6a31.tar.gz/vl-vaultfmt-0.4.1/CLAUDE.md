# vl-vaultfmt

Vaulthalla's vault format (VHF1 files, the object keys of an opaque_v1 bucket, the encrypted manifest with its publish,
read, reconcile and session logic) for C++23, extracted from vaulthalla-server and shared by vaulthalla-server, the
Desktop-only engine (through the C API) and the portal's WebAssembly reader. Owner: **Valkyrian Labs LLC**. License:
**AGPL-3.0-or-later** (`Copyright (c) 2026 Valkyrian Labs LLC`). Repository: `valkyrianlabs/vl-vaultfmt` (private).
Design: vaulthalla-server `design/core/vault-format-library.md`.

## Map

| Path | What |
| --- | --- |
| `include/vl/vaultfmt/` | public headers: `vhf1/` (`Format`, `Reader`, `Writer`, `Key`, `Aead`), `ObjectKeys`, `manifest/` (`Document`, `Content`, `Partition`, `Objects`, `Chain`, `VersionLog`, `Reader`, `Publisher`, `Reconcile`, `Session`, `Store`, `WriteCapability`), `Fwd`, umbrella `vaultfmt.hpp`; `vl_vaultfmt.h`: the C API (plain C11); `testing/`: header-only test doubles (`memory_store`, `hooked_store`) |
| `include/vl/vaultfmt/engine/` | the database-free engine: `Session`, `State` (`StateFile`, `FileStateBlob`), `Store` (`BucketStore`); `vl_vaultfmt_engine.h` its C API; `docs/engine.md` (state format, invariants, guarantees, writer floor) |
| `src/` | implementation; `c_api.cpp` (the C API over the C++ one), `c_api_reader.cpp` (the reader's), `c_api_engine.cpp` (the engine's), `engine/` |
| `tests/` | GoogleTest suite: `test_vhf1` and `test_manifest` against `vectors/vectors.json`, `test_manifest_reconcile`, `test_manifest_interleavings` (the version_log protocol under every interleaving and fault, on the in-memory store), `test_object_keys`, `test_c_api` and `c_header_check.c` (compiled as C), `test_c_api_reader`, `test_manifest_protocol` (the publish protocol on the memory store, `fake_bucket.hpp`), `test_writer_floor`; `vl-vaultfmt-engine-tests`: `test_engine`, `test_engine_state`, `test_c_engine` with `c_engine_lifecycle.c` (compiled as C); `vectors_contract.py` |
| `fuzz/` | the libFuzzer targets `fuzz_vhf1` and `fuzz_reader` (`-Dfuzz=true`, clang) |
| `wasm/` | the WebAssembly reader: the committed `vl-vaultfmt-reader.wasm` and its checksum, `build.sh` (pinned image and sources, byte for byte), `reader.ts` (the binding the portal copies), Node tests; `wasm/README.md` |
| `vectors/` | `vectors.json` and `vh_crypto_vectors.py`: verbatim copy of vaulthalla-server `design/encryption/vectors/` |
| `subprojects/` | `vl-keykit.wrap` with its release tarball (and the 0.2.0 unity patch) for standalone builds |
| `ci/` | `run-ci` (verbatim from vaulthalla-server), `Containerfile` |
| `scripts/`, `tests/apple/` | `build-xcframework.sh` (VLVaultfmt.xcframework) and its Swift check (`run.sh`; macOS only) |

## Commands

```bash
meson setup build -Db_sanitize=address,undefined && meson compile -C build && meson test -C build --print-errorlogs
# macOS: PKG_CONFIG_PATH=$(brew --prefix openssl@3)/lib/pkgconfig:/opt/homebrew/lib/pkgconfig:/opt/homebrew/share/pkgconfig meson setup build-mac
CI_CACHE_NAMES=ccache ./ci/run-ci meson test -C build   # the CI container (Podman); run it on `ssh dev`
CXX=clang++-18 meson setup build-fuzz -Dfuzz=true -Db_sanitize=address,undefined -Db_lundef=false && meson compile -C build-fuzz
wasm/build.sh && wasm/build.sh --test      # the wasm reader rebuilt and compared, then its Node tests (run on `ssh dev`)
```

## Rules

- **Licensing.** AGPL-3.0-or-later. Every source file (C++, meson, scripts, workflows) starts with
  `// SPDX-License-Identifier: AGPL-3.0-or-later` (or `#`) and `Copyright (c) 2026 Valkyrian Labs LLC`; `vectors/` is a
  verbatim copy and keeps the upstream bytes. The LLC owns all of it and uses it in its closed products by that
  ownership, so an outside contribution needs a copyright assignment or contributor agreement. Never import
  third-party code.
- **Scope.** Namespace `vl::vaultfmt` (`vhf1`, `keys`, `manifest`, `test_support`, `capi`). Dependencies: OpenSSL 3,
  nlohmann_json and vl-keykit only. No libsodium, fmt, Boost, logging, database, HTTP client or POSIX I/O: time, sleep,
  alerts and storage reach the library through its parameters and interfaces (`PublishOptions`, `SessionHost`,
  `StateStore`, `ObjectStore`, the engine's `BucketStore` and `StateBlob`). One exception: `src/engine/FileStateBlob.cpp`,
  the reference state file, does POSIX file I/O (open, write, `F_FULLFSYNC`, rename); nothing else does. The only global
  is the test chunk-wipe observer.
- **Formats are frozen by the vectors.** Output must stay byte-for-byte equal to `vectors/vectors.json`. Decision 2 of
  the design: a VHF1 or manifest format change lands here with its vectors (and vaulthalla-server's spec) in one
  change, then every consumer's identical-copy test (vaulthalla-server, vl-keykit, Desktop) takes the new copy. Never
  edit an expected vector to get green.
- **Readers ignore unknown members; writers rebuild from typed structs.** An older writer republishing would drop a
  newer writer's members, so the root's `writer_floor` binds every writer (`docs/engine.md`, "The writer floor"): a new
  member that a writer must round-trip comes with a new writer revision (a constant beside `kBaselineWriterRevision`),
  vectors in `vectors/writer_floor.json`, and writers that need it write the floor. Never lower a floor.
- **The engine's state format is versioned** (`StateFile::kFormatVersion`, `docs/engine.md`): a change to the blob's
  layout or members bumps it, and an engine never reads or overwrites a newer state.
- **Secrets.** Keys are `vhf1::Key` (locked, wiped); plaintext buffers are `SecureBytes`; temporaries are wiped on
  every path; comparisons of secret-dependent bytes are constant time. Never log or put a secret in an exception.
- **The C API is stable.** `vl_vaultfmt.h` is plain C: no C++ type, exception or allocation crosses it. Status values
  are never renumbered or reused (100 + `vhf1::ErrorCode`, 300 + `manifest::ChainError`: new C++ codes are only
  appended, and the header and `kStatusNames` gain them in the same change; `test_c_api.cpp` checks every name). Keys
  stay in the keyring; plaintext leaves only through a sink after its chunk authenticated.
- **The wasm artifact follows the source.** A change to what `wasm/build-in-container.sh` compiles is committed with
  `wasm/build.sh --record` (the CI job fails on a stale artifact); a C API function the reader needs goes in
  `wasm/exports.txt` and `wasm/reader.ts` too. Nothing that seals, publishes or deletes is exported.
- **Builds are silent.** Zero warnings on GCC 14 and clang at `warning_level=3`, unity on (one unit) and off; fix
  causes, never suppress.
- **Tests with every change**, positive vectors and the negative path; the suite passes under ASan/UBSan.
- **Git.** Changes land on `main` through PRs and CI. Tags and releases (`vX.Y.Z`, the tarball consumers pin) only
  with Cooper's go-ahead. Keep `ci/run-ci` identical to vaulthalla-server's.
