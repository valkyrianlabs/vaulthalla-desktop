// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
// The engine's state blob (include/vl/vaultfmt/engine/State.hpp; docs/engine.md "The state file"): the reference file
// blob, the record format (checksums, torn and truncated tails, versions), journalling and compaction, and the
// StateStore rules the server keeps in PostgreSQL (db::query::sync::Manifest), kept the same here.

#include "engine_support.hpp"

#include <gtest/gtest.h>

#include <filesystem>
#include <fstream>

namespace vl::vaultfmt::test_engine_state {

using namespace test_engine_support;

namespace {

mf::Uid vaultUid() {
    mf::Uid u{};
    u.fill(0x5a);
    return u;
}

// A record with what the test names (RootRecord has no member defaults for everything: designated initializers would
// leave GCC's -Wmissing-field-initializers to complain).
mf::RootRecord rec(const uint64_t epoch, const std::string& sha, std::vector<std::string> sids = {}, const bool own = false,
                   std::optional<mf::BaseCopy> base = std::nullopt, std::vector<std::string> writers = {}) {
    mf::RootRecord r;
    r.epoch = epoch;
    r.root_sha256 = sha;
    r.sids = std::move(sids);
    r.own = own;
    r.base = std::move(base);
    r.writers = std::move(writers);
    return r;
}

mf::Entry dir(const std::string& uid, const std::optional<std::string>& parent, const std::string& name) {
    mf::Entry e;
    e.uid = uid;
    e.kind = mf::EntryKind::Dir;
    e.parent = parent;
    e.name = name;
    e.mode = 0755;
    return e;
}

std::string uidOf(const uint8_t b) {
    mf::Uid u{};
    u.fill(b);
    return mf::uidText(u);
}

struct Fixture {
    std::shared_ptr<test_support::MemoryStateBlob> blob;
    std::unique_ptr<en::StateFile> state;
    explicit Fixture(const bool appendable = true, const std::size_t compact = 256)
        : blob(std::make_shared<test_support::MemoryStateBlob>(appendable)),
          state(std::make_unique<en::StateFile>(blob, vaultUid(), [] { return std::time_t{1'800'000'000}; }, compact)) {
        mf::Content c;
        c.entries.push_back(dir(uidOf(0x01), std::nullopt, ""));
        state->reset(c, std::nullopt, "mac-a", mf::kBaselineWriterRevision, false);
    }
    std::unique_ptr<en::StateFile> reopen(en::StateLoad* out = nullptr) const {
        auto s = std::make_unique<en::StateFile>(blob->crash(), vaultUid(), [] { return std::time_t{1'800'000'000}; });
        const auto l = s->load(mf::kBaselineWriterRevision);
        if (out) *out = l;
        return s;
    }
};

}

TEST(EngineStateFile, TheReferenceFileBlobSavesAtomicallyAndAppendsDurably) {
    const auto dirPath = std::filesystem::temp_directory_path() / ("vl-vaultfmt-state-" + uidOf(0x33));
    std::filesystem::remove_all(dirPath);
    std::filesystem::create_directories(dirPath);
    const auto path = (dirPath / "vault.state").string();
    en::FileStateBlob blob(path);
    EXPECT_FALSE(blob.load().has_value());
    const std::vector<uint8_t> a{1, 2, 3}, b{4, 5};
    blob.save(a);
    EXPECT_TRUE(blob.append(b));
    EXPECT_EQ(blob.load(), std::optional<std::vector<uint8_t>>({1, 2, 3, 4, 5}));
    blob.save(b);
    EXPECT_EQ(blob.load(), std::optional<std::vector<uint8_t>>(b));
    EXPECT_FALSE(std::filesystem::exists(path + ".tmp"));
    EXPECT_EQ(std::filesystem::status(path).permissions() & std::filesystem::perms::all,
              std::filesystem::perms::owner_read | std::filesystem::perms::owner_write);
    // An engine over it: every change durable, and a new engine reads them back.
    {
        auto blobPtr = std::make_shared<en::FileStateBlob>(path);
        en::StateFile s(blobPtr, vaultUid(), [] { return std::time_t{0}; });
        mf::Content c;
        c.entries.push_back(dir(uidOf(0x01), std::nullopt, ""));
        s.reset(c, std::nullopt, "mac-a", 1, false);
        (void)s.commit({.put = {dir(uidOf(0x02), uidOf(0x01), "D")}});
    }
    en::StateFile again(std::make_shared<en::FileStateBlob>(path), vaultUid(), [] { return std::time_t{0}; });
    EXPECT_EQ(again.load(1).journal_records, 1u);
    EXPECT_EQ(again.working().entries.size(), 2u);
    std::filesystem::remove_all(dirPath);
    EXPECT_THROW((void)en::FileStateBlob("/nonexistent-dir-vl-vaultfmt/x").append(a), en::StateFailed);
}

TEST(EngineStateFile, ChangesAreJournalledAndFoldedIntoASnapshotEveryCompactAfterChanges) {
    Fixture f(true, 3);
    const auto saves = f.blob->saves();
    for (uint8_t i = 0; i < 7; ++i) (void)f.state->commit({.put = {dir(uidOf(0x10 + i), uidOf(0x01), std::to_string(i))}});
    EXPECT_EQ(f.blob->appends(), 6u);   // three appended, the fourth folded into a snapshot, three more appended
    EXPECT_EQ(f.blob->saves(), saves + 1);
    en::StateLoad l;
    const auto s = f.reopen(&l);
    EXPECT_EQ(s->working(), f.state->working());
    EXPECT_EQ(s->revision(), f.state->revision());
    // A blob without append saves every change.
    Fixture g(false);
    const auto before = g.blob->saves();
    (void)g.state->commit({.put = {dir(uidOf(0x20), uidOf(0x01), "x")}});
    EXPECT_EQ(g.blob->saves(), before + 1);
    EXPECT_EQ(g.blob->appends(), 0u);
}

TEST(EngineStateFile, ARecordThatFailsItsChecksumEndsTheJournalThere) {
    Fixture f;
    (void)f.state->commit({.put = {dir(uidOf(0x10), uidOf(0x01), "a")}});
    const auto at = f.blob->durable()->size() + 10;   // inside the next record
    (void)f.state->commit({.put = {dir(uidOf(0x11), uidOf(0x01), "b")}});
    (void)f.state->commit({.put = {dir(uidOf(0x12), uidOf(0x01), "c")}});
    f.blob->corrupt(at);
    en::StateLoad l;
    const auto s = f.reopen(&l);
    EXPECT_EQ(l.condition, en::StateCondition::Loaded);
    EXPECT_TRUE(l.journal_truncated);
    EXPECT_EQ(l.journal_records, 1u);
    EXPECT_EQ(s->working().entries.size(), 2u);
}

TEST(EngineStateFile, FormatsAndRevisionsFromTheFutureAreNeverOverwritten) {
    Fixture f;
    auto bytes = *f.blob->durable();
    bytes[11] = 2;   // format version 2
    const auto blob = std::make_shared<test_support::MemoryStateBlob>(bytes, true);
    en::StateFile s(blob, vaultUid(), [] { return std::time_t{0}; });
    EXPECT_THROW((void)s.load(1), en::StateTooNew);
    EXPECT_EQ(blob->durable(), std::optional(bytes));
    en::StateFile t(f.blob->crash(), vaultUid(), [] { return std::time_t{0}; });
    EXPECT_THROW((void)t.load(0), en::StateTooNew);   // written by revision 1, read by 0
    auto garbage = bytes;
    garbage[0] = 'X';
    en::StateFile u(std::make_shared<test_support::MemoryStateBlob>(garbage, true), vaultUid(), [] { return std::time_t{0}; });
    EXPECT_EQ(u.load(1).condition, en::StateCondition::Damaged);
}

// The rules of the server's remote_manifest_state / _root / _base / _pending / _gc, without SQL.
TEST(EngineStateFile, TheStateStoreKeepsTheServersRules) {
    Fixture f;
    auto& s = *f.state;
    mf::BaseCopy pending{{9, 9}, {{"sid-new", {1}}}};
    s.notePublishing("sha-1", pending);
    EXPECT_EQ(s.state().publishing_roots, std::vector<std::string>({"sha-1"}));
    ASSERT_TRUE(s.pendingBase("sha-1"));
    EXPECT_EQ(s.pendingBase("sha-1")->root, std::vector<uint8_t>({9, 9}));
    for (uint64_t epoch = 1; epoch <= 4; ++epoch)
        s.recordRoot(rec(epoch, "sha-" + std::to_string(epoch), {"s" + std::to_string(epoch)}, epoch % 2 == 1,
                         mf::BaseCopy{{1}, {{"s" + std::to_string(epoch), {2}}}}, {"mac-a"}));
    const auto st = s.state();
    EXPECT_EQ(st.epoch, std::optional<uint64_t>(4));
    EXPECT_EQ(st.own_epoch, std::optional<uint64_t>(3));   // kept from the last own record
    EXPECT_EQ(st.publishing_roots, std::vector<std::string>({"sha-4"}));
    EXPECT_FALSE(s.pendingBase("sha-1"));                   // a record clears the pending copies
    EXPECT_EQ(s.retainedSids(), std::set<std::string>({"s2", "s3", "s4"}));   // the last three roots
    EXPECT_EQ(s.base()->objects.size(), 1u);                // only the sids the recorded root names
    EXPECT_TRUE(s.recordRefused("fork", 5, "sha-x"));
    EXPECT_FALSE(s.recordRefused("fork", 5, "sha-x"));      // once per root
    EXPECT_TRUE(s.recordRefused("rollback", 5, "sha-x"));
    s.recordRoot(rec(5, "sha-5", {}, false, std::nullopt, {"mac-a"}));
    EXPECT_FALSE(s.state().refused_reason);                 // the chain moved on
    EXPECT_FALSE(s.base());                                 // no copy: dropped
    const auto t = s.firstUnreferenced("old");
    EXPECT_EQ(s.firstUnreferenced("old"), t);
    s.forgetUnreferenced("old");
    for (int i = 0; i < 300; ++i) s.notePublishing("p" + std::to_string(i), mf::BaseCopy{});
    EXPECT_EQ(s.state().publishing_roots.size(), 256u);
    EXPECT_EQ(s.state().publishing_roots.back(), "p299");
    s.markApplying(6, "sha-6");
    s.recordRoot(rec(6, "sha-6"));
    EXPECT_FALSE(s.state().applying_epoch);
    // All of it survives a reopen.
    const auto r = f.reopen();
    EXPECT_EQ(r->state().epoch, std::optional<uint64_t>(6));
    EXPECT_EQ(r->state().own_epoch, std::optional<uint64_t>(3));
}

TEST(EngineStateFile, TheChangeLogExpiresAnchorsOlderThanTheRemovalsItKeeps) {
    Fixture f;
    const auto gen = f.state->changesSince(0, 0).generation;
    const auto start = f.state->revision();
    for (std::size_t i = 0; i < en::StateFile::kMaxRemovedInLog + 10; ++i) {
        const auto uid = mf::uidText([&] {
            mf::Uid u{};
            u.fill(0x40);
            u[0] = static_cast<uint8_t>(i);
            u[1] = static_cast<uint8_t>(i >> 8);
            return u;
        }());
        (void)f.state->commit({.remove = {uid}});
    }
    EXPECT_TRUE(f.state->changesSince(gen, start).expired);
    const auto recent = f.state->revision() - 5;
    const auto c = f.state->changesSince(gen, recent);
    EXPECT_FALSE(c.expired);
    EXPECT_EQ(c.removed.size(), 5u);
}

}
