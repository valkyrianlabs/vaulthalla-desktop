// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The reader's C API (vl_vaultfmt.h, "The reader"): KEV1 and recovery seed vectors through the recipient handle and
// keyring_add_envelope, the listing's grammar and limits, the head choice over a version listing (C1 with and without
// an anchor, a stale root, another vault's root, a gap, the two rounds of needed versions), the tree as JSON, content
// bound to its entry, buffers, and the read-only end to end scenario the WebAssembly tests run in Node
// (wasm/tests/reader.test.mjs) over the same fixture: built fresh here, and from the committed wasm/tests/fixture.json.
// ReaderProperty replays the reader fuzz iteration (fuzz/reader_fuzz_body.hpp).
#include "support.hpp"

#include "reader_fixture.hpp"

#include "../fuzz/reader_fuzz_body.hpp"

#include "vl/vaultfmt/vhf1/Writer.hpp"
#include "vl/vaultfmt/vl_vaultfmt.h"

#include <gtest/gtest.h>

#include <cstring>
#include <filesystem>
#include <fstream>
#include <memory>
#include <random>
#include <set>
#include <string>
#include <vector>

namespace vl::vaultfmt::test_c_api_reader {

namespace {

using Bytes = std::vector<uint8_t>;
using nlohmann::json;
using test::fromHex;
using test::toHex;

const json& vectors() { return test::goldenVectors(); }
std::string name(const vl_vaultfmt_status s) { return vl_vaultfmt_status_name(s); }

template <class T, void (*Free)(T*)>
struct Handle {
    T* p = nullptr;
    Handle() = default;
    Handle(const Handle&) = delete;
    Handle& operator=(const Handle&) = delete;
    ~Handle() { Free(p); }
    T** out() { return &p; }
    T* get() const { return p; }
};
using Ring = Handle<vl_vaultfmt_keyring, vl_vaultfmt_keyring_free>;
using Recipient = Handle<vl_vaultfmt_recipient, vl_vaultfmt_recipient_free>;
using Head = Handle<vl_vaultfmt_head, vl_vaultfmt_head_free>;
using Root = Handle<vl_vaultfmt_root, vl_vaultfmt_root_free>;
using Tree = Handle<vl_vaultfmt_tree, vl_vaultfmt_tree_free>;
using Opener = Handle<vl_vaultfmt_opener, vl_vaultfmt_opener_free>;
using Buffer = Handle<vl_vaultfmt_buffer, vl_vaultfmt_buffer_free>;

template <class Fn>
std::string text(Fn&& fn, vl_vaultfmt_status* status = nullptr) {
    size_t len = 0;
    auto s = fn(nullptr, &len);
    std::string out;
    if (s == VL_VAULTFMT_ERR_BUFFER_TOO_SMALL || (s == VL_VAULTFMT_OK && len == 0)) {
        out.resize(len);
        s = fn(out.data(), &len);
    }
    if (status) {
        *status = s;
    } else {
        EXPECT_EQ(s, VL_VAULTFMT_OK) << name(s);
    }
    return out;
}

Bytes bytesOf(const vl_vaultfmt_buffer* b) {
    const auto* p = vl_vaultfmt_buffer_data(b);
    return p ? Bytes(p, p + vl_vaultfmt_buffer_size(b)) : Bytes{};
}

std::string sha256Hex(const Bytes& b) { return manifest::sha256Hex(b); }

// ---- the page's side of the protocol, in C ----------------------------------------------------------------------

struct Page {
    const test::ReaderFixture& f;
    Ring ring;

    explicit Page(const test::ReaderFixture& fixture) : f(fixture) {
        EXPECT_EQ(vl_vaultfmt_keyring_new(ring.out()), VL_VAULTFMT_OK);
        Recipient account;
        EXPECT_EQ(vl_vaultfmt_recipient_from_seed(f.seed_text.data(), f.seed_text.size(), account.out()), VL_VAULTFMT_OK);
        uint32_t version = 0;
        EXPECT_EQ(name(vl_vaultfmt_keyring_add_envelope(ring.get(), account.get(), f.vault.data(), f.decoy_envelope.data(),
                                                        f.decoy_envelope.size(), &version)),
                  "kev1_recipient_mismatch");
        EXPECT_EQ(vl_vaultfmt_keyring_add_envelope(ring.get(), account.get(), f.vault.data(), f.envelope.data(),
                                                   f.envelope.size(), &version),
                  VL_VAULTFMT_OK);
        EXPECT_EQ(version, f.key_version);
    }

    [[nodiscard]] const Bytes* rootBytes(const std::string& id) const {
        for (const auto& r : f.roots)
            if (r.version_id == id) return &r.bytes;
        return nullptr;
    }

    std::vector<std::string> needed(const vl_vaultfmt_head* h) const {
        return json::parse(text([&](char* o, size_t* n) { return vl_vaultfmt_head_needed(h, o, n); }))
            .get<std::vector<std::string>>();
    }

    void supply(vl_vaultfmt_head* h) const {
        for (const auto& id : needed(h)) {
            const auto* b = rootBytes(id);
            ASSERT_NE(b, nullptr) << id;
            ASSERT_EQ(vl_vaultfmt_head_supply(h, id.data(), id.size(), b->data(), b->size()), VL_VAULTFMT_OK);
        }
    }

    // A head over `listing`, every needed version supplied, decided; the status.
    vl_vaultfmt_status choose(Head& h, const std::string& listing, const vl_vaultfmt_anchor* anchor) const {
        EXPECT_EQ(vl_vaultfmt_head_new(f.vault.data(), listing.data(), listing.size(), anchor, h.out()), VL_VAULTFMT_OK);
        for (int round = 0; round < 3; ++round) {
            supply(h.get());
            const auto s = vl_vaultfmt_head_decide(h.get(), ring.get());
            if (s != VL_VAULTFMT_ERR_READER_NEED_OBJECTS) return s;
        }
        return VL_VAULTFMT_ERR_READER_NEED_OBJECTS;
    }

    json decision(const vl_vaultfmt_head* h) const {
        return json::parse(text([&](char* o, size_t* n) { return vl_vaultfmt_head_json(h, o, n); }));
    }
};

std::string listingWithout(const test::ReaderFixture& f, const std::set<std::string>& drop) {
    auto a = json::array();
    for (const auto& r : f.roots)
        if (!drop.contains(r.version_id)) a.push_back({{"version_id", r.version_id}, {"delete_marker", r.delete_marker}});
    return a.dump();
}

// The end to end read, through the C API only (wasm/tests/reader.test.mjs makes the same checks through the wasm
// build): head selection without and with an anchor, a stale root, another vault's root, the tree, listing and stat,
// a file's bytes, a ranged read across chunks, a tampered chunk and another file's object refused.
void readBack(const test::ReaderFixture& f) {
    const Page page(f);
    const auto listing = f.listingJson();

    // No anchor: every version is needed; the head is epoch 3, freshness unverified, the sibling a stray.
    {
        Head h;
        ASSERT_EQ(vl_vaultfmt_head_new(f.vault.data(), listing.data(), listing.size(), nullptr, h.out()), VL_VAULTFMT_OK);
        EXPECT_EQ(page.needed(h.get()).size(), f.roots.size());
        EXPECT_EQ(name(vl_vaultfmt_head_decide(h.get(), page.ring.get())), "reader_need_objects");
        page.supply(h.get());
        EXPECT_TRUE(page.needed(h.get()).empty());
        ASSERT_EQ(vl_vaultfmt_head_decide(h.get(), page.ring.get()), VL_VAULTFMT_OK);
        const auto d = page.decision(h.get());
        EXPECT_EQ(d["epoch"], 3);
        EXPECT_EQ(d["version_id"], f.epoch_version.at(3));
        EXPECT_EQ(d["root_sha256"], f.epoch_sha.at(3));
        EXPECT_EQ(d["freshness"], "unverified");
        EXPECT_EQ(d["gap"], false);
        EXPECT_EQ(d["base_version_id"], f.epoch_version.at(2));
        EXPECT_EQ(d["strays"], json::array({f.sibling_version}));
        EXPECT_EQ(d["anchor"], json({{"epoch", 3}, {"root_sha256", f.epoch_sha.at(3)}, {"version_id", f.epoch_version.at(3)}}));
    }

    // Anchored at epoch 2 (with its version id): only the versions from it on are needed; verified.
    const auto sha2 = f.epoch_sha.at(2);
    const auto id2 = f.epoch_version.at(2);
    const vl_vaultfmt_anchor anchor2{2, sha2.c_str(), id2.c_str()};
    {
        Head h;
        ASSERT_EQ(vl_vaultfmt_head_new(f.vault.data(), listing.data(), listing.size(), &anchor2, h.out()), VL_VAULTFMT_OK);
        const auto need = page.needed(h.get());
        EXPECT_EQ(need.size(), f.roots.size() - 1);
        EXPECT_EQ(std::count(need.begin(), need.end(), f.epoch_version.at(1)), 0);
        page.supply(h.get());
        ASSERT_EQ(vl_vaultfmt_head_decide(h.get(), page.ring.get()), VL_VAULTFMT_OK);
        const auto d = page.decision(h.get());
        EXPECT_EQ(d["epoch"], 3);
        EXPECT_EQ(d["freshness"], "verified");
        EXPECT_EQ(d["gap"], false);
    }

    // A stale root: the bucket hides epoch 3 (and the sibling) from a reader anchored at epoch 3.
    {
        const auto sha3 = f.epoch_sha.at(3);
        const vl_vaultfmt_anchor anchor3{3, sha3.c_str(), nullptr};
        Head h;
        EXPECT_EQ(name(page.choose(h, listingWithout(f, {f.epoch_version.at(3), f.sibling_version}), &anchor3)),
                  "chain_rollback");
        EXPECT_EQ(name(vl_vaultfmt_head_json(h.get(), nullptr, nullptr)), "unusable");
    }

    // Another vault's root, alone in the listing: it doesn't authenticate as this vault's, so there is no head.
    {
        const std::string other = R"([{"version_id":"other-1"}])";
        Head h;
        ASSERT_EQ(vl_vaultfmt_head_new(f.vault.data(), other.data(), other.size(), nullptr, h.out()), VL_VAULTFMT_OK);
        ASSERT_EQ(vl_vaultfmt_head_supply(h.get(), "other-1", 7, f.other_root.data(), f.other_root.size()), VL_VAULTFMT_OK);
        EXPECT_EQ(name(vl_vaultfmt_head_decide(h.get(), page.ring.get())), "reader_no_usable_root");
        Root r;
        EXPECT_EQ(name(vl_vaultfmt_root_open(f.other_root.data(), f.other_root.size(), f.vault.data(), page.ring.get(),
                                             nullptr, r.out())),
                  "vhf1_vault_mismatch");
    }

    // The tree of the head.
    Head h;
    ASSERT_EQ(page.choose(h, listing, &anchor2), VL_VAULTFMT_OK);
    Root root;
    ASSERT_EQ(vl_vaultfmt_head_root(h.get(), page.ring.get(), root.out()), VL_VAULTFMT_OK);
    std::vector<vl_vaultfmt_object_bytes> objects;
    for (size_t i = 0; i < vl_vaultfmt_root_object_count(root.get()); ++i) {
        vl_vaultfmt_object_ref ref{};
        ASSERT_EQ(vl_vaultfmt_root_object(root.get(), i, &ref), VL_VAULTFMT_OK);
        const auto& bytes = f.segments.at(ref.sid);
        EXPECT_EQ(sha256Hex(bytes), ref.object_sha256);
        objects.push_back({ref.sid, bytes.data(), bytes.size()});
    }
    ASSERT_GE(objects.size(), 2u);
    {
        Tree missing;
        EXPECT_EQ(name(vl_vaultfmt_tree_build(root.get(), objects.data() + 1, objects.size() - 1, page.ring.get(),
                                              missing.out())),
                  "chain_segment_missing");
        auto swapped = objects;
        swapped[0].bytes = objects[1].bytes;
        swapped[0].len = objects[1].len;
        Tree mismatched;
        EXPECT_EQ(name(vl_vaultfmt_tree_build(root.get(), swapped.data(), swapped.size(), page.ring.get(), mismatched.out())),
                  "chain_segment_mismatch");
    }
    Tree tree;
    ASSERT_EQ(vl_vaultfmt_tree_build(root.get(), objects.data(), objects.size(), page.ring.get(), tree.out()), VL_VAULTFMT_OK);

    const auto top = json::parse(text([&](char* o, size_t* n) { return vl_vaultfmt_tree_list_json(tree.get(), nullptr, 0, o, n); }));
    ASSERT_EQ(top.size(), 1u);
    const auto rootUid = top[0]["uid"].get<std::string>();
    const auto inRoot = json::parse(text([&](char* o, size_t* n) {
        return vl_vaultfmt_tree_list_json(tree.get(), rootUid.data(), rootUid.size(), o, n);
    }));
    std::set<std::string> names;
    for (const auto& e : inRoot) names.insert(e["name"]);
    EXPECT_EQ(names, (std::set<std::string>{"docs", "notes.txt"}));
    const auto& report = f.files[0];
    const auto stat = json::parse(text([&](char* o, size_t* n) {
        return vl_vaultfmt_tree_stat_json(tree.get(), report.uid.data(), report.uid.size(), o, n);
    }));
    EXPECT_EQ(stat["name"], "report.bin");
    EXPECT_EQ(stat["size"], report.size);
    vl_vaultfmt_status s{};
    text([&](char* o, size_t* n) { return vl_vaultfmt_tree_stat_json(tree.get(), "nope", 4, o, n); }, &s);
    EXPECT_EQ(name(s), "not_found");

    // Every file's bytes, whole, through the opener bound to its entry.
    for (const auto& file : f.files) {
        SCOPED_TRACE(file.name);
        Opener o;
        ASSERT_EQ(vl_vaultfmt_tree_open_content(tree.get(), f.vault.data(), file.uid.data(), file.uid.size(), nullptr, 0,
                                                file.object.data(), VL_VAULTFMT_HEADER_SIZE, page.ring.get(), o.out()),
                  VL_VAULTFMT_OK);
        Buffer out;
        ASSERT_EQ(vl_vaultfmt_buffer_new(out.out()), VL_VAULTFMT_OK);
        ASSERT_EQ(vl_vaultfmt_opener_update(o.get(), file.object.data() + VL_VAULTFMT_HEADER_SIZE,
                                            file.object.size() - VL_VAULTFMT_HEADER_SIZE, vl_vaultfmt_buffer_sink_fn(),
                                            out.get()),
                  VL_VAULTFMT_OK);
        ASSERT_EQ(vl_vaultfmt_opener_finish(o.get()), VL_VAULTFMT_OK);
        EXPECT_EQ(bytesOf(out.get()), test::patternBytes(file.pattern, file.size));
    }

    // A ranged read across chunks of report.bin (4 KiB chunks): only the chunks it needs, authenticated.
    const auto rangedRead = [&](const Bytes& object, const uint64_t start, const uint64_t end, Bytes* plain) {
        Opener o;
        const auto opened = vl_vaultfmt_tree_open_content(tree.get(), f.vault.data(), report.uid.data(), report.uid.size(),
                                                          nullptr, 0, object.data(), VL_VAULTFMT_HEADER_SIZE,
                                                          page.ring.get(), o.out());
        if (opened != VL_VAULTFMT_OK) return opened;
        uint64_t offset = 0, length = 0;
        EXPECT_EQ(vl_vaultfmt_range_plan(o.get(), start, end, &offset, &length), VL_VAULTFMT_OK);
        Buffer out;
        EXPECT_EQ(vl_vaultfmt_buffer_new(out.out()), VL_VAULTFMT_OK);
        const auto st = vl_vaultfmt_range_read(o.get(), start, end, object.size(), object.data() + offset, length,
                                               vl_vaultfmt_buffer_sink_fn(), out.get());
        *plain = bytesOf(out.get());
        return st;
    };
    Bytes plain;
    ASSERT_EQ(rangedRead(report.object, 3000, 9000, &plain), VL_VAULTFMT_OK);
    const auto whole = test::patternBytes(report.pattern, report.size);
    EXPECT_EQ(plain, Bytes(whole.begin() + 3000, whole.begin() + 9000));
    // The tampered object: chunk 0 still reads, a range touching chunk 1 is refused and yields nothing.
    ASSERT_EQ(rangedRead(f.tampered, 0, 4096, &plain), VL_VAULTFMT_OK);
    EXPECT_EQ(plain.size(), 4096u);
    EXPECT_EQ(name(rangedRead(f.tampered, 3000, 5000, &plain)), "vhf1_chunk_auth_failed");
    EXPECT_TRUE(plain.empty());
    // Another file's object for report.bin: refused at the header.
    EXPECT_EQ(name(rangedRead(f.files[2].object, 0, 10, &plain)), "vhf1_object_mismatch");
}

}

TEST(VaultfmtReader, StatusNamesOfTheReaderBlocks) {
    EXPECT_EQ(name(VL_VAULTFMT_ERR_KEV1_BAD_MAGIC), "kev1_bad_magic");
    EXPECT_EQ(name(VL_VAULTFMT_ERR_KEV1_BAD_KEY_VERSION), "kev1_bad_key_version");
    EXPECT_EQ(name(VL_VAULTFMT_ERR_SEED_BAD_CHECK), "seed_bad_check");
    EXPECT_EQ(name(VL_VAULTFMT_ERR_READER_NEED_OBJECTS), "reader_need_objects");
    EXPECT_EQ(name(VL_VAULTFMT_ERR_READER_BAD_LISTING), "reader_bad_listing");
    // 400 + kev1::ErrorCode, in vl-keykit's spelling.
    for (int code = 0; code <= static_cast<int>(keykit::kev1::ErrorCode::BadKeyVersion); ++code)
        EXPECT_EQ(name(400 + code),
                  "kev1_" + std::string(keykit::kev1::errorCodeName(static_cast<keykit::kev1::ErrorCode>(code))));
    std::set<std::string> seen;
    for (vl_vaultfmt_status st = 0; st < 1000; ++st) {
        const auto n = name(st);
        if (n != "unknown") {
            EXPECT_TRUE(seen.insert(n).second) << n;
        }
    }
}

TEST(VaultfmtReader, EveryKev1VectorThroughTheRecipientHandle) {
    for (const auto& v : vectors()["kev1"]["positive"]) {
        SCOPED_TRACE(v["name"].get<std::string>());
        const auto sk = fromHex(v["recipient_sk_hex"]);
        const auto env = fromHex(v["envelope_hex"]);
        const auto vault = fromHex(v["vault_uid_hex"]);
        Recipient r;
        ASSERT_EQ(vl_vaultfmt_recipient_from_secret(v["suite"].get<int32_t>(), sk.data(), sk.size(), r.out()), VL_VAULTFMT_OK);
        uint8_t id[32];
        ASSERT_EQ(vl_vaultfmt_recipient_id(r.get(), id), VL_VAULTFMT_OK);
        EXPECT_EQ(toHex(id), v["recipient_id_hex"].get<std::string>());
        Ring ring;
        ASSERT_EQ(vl_vaultfmt_keyring_new(ring.out()), VL_VAULTFMT_OK);
        uint32_t version = 0;
        ASSERT_EQ(vl_vaultfmt_keyring_add_envelope(ring.get(), r.get(), vault.data(), env.data(), env.size(), &version),
                  VL_VAULTFMT_OK);
        EXPECT_EQ(version, v["key_version"].get<uint32_t>());
        // The ring now holds the vector's vault key: an object sealed under it opens.
        vhf1::HeaderParams p;
        p.keyVersion = version;
        std::copy(vault.begin(), vault.end(), p.vaultUid.begin());
        p.objectUid.fill(0x42);
        p.salt.fill(0x24);
        const auto object = vhf1::seal(Bytes{1, 2, 3}, p, vhf1::Key(fromHex(v["vault_key_hex"])));
        const vl_vaultfmt_expectation e{VL_VAULTFMT_KIND_FILE_CONTENT, vault.data(), p.objectUid.data(), nullptr};
        Opener o;
        EXPECT_EQ(vl_vaultfmt_opener_new(object.data(), object.size(), &e, ring.get(), object.size(), o.out()), VL_VAULTFMT_OK);
    }
    for (const auto& v : vectors()["kev1"]["negative"]) {
        SCOPED_TRACE(v["name"].get<std::string>());
        const auto sk = fromHex(v["recipient_sk_hex"]);
        const auto env = fromHex(v["envelope_hex"]);
        const auto vault = fromHex(v["vault_uid_hex"]);
        Recipient r;
        ASSERT_EQ(vl_vaultfmt_recipient_from_secret(v["suite_expected"].get<int32_t>(), sk.data(), sk.size(), r.out()),
                  VL_VAULTFMT_OK);
        Ring ring;
        ASSERT_EQ(vl_vaultfmt_keyring_new(ring.out()), VL_VAULTFMT_OK);
        uint32_t version = 77;
        EXPECT_EQ(name(vl_vaultfmt_keyring_add_envelope(ring.get(), r.get(), vault.data(), env.data(), env.size(), &version)),
                  "kev1_" + v["expect"]["error"].get<std::string>());
        EXPECT_EQ(version, 77u);
    }
}

TEST(VaultfmtReader, EveryRecoverySeedVectorAsTheAccountKey) {
    for (const auto& v : vectors()["recovery_seed"]["positive"]) {
        const auto t = v["seed_text"].get<std::string>();
        Recipient r;
        ASSERT_EQ(vl_vaultfmt_recipient_from_seed(t.data(), t.size(), r.out()), VL_VAULTFMT_OK);
        uint8_t id[32];
        ASSERT_EQ(vl_vaultfmt_recipient_id(r.get(), id), VL_VAULTFMT_OK);
        EXPECT_EQ(toHex(id), v["recipient_id_hex"].get<std::string>());
    }
    for (const auto& v : vectors()["recovery_seed"]["negative"]) {
        const auto t = v["seed_text"].get<std::string>();
        Recipient r;
        EXPECT_EQ(name(vl_vaultfmt_recipient_from_seed(t.data(), t.size(), r.out())), "seed_" + v["error"].get<std::string>());
        EXPECT_EQ(r.get(), nullptr);
    }
    Recipient r;
    const uint8_t sk[32]{};
    EXPECT_EQ(vl_vaultfmt_recipient_from_secret(3, sk, 32, r.out()), VL_VAULTFMT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_vaultfmt_recipient_from_secret(1, sk, 31, r.out()), VL_VAULTFMT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_vaultfmt_recipient_from_secret(2, sk, 32, r.out()), VL_VAULTFMT_ERR_INVALID_ARGUMENT);   // scalar 0
}

TEST(VaultfmtReader, AListingIsJsonOfVersionsWithinTheLimits) {
    const uint8_t vault[16]{};
    const auto status = [&](const std::string& listing, const vl_vaultfmt_anchor* anchor = nullptr) {
        Head h;
        const auto s = vl_vaultfmt_head_new(vault, listing.data(), listing.size(), anchor, h.out());
        EXPECT_EQ(s == VL_VAULTFMT_OK, h.get() != nullptr);
        return name(s);
    };
    EXPECT_EQ(status("[]"), "ok");
    EXPECT_EQ(status(R"([{"version_id":"a","etag":null,"size":3,"key":".vaulthalla/root","extra":[1]}])"), "ok");
    for (const auto* bad : {"", "{}", "[1]", "[{}]", R"([{"version_id":""}])", R"([{"version_id":7}])",
                            R"([{"version_id":"a","key":".vaulthalla/seg/x"}])", R"([{"version_id":"a","size":-1}])",
                            R"([{"version_id":"a","delete_marker":"no"}])", R"([{"version_id":"a"},{"version_id":"a"}])",
                            R"([{"version_id":"a","x":[[[[1]]]]}])", "[{\"version_id\":\"a\"", "[\"\\u0000\"]"})
        EXPECT_EQ(status(bad), "reader_bad_listing") << bad;
    EXPECT_EQ(status(R"([{"version_id":")" + std::string(VL_VAULTFMT_READER_MAX_VERSION_ID + 1, 'v') + R"("}])"),
              "reader_limit");
    std::string many = "[";
    for (unsigned i = 0; i <= VL_VAULTFMT_READER_MAX_VERSIONS; ++i) many += (i ? "," : "") + json({{"version_id", std::to_string(i)}}).dump();
    EXPECT_EQ(status(many + "]"), "reader_limit");
    EXPECT_EQ(status(std::string(VL_VAULTFMT_READER_MAX_LISTING_BYTES + 1, ' ')), "reader_limit");
    const std::string sha(64, 'a');
    const vl_vaultfmt_anchor zero{0, sha.c_str(), nullptr};
    EXPECT_EQ(status("[]", &zero), "invalid_argument");
    const vl_vaultfmt_anchor upper{1, "AAAA", nullptr};
    EXPECT_EQ(status("[]", &upper), "invalid_argument");

    // Supplying: only listed, non-marker versions, within the byte limits.
    Head h;
    const std::string l = R"([{"version_id":"a"},{"version_id":"m","delete_marker":true}])";
    ASSERT_EQ(vl_vaultfmt_head_new(vault, l.data(), l.size(), nullptr, h.out()), VL_VAULTFMT_OK);
    const uint8_t b[1]{};
    EXPECT_EQ(name(vl_vaultfmt_head_supply(h.get(), "zz", 2, b, 1)), "not_found");
    EXPECT_EQ(name(vl_vaultfmt_head_supply(h.get(), "m", 1, b, 1)), "not_found");
    const Bytes big(VL_VAULTFMT_READER_MAX_ROOT_BYTES + 1);
    EXPECT_EQ(name(vl_vaultfmt_head_supply(h.get(), "a", 1, big.data(), big.size())), "reader_limit");
    EXPECT_EQ(vl_vaultfmt_head_gone(h.get(), "a", 1), VL_VAULTFMT_OK);
    Ring ring;
    ASSERT_EQ(vl_vaultfmt_keyring_new(ring.out()), VL_VAULTFMT_OK);
    EXPECT_EQ(name(vl_vaultfmt_head_decide(h.get(), ring.get())), "reader_no_usable_root");
}

TEST(VaultfmtReader, AnIncompleteChainFromTheAnchorNeedsASecondRoundAndReadsAsAGap) {
    // A root of epoch 5 whose chain doesn't reach the anchor (epoch 2): the anchored walk is incomplete, so C1 falls
    // back to the whole log, which needs epoch 1 too; the newest chain is accepted with a gap.
    auto f = test::buildReaderFixture();
    const Page page(f);
    const auto keyLookup = [&](uint32_t) -> vhf1::KeyPtr {
        Bytes k(32);
        for (std::size_t i = 0; i < k.size(); ++i) k[i] = static_cast<uint8_t>(0x40 + 3 * i);
        return std::make_shared<const vhf1::Key>(k);
    };
    auto doc = manifest::openRoot(*page.rootBytes(f.epoch_version.at(3)), f.vault, keyLookup);
    doc.epoch = 5;
    doc.prev = std::string(64, 'e');
    f.roots.insert(f.roots.begin(), {"v-epoch-5", false, manifest::sealRoot(doc, f.vault, {1, keyLookup(1)})});
    const auto sha2 = f.epoch_sha.at(2);
    const auto id2 = f.epoch_version.at(2);
    const vl_vaultfmt_anchor anchor{2, sha2.c_str(), id2.c_str()};
    const auto listing = f.listingJson();
    Head h;
    ASSERT_EQ(vl_vaultfmt_head_new(f.vault.data(), listing.data(), listing.size(), &anchor, h.out()), VL_VAULTFMT_OK);
    page.supply(h.get());
    EXPECT_EQ(name(vl_vaultfmt_head_decide(h.get(), page.ring.get())), "reader_need_objects");
    EXPECT_EQ(page.needed(h.get()), std::vector<std::string>{f.epoch_version.at(1)});
    page.supply(h.get());
    ASSERT_EQ(vl_vaultfmt_head_decide(h.get(), page.ring.get()), VL_VAULTFMT_OK);
    const auto d = page.decision(h.get());
    EXPECT_EQ(d["epoch"], 5);
    EXPECT_EQ(d["gap"], true);
    EXPECT_EQ(d["freshness"], "verified");
    EXPECT_EQ(vl_vaultfmt_head_decide(h.get(), page.ring.get()), VL_VAULTFMT_OK);   // final
    EXPECT_TRUE(page.needed(h.get()).empty());
}

TEST(VaultfmtReader, AForkOfTheAnchorIsRefused) {
    // The reader had accepted the sibling (another epoch 3 on the same base); an epoch 4 on the canonical epoch 3 is
    // then a fork of what it knows.
    auto f = test::buildReaderFixture();
    const Page page(f);
    const auto siblingSha = manifest::sha256Hex(*page.rootBytes(f.sibling_version));
    const auto keyLookup = [&](uint32_t) -> vhf1::KeyPtr {
        Bytes k(32);
        for (std::size_t i = 0; i < k.size(); ++i) k[i] = static_cast<uint8_t>(0x40 + 3 * i);
        return std::make_shared<const vhf1::Key>(k);
    };
    auto doc = manifest::openRoot(*page.rootBytes(f.epoch_version.at(3)), f.vault, keyLookup);
    doc.epoch = 4;
    doc.prev = f.epoch_sha.at(3);
    f.roots.insert(f.roots.begin(), {"v-epoch-4", false, manifest::sealRoot(doc, f.vault, {1, keyLookup(1)})});
    const vl_vaultfmt_anchor anchor{3, siblingSha.c_str(), f.sibling_version.c_str()};
    Head h;
    EXPECT_EQ(name(page.choose(h, f.listingJson(), &anchor)), "chain_fork");
}

TEST(VaultfmtReader, BuffersGrowAndZeroWhatTheyHeld) {
    Buffer b;
    ASSERT_EQ(vl_vaultfmt_buffer_new(b.out()), VL_VAULTFMT_OK);
    EXPECT_EQ(vl_vaultfmt_buffer_data(b.get()), nullptr);
    Bytes all;
    for (int i = 0; i < 40; ++i) {
        const Bytes part(static_cast<std::size_t>(i * 37 + 1), static_cast<uint8_t>(i));
        ASSERT_EQ(vl_vaultfmt_buffer_sink_fn()(b.get(), part.data(), part.size()), 0);
        all.insert(all.end(), part.begin(), part.end());
    }
    EXPECT_EQ(bytesOf(b.get()), all);
    vl_vaultfmt_buffer_clear(b.get());
    EXPECT_EQ(vl_vaultfmt_buffer_size(b.get()), 0u);
    EXPECT_NE(vl_vaultfmt_buffer_sink(nullptr, all.data(), 1), 0);
    EXPECT_NE(vl_vaultfmt_buffer_sink(b.get(), nullptr, 1), 0);
}

TEST(VaultfmtReader, AVaultBuiltNowReadsBackThroughTheCApiAlone) { readBack(test::buildReaderFixture()); }

TEST(VaultfmtReader, TheCommittedWasmFixtureReadsBackNatively) {
    // wasm/tests/fixture.json is what the Node suite reads through the wasm build: it must stay readable by this
    // library (regenerate it with make_reader_fixture after a format change).
    std::ifstream in(std::filesystem::path(VL_VAULTFMT_WASM_FIXTURE));
    ASSERT_TRUE(in) << VL_VAULTFMT_WASM_FIXTURE;
    readBack(test::fixtureFromJson(json::parse(in)));
}

TEST(VaultfmtReader, ReaderPropertyOverRandomBucketBytes) {
    // The fuzz iteration over a deterministic set: every mode, short and long inputs.
    std::mt19937 rng(20261115);
    for (int i = 0; i < 3000; ++i) {
        Bytes input(static_cast<std::size_t>(rng() % 600));
        for (auto& b : input) b = static_cast<uint8_t>(rng());
        if (!input.empty()) input[0] = static_cast<uint8_t>(i % 6);
        reader_fuzz::runOne(input);
    }
    // Oversized counts in otherwise valid shapes.
    for (const auto& text : {std::string(R"([{"version_id":"a","size":18446744073709551615}])"),
                             std::string(R"([{"version_id":"a","size":1e400}])")}) {
        Bytes input{0};
        input.insert(input.end(), text.begin(), text.end());
        reader_fuzz::runOne(input);
    }
}

}
