// swift-tools-version: 6.0
// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Proves VLVaultfmt.xcframework links and runs from Swift (run.sh builds it and copies it to Frameworks/). macOS only;
// not part of the meson build or the Linux CI.

import PackageDescription

let package = Package(
    name: "VaultfmtCheck",
    platforms: [.macOS("27.0")],
    targets: [
        .binaryTarget(name: "VLVaultfmt", path: "Frameworks/VLVaultfmt.xcframework"),
        .executableTarget(name: "VaultfmtCheck", dependencies: ["VLVaultfmt"]),
    ]
)
