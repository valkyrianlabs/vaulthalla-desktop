// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
//
// Writes the reader fixture (reader_fixture.hpp) as JSON to the path given, for the WebAssembly tests:
//   build/tests/make_reader_fixture wasm/tests/fixture.json
#include "reader_fixture.hpp"

#include <fstream>
#include <iostream>

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: make_reader_fixture <out.json>\n";
        return 2;
    }
    std::ofstream out(argv[1], std::ios::binary | std::ios::trunc);
    out << vl::vaultfmt::test::toJson(vl::vaultfmt::test::buildReaderFixture()).dump(1) << '\n';
    return out ? 0 : 1;
}
