// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
// The engine's C API (vl_vaultfmt_engine.h): the whole lifecycle from C (c_engine_lifecycle.c, compiled as C), every
// status's stable name, and the reference file state through the C table.

#include "vl/vaultfmt/vl_vaultfmt_engine.h"

#include "engine_support.hpp"

#include <gtest/gtest.h>

#include <filesystem>
#include <set>
#include <string>

extern "C" int vl_vaultfmt_c_engine_lifecycle(const uint8_t key[32], const uint8_t* envelope, size_t envelope_len,
                                              char* why, size_t why_cap);

namespace vl::vaultfmt::test_c_engine {

using namespace test_engine_support;

TEST(CEngine, AWholeVaultLifecycleThroughTheCApiAlone) {
    mf::Uid uid{};
    for (std::size_t i = 0; i < uid.size(); ++i) uid[i] = static_cast<uint8_t>(0x56 + i);
    const auto key = keyBytes(1);
    std::vector<uint8_t> recipient(32, 0);
    recipient[0] = 9;
    const auto envelope = vl::keykit::kev1::wrap(key, vl::keykit::kev1::Suite::X25519, 1, uid, recipient);
    char why[512] = {};
    EXPECT_EQ(vl_vaultfmt_c_engine_lifecycle(key.data(), envelope.data(), envelope.size(), why, sizeof why), 1) << why;
}

TEST(CEngine, EveryEngineStatusHasItsStableName) {
    const std::pair<vl_vaultfmt_status, std::string> names[] = {
        {VL_VAULTFMT_ERR_STORE_FAILED, "store_failed"},
        {VL_VAULTFMT_ERR_STORE_PRECONDITION_FAILED, "store_precondition_failed"},
        {VL_VAULTFMT_ERR_STORE_CONDITIONS_UNSUPPORTED, "store_conditions_unsupported"},
        {VL_VAULTFMT_ERR_STORE_OUTCOME_UNKNOWN, "store_outcome_unknown"},
        {VL_VAULTFMT_ERR_STATE_FAILED, "state_failed"},
        {VL_VAULTFMT_ERR_STATE_TOO_NEW, "state_too_new"},
        {VL_VAULTFMT_ERR_STATE_OTHER_VAULT, "state_other_vault"},
        {VL_VAULTFMT_ERR_PUBLISH_CONFLICT, "publish_conflict"},
        {VL_VAULTFMT_ERR_PUBLISH_UNSETTLED, "publish_unsettled"},
        {VL_VAULTFMT_ERR_PUBLISH_UNSUPPORTED, "publish_unsupported"},
        {VL_VAULTFMT_ERR_NO_USABLE_ROOT, "no_usable_root"},
        {VL_VAULTFMT_ERR_WRITER_FLOOR, "writer_floor"},
        {VL_VAULTFMT_ERR_APPLY_STOPPED, "apply_stopped"},
        {VL_VAULTFMT_ERR_NOT_A_DIRECTORY, "not_a_directory"},
        {VL_VAULTFMT_ERR_NAME_EXISTS, "name_exists"},
        {VL_VAULTFMT_ERR_INVALID_NAME, "invalid_name"},
        {VL_VAULTFMT_ERR_INVALID_MOVE, "invalid_move"},
        {VL_VAULTFMT_ERR_KEY_NOT_ADDED, "key_not_added"},
        {VL_VAULTFMT_ERR_RECIPIENT_REQUIRED, "recipient_required"},
        {VL_VAULTFMT_ERR_KEY_MISMATCH, "key_mismatch"},
        {VL_VAULTFMT_ERR_KEY_VERSION, "key_version"},
        {VL_VAULTFMT_ERR_BAD_ENVELOPE, "bad_envelope"},
        {VL_VAULTFMT_ERR_NO_VAULT, "no_vault"},
        {VL_VAULTFMT_ERR_BUSY, "busy"},
        {VL_VAULTFMT_ERR_WRITERS_REFUSED, "writers_refused"},
    };
    std::set<std::string> seen;
    for (const auto& [code, name] : names) {
        EXPECT_EQ(vl_vaultfmt_status_name(code), name);
        EXPECT_TRUE(seen.insert(name).second);
    }
    // engine::Refusal's names are the C names (620 + the refusal; not_found is the shared code 6).
    EXPECT_EQ(en::to_string(en::Refusal::NameExists), "name_exists");
    EXPECT_STREQ(vl_vaultfmt_status_name(620 + static_cast<int>(en::Refusal::KeyNotAdded)), "key_not_added");
    EXPECT_STREQ(vl_vaultfmt_status_name(620), "unknown");
    EXPECT_STREQ(vl_vaultfmt_status_name(VL_VAULTFMT_ERR_NOT_FOUND), "not_found");
}

TEST(CEngine, TheReferenceFileStateThroughItsTable) {
    const auto dir = std::filesystem::temp_directory_path() / "vl-vaultfmt-c-file-state";
    std::filesystem::remove_all(dir);
    std::filesystem::create_directories(dir);
    const auto path = (dir / "v.state").string();
    vl_vaultfmt_file_state* state = nullptr;
    ASSERT_EQ(vl_vaultfmt_file_state_new(path.data(), path.size(), &state), VL_VAULTFMT_OK);
    vl_vaultfmt_state_table table{};
    ASSERT_EQ(vl_vaultfmt_file_state_table(state, &table), VL_VAULTFMT_OK);
    EXPECT_EQ(table.load(table.ctx, nullptr), VL_VAULTFMT_ERR_NOT_FOUND);
    const uint8_t a[] = {1, 2, 3};
    EXPECT_EQ(table.save(table.ctx, a, sizeof a), VL_VAULTFMT_OK);
    EXPECT_EQ(table.append(table.ctx, a, 1), VL_VAULTFMT_OK);
    EXPECT_EQ(std::filesystem::file_size(path), 4u);
    vl_vaultfmt_file_state_free(state);
    std::filesystem::remove_all(dir);
    EXPECT_EQ(vl_vaultfmt_file_state_new(nullptr, 0, &state), VL_VAULTFMT_ERR_INVALID_ARGUMENT);
}

}
