# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 Valkyrian Labs LLC
"""The golden vectors, their reference reader and the C++ suites mean the same thing.

vectors/vh_crypto_vectors.py --check (meson test `vectors-reference`) regenerates vectors.json and verifies every vector
with the reference reader; Vhf1Vectors (tests/test_vhf1.cpp) and ManifestVectors (tests/test_manifest.cpp) read the same
vectors.json. These checks keep them from drifting: every VHF1 and manifest section the reference verifies is consumed
by a C++ suite, every error code the vectors use exists in vhf1::ErrorCode or manifest::ChainError, and the manifest
suite iterates every vector of each section. (Moved from vaulthalla-server's tools/contracts/test_vhf1_vectors_contract.py
with the code.)
"""

import json
import re
import sys
import unittest
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
VECTORS = REPO / "vectors" / "vectors.json"
REFERENCE = REPO / "vectors" / "vh_crypto_vectors.py"
CPP_VHF1 = REPO / "tests" / "test_vhf1.cpp"
CPP_MANIFEST = REPO / "tests" / "test_manifest.cpp"
CPP_FORMAT = REPO / "src" / "vhf1" / "Format.cpp"
CPP_CHAIN = REPO / "src" / "manifest" / "Chain.cpp"
GROUPS = ("vhf1", "manifest")


def reference_sections() -> set[tuple[str, str]]:
    text = REFERENCE.read_text(encoding="utf-8")
    verify = text[text.index("def verify("):text.index("def render(")]
    found = set()
    for group in GROUPS:
        found |= {(group, s) for s in re.findall(r'doc\["%s"\]\["(\w+)"\]' % group, verify)}
    return found


class VectorsContract(unittest.TestCase):
    def test_every_section_the_reference_verifies_is_consumed_by_a_cpp_suite(self) -> None:
        doc = json.loads(VECTORS.read_text(encoding="utf-8"))
        cpp = CPP_VHF1.read_text(encoding="utf-8") + CPP_MANIFEST.read_text(encoding="utf-8")
        consumed = {(g, s) for g in GROUPS for s in re.findall(r'\["%s"\]\["(\w+)"\]' % g, cpp)}
        verified = reference_sections()
        self.assertTrue(verified, "found no sections in the reference verify(); did its structure change?")
        in_file = {(g, s) for g in GROUPS for s in doc[g]}
        self.assertEqual(sorted((verified | in_file) - consumed), [], "vector sections no C++ test reads")

    def test_every_vector_error_code_exists_in_the_codec(self) -> None:
        doc = json.loads(VECTORS.read_text(encoding="utf-8"))
        codes = set(re.findall(r'\{ErrorCode::\w+, "(\w+)"\}', CPP_FORMAT.read_text(encoding="utf-8")))
        self.assertIn("chunk_auth_failed", codes, "error-name table not found in Format.cpp")
        used = {e["expect"]["error"] for e in doc["vhf1"]["negative"] + doc["vhf1"]["range_negative"]
                + doc["manifest"]["negative"] if "error" in e["expect"]}
        self.assertEqual(sorted(used - codes), [], "vector error codes without a vhf1::ErrorCode")

    def test_every_manifest_chain_outcome_exists_in_the_reader(self) -> None:
        doc = json.loads(VECTORS.read_text(encoding="utf-8"))
        names = set(re.findall(r'\{ChainError::\w+, "(\w+)"\}', CPP_CHAIN.read_text(encoding="utf-8")))
        self.assertIn("rollback", names, "chain error-name table not found in Chain.cpp")
        cases = doc["manifest"]["chain"]
        errors = {c["expect"]["error"] for c in cases if "error" in c["expect"]}
        self.assertEqual(sorted(errors - names), [], "chain vector errors without a manifest::ChainError")
        warnings = {c["expect"]["warning"] for c in cases if "warning" in c["expect"]}
        self.assertEqual(warnings, {"gap"}, "the chain vectors' warnings changed; teach ManifestVectors the new one")
        self.assertIn('got["warning"] = "gap"', CPP_MANIFEST.read_text(encoding="utf-8"))
        self.assertTrue({"rollback", "fork", "segment_missing", "segment_mismatch"} <= errors)

    def test_manifest_suite_iterates_every_vector_of_each_section(self) -> None:
        cpp = CPP_MANIFEST.read_text(encoding="utf-8")
        for section in ("objects", "chain", "negative"):
            self.assertRegex(cpp, r'for \(const auto& \w+ : vectors\(\)\["manifest"\]\["%s"\]\)' % section)


if __name__ == "__main__":
    sys.exit(0 if unittest.main(exit=False).result.wasSuccessful() else 1)
