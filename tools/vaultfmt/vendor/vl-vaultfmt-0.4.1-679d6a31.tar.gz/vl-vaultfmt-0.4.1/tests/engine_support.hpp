// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// What the engine suites share: a world (one versioned in-memory bucket in a publish mode, a hooked store over it, a
// keyring, a clock) and installations on it (an engine over a state blob that can crash and restart).

#include "vl/vaultfmt/engine/Session.hpp"
#include "vl/vaultfmt/testing/engine_store.hpp"
#include "vl/vaultfmt/vhf1/Key.hpp"

#include <vl/keykit/kev1.hpp>

#include <map>
#include <ostream>
#include <memory>
#include <string>
#include <vector>

namespace vl::vaultfmt::manifest {

// gtest prints entries as the manifest's JSON.
inline void PrintTo(const Entry& e, std::ostream* os) { *os << canonicalJson(toJson(e)); }

}

namespace vl::vaultfmt::test_engine_support {

namespace mf = manifest;
namespace en = engine;

// A crash at a scheduled point (a hook throws it; nothing after it runs).
struct Crash {};

inline std::vector<uint8_t> keyBytes(const uint32_t version) {
    std::vector<uint8_t> k(32);
    for (std::size_t i = 0; i < k.size(); ++i) k[i] = static_cast<uint8_t>(version * 41 + i);
    return k;
}

inline std::vector<uint8_t> pattern(const std::size_t n, const uint8_t seed) {
    std::vector<uint8_t> out(n);
    for (std::size_t i = 0; i < n; ++i) out[i] = static_cast<uint8_t>(seed + i * 7 + (i >> 9));
    return out;
}

struct World {
    std::shared_ptr<test_support::MemoryBucket> bucket = std::make_shared<test_support::MemoryBucket>();
    mf::WriteCapability mode;
    std::shared_ptr<test_support::HookedBucketStore> store;
    mf::Uid vault{};
    std::map<uint32_t, vhf1::KeyPtr> keyring;
    uint32_t current{1};
    std::time_t clock{1'800'000'000};

    explicit World(const mf::WriteCapability m = mf::WriteCapability::VersionLog) : mode(m) {
        if (mode == mf::WriteCapability::VersionLog) bucket->provider(test_support::MemoryBucket::Provider::Backblaze);
        store = std::make_shared<test_support::HookedBucketStore>(
            std::make_shared<test_support::MemoryBucketStore>(bucket, mode));
        vault.fill(0x5a);
        vault[0] = 0x56;
        hold(1);
    }

    void hold(const uint32_t version) { keyring[version] = std::make_shared<const vhf1::Key>(keyBytes(version)); }

    en::Keys keys() {
        return {[this](const uint32_t v) -> vhf1::KeyPtr {
                    const auto it = keyring.find(v);
                    return it == keyring.end() ? nullptr : it->second;
                },
                [this] { return current; }};
    }

    std::vector<uint8_t> envelope(const uint32_t version) const {
        std::vector<uint8_t> recipient(32, 0);
        recipient[0] = 9;   // the X25519 base point: a valid public key
        std::vector<uint8_t> ephemeral(32, static_cast<uint8_t>(0x40 + version));   // deterministic: one kid per version
        return vl::keykit::kev1::wrap(keyBytes(version), vl::keykit::kev1::Suite::X25519, version, vault, recipient,
                                      ephemeral);
    }
};

// One installation (a Mac): its node id and its state blob, which survives a crash as what was durable.
struct Mac {
    World& world;
    std::string node;
    std::shared_ptr<test_support::MemoryStateBlob> blob = std::make_shared<test_support::MemoryStateBlob>();
    std::unique_ptr<en::Session> engine;
    en::OpenReport report;
    std::function<void()> afterRootPut;

    Mac(World& w, std::string n) : world(w), node(std::move(n)) {}

    en::Session& open(const std::optional<std::string>& create = std::nullopt) {
        en::Options o;
        o.node_id = node;
        o.software = "vl-vaultfmt test";
        o.now = [this] { return world.clock++; };
        o.create_name = create;
        o.after_root_put = [this] {
            if (afterRootPut) afterRootPut();
        };
        engine = en::Session::open(world.vault, world.store, world.keys(), blob, o, &report);
        return *engine;
    }
    // A crash: the engine is gone, its state is what was durable; then it starts again.
    en::Session& restart() {
        engine.reset();
        blob = blob->crash();
        return open();
    }
    en::Session* operator->() { return engine.get(); }
};

// A new vault with its first key added.
inline en::Session& created(Mac& mac) {
    auto& e = mac.open("Finance");
    e.keyAdd(1, keyBytes(1), {mac.world.envelope(1)});
    return e;
}

inline mf::Entry writeFile(en::Session& e, const std::string& parent, const std::string& name,
                           const std::vector<uint8_t>& bytes, const std::optional<std::string>& uid = std::nullopt) {
    auto w = e.writeBegin(parent, name, uid, std::nullopt, bytes.size());
    for (std::size_t at = 0; at < bytes.size(); at += 70'000)
        w->write(std::span(bytes).subspan(at, std::min<std::size_t>(70'000, bytes.size() - at)));
    return w->finish().entry;
}

inline std::vector<uint8_t> readAll(const en::Session& e, const std::string& uid,
                                    const std::optional<std::string>& version = std::nullopt) {
    std::vector<uint8_t> out;
    e.read(uid, version, 0, UINT64_MAX, [&](const std::span<const uint8_t> b) { out.insert(out.end(), b.begin(), b.end()); });
    return out;
}

inline std::optional<mf::Entry> named(const en::Session& e, const std::string& parent, const std::string& name) {
    for (const auto& x : e.list(parent))
        if (x.name == name) return x;
    return std::nullopt;
}

// The bucket's canonical head as a fresh reader loads it.
inline mf::Loaded head(World& w) {
    return mf::loadForRestore(*w.store, w.vault, w.keys().lookup, std::nullopt).loaded;
}

}
