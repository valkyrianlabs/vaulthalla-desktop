// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
// The object keys of an opaque_v1 bucket (vl/vaultfmt/ObjectKeys.hpp; vaulthalla-server
// design/encryption/01-provider-blind-storage.md §4.2, §4.3, §7).
#include "vl/vaultfmt/ObjectKeys.hpp"

#include <vl/keykit/kev1.hpp>
#include <vl/keykit/uid.hpp>

#include <gtest/gtest.h>

#include <algorithm>
#include <cctype>
#include <string>

namespace vl::vaultfmt::keys::test_object_keys {

namespace {

constexpr uint64_t kMiB = 1024ull * 1024;
constexpr uint64_t kGiB = 1024ull * kMiB;

std::string lower(std::string s) {
    std::ranges::transform(s, s.begin(), [](const unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return s;
}

vl::keykit::Uid someUid() {
    vl::keykit::Uid u{};
    for (std::size_t i = 0; i < u.size(); ++i) u[i] = static_cast<uint8_t>(0x5a + 17 * i);
    return u;
}

}

TEST(ObjectKeys, KeysAreBuiltParsedAndClassifiedInOnePlace) {
    const auto uid = someUid();
    const auto key = contentKey(uid);
    EXPECT_EQ(key, "o/" + vl::keykit::toBase32(uid));
    EXPECT_EQ(uidOfContentKey(key), uid);
    EXPECT_EQ(uidOfContentKey("/" + key), uid) << "scope keys and index paths carry a leading slash";
    EXPECT_FALSE(uidOfContentKey("o/" + lower(vl::keykit::toBase32(uid)) + "x"));
    EXPECT_FALSE(uidOfContentKey("o/OO"));

    EXPECT_EQ(classify(key), KeyClass::Content);
    for (const auto* k : {".vaulthalla/layout.json", ".vaulthalla/root"}) EXPECT_EQ(classify(k), KeyClass::Metadata) << k;
    EXPECT_EQ(classify(".vaulthalla/seg/" + vl::keykit::toBase32(uid)), KeyClass::Metadata);
    EXPECT_EQ(classify(".vaulthalla/key/" + vl::keykit::toBase32(uid)), KeyClass::Metadata);
    const std::string envelope = "any envelope bytes";
    const auto envelopeKey = vl::keykit::kev1::objectKey(
        vl::keykit::kev1::kid(std::span(reinterpret_cast<const uint8_t*>(envelope.data()), envelope.size())));
    EXPECT_EQ(classify(envelopeKey), KeyClass::Metadata) << "KEV1 envelopes are allowlisted";
    EXPECT_EQ(classify(".vaulthalla/probe/" + vl::keykit::toBase32(uid)), KeyClass::Metadata)
        << "the bucket capability probe's object";
    for (const auto* k : {"Reports/Q3 board pack.pdf", ".vaulthalla/index-v1.json", ".vaulthalla/seg/nope", "o/",
                          "o/x/y", "/o/abc", ".vaulthalla/probe/Reports"})
        EXPECT_EQ(classify(k), KeyClass::Foreign) << k;

    for (const auto* p : {"", "o/", ".vaulthalla/", ".vaulthalla/seg/"}) EXPECT_TRUE(isAllowedListPrefix(p)) << p;
    EXPECT_TRUE(isAllowedListPrefix(key)) << "the versions of one object";
    for (const auto* p : {"Reports/", "docs", "o/ab"}) EXPECT_FALSE(isAllowedListPrefix(p)) << p;
    EXPECT_TRUE(isAllowedKey(key));
    EXPECT_FALSE(isAllowedKey("Reports/x"));
    EXPECT_EQ(importedPathOf("notes/plain.txt"), "/Imported/notes/plain.txt");
}

TEST(ObjectKeys, PartSizeGrowsWithTheObjectAndNeverExceeds10000Parts) {
    EXPECT_EQ(partSizeFor(0), 5 * kMiB);
    EXPECT_EQ(partSizeFor(11 * kMiB), 5 * kMiB);
    EXPECT_EQ(partSizeFor(48 * kGiB), 5 * kMiB) << "today's objects keep 5 MiB parts";
    EXPECT_EQ(partSizeFor(60 * kGiB), 7 * kMiB) << "ceil(60 GiB / 10,000) rounded up to a whole MiB";
    for (const uint64_t size : {50 * kGiB, 60 * kGiB, 1024 * kGiB, 5 * 1024 * kGiB, 5 * 1024 * kGiB + 1}) {
        const auto part = partSizeFor(size);
        EXPECT_EQ(part % kMiB, 0u);
        EXPECT_GE(part, 5 * kMiB);
        EXPECT_LE(partCountFor(size, part), kMaxParts) << size;
    }
    EXPECT_GT(partCountFor(60 * kGiB, 5 * kMiB), kMaxParts) << "the fixed 5 MiB part could not do it";
}

}
