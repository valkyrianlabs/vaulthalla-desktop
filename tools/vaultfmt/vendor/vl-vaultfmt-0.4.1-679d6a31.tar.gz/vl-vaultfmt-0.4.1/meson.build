# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 Valkyrian Labs LLC
project('vl-vaultfmt', 'cpp',
  version: '0.4.1',
  license: 'AGPL-3.0-or-later',
  license_files: ['LICENSE'],
  meson_version: '>= 1.3.0',
  default_options: ['cpp_std=c++23', 'warning_level=3'],
)

openssl_dep = dependency('libcrypto', version: '>= 3.0')
json_dep = dependency('nlohmann_json', version: '>= 3.11')
# Uid, SecretBytes, KEV1 object keys. A consumer that already links vl-keykit (vaulthalla-server) provides it; standing
# alone, the release pinned in subprojects/vl-keykit.wrap (its tarball committed under subprojects/packagecache/).
keykit_dep = dependency('vl-keykit', version: '>= 0.2.0', fallback: ['vl-keykit', 'vl_keykit_dep'])

fuzz = get_option('fuzz')
if fuzz and meson.get_compiler('cpp').get_id() != 'clang'
  error('-Dfuzz=true needs clang with libFuzzer (e.g. CXX=clang++-18)')
endif

inc = include_directories('include')

sources = files(
  'src/ObjectKeys.cpp',
  'src/c_api.cpp',
  'src/c_api_engine.cpp',
  'src/c_api_reader.cpp',
  'src/engine/FileStateBlob.cpp',
  'src/engine/Session.cpp',
  'src/engine/StateFile.cpp',
  'src/manifest/Chain.cpp',
  'src/manifest/Content.cpp',
  'src/manifest/Document.cpp',
  'src/manifest/Objects.cpp',
  'src/manifest/Partition.cpp',
  'src/manifest/Publisher.cpp',
  'src/manifest/Reader.cpp',
  'src/manifest/Reconcile.cpp',
  'src/manifest/Session.cpp',
  'src/manifest/Store.cpp',
  'src/manifest/VersionLog.cpp',
  'src/manifest/WriteCapability.cpp',
  'src/vhf1/Aead.cpp',
  'src/vhf1/Format.cpp',
  'src/vhf1/Key.cpp',
  'src/vhf1/Reader.cpp',
  'src/vhf1/Writer.cpp',
)

deps = [openssl_dep, json_dep, keykit_dep, dependency('threads')]

vl_vaultfmt_lib = static_library('vl-vaultfmt', sources,
  include_directories: inc,
  cpp_args: ['-DVL_VAULTFMT_VERSION="' + meson.project_version() + '"'] + (fuzz ? ['-fsanitize=fuzzer-no-link'] : []),
  dependencies: deps,
  install: not meson.is_subproject(),
)

# `vectors_dir`: the golden vectors (vectors/vectors.json), for a consumer that checks its own copy against them.
vl_vaultfmt_dep = declare_dependency(
  include_directories: inc,
  link_with: vl_vaultfmt_lib,
  dependencies: deps,
  version: meson.project_version(),
  variables: {'vectors_dir': meson.current_source_dir() / 'vectors'},
)
meson.override_dependency('vl-vaultfmt', vl_vaultfmt_dep)

headers = files(
  'include/vl/vaultfmt/Fwd.hpp',
  'include/vl/vaultfmt/ObjectKeys.hpp',
  'include/vl/vaultfmt/vaultfmt.hpp',
  'include/vl/vaultfmt/vl_vaultfmt.h',
  'include/vl/vaultfmt/vl_vaultfmt_engine.h',
)
manifest_headers = files(
  'include/vl/vaultfmt/manifest/Chain.hpp',
  'include/vl/vaultfmt/manifest/Content.hpp',
  'include/vl/vaultfmt/manifest/Document.hpp',
  'include/vl/vaultfmt/manifest/Objects.hpp',
  'include/vl/vaultfmt/manifest/Partition.hpp',
  'include/vl/vaultfmt/manifest/Publisher.hpp',
  'include/vl/vaultfmt/manifest/Reader.hpp',
  'include/vl/vaultfmt/manifest/Reconcile.hpp',
  'include/vl/vaultfmt/manifest/Session.hpp',
  'include/vl/vaultfmt/manifest/Store.hpp',
  'include/vl/vaultfmt/manifest/VersionLog.hpp',
  'include/vl/vaultfmt/manifest/WriteCapability.hpp',
)
# The database-free engine (Vaulthalla Desktop's Desktop-only vaults).
engine_headers = files(
  'include/vl/vaultfmt/engine/Session.hpp',
  'include/vl/vaultfmt/engine/State.hpp',
  'include/vl/vaultfmt/engine/Store.hpp',
)
vhf1_headers = files(
  'include/vl/vaultfmt/vhf1/Aead.hpp',
  'include/vl/vaultfmt/vhf1/Format.hpp',
  'include/vl/vaultfmt/vhf1/Key.hpp',
  'include/vl/vaultfmt/vhf1/Reader.hpp',
  'include/vl/vaultfmt/vhf1/Writer.hpp',
)
# Header-only test doubles for consumers' own suites (an in-memory versioned ObjectStore and a hooking wrapper).
testing_headers = files(
  'include/vl/vaultfmt/testing/engine_store.hpp',
  'include/vl/vaultfmt/testing/hooked_store.hpp',
  'include/vl/vaultfmt/testing/memory_store.hpp',
)

if not meson.is_subproject()
  install_headers(headers, subdir: 'vl/vaultfmt')
  install_headers(manifest_headers, subdir: 'vl/vaultfmt/manifest')
  install_headers(engine_headers, subdir: 'vl/vaultfmt/engine')
  install_headers(vhf1_headers, subdir: 'vl/vaultfmt/vhf1')
  install_headers(testing_headers, subdir: 'vl/vaultfmt/testing')
  pkg = import('pkgconfig')
  pkg.generate(vl_vaultfmt_lib,
    name: 'vl-vaultfmt',
    description: 'Vaulthalla vault format: VHF1 files, object keys and the encrypted manifest (C++23, C API)',
    url: 'https://github.com/valkyrianlabs/vl-vaultfmt',
    requires: ['libcrypto >= 3.0', 'nlohmann_json >= 3.11', 'vl-keykit >= 0.2.0'],
  )
endif

if fuzz
  subdir('fuzz')
elif get_option('tests').allowed() and not meson.is_subproject()
  gtest_dep = dependency('gtest', main: true, required: get_option('tests'))
  if gtest_dep.found()
    subdir('tests')
  endif
endif
