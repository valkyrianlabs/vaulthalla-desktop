// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include "vl/vaultfmt/engine/State.hpp"
#include "vl/vaultfmt/engine/Store.hpp"
#include "vl/vaultfmt/manifest/Reader.hpp"
#include "vl/vaultfmt/manifest/Reconcile.hpp"
#include "vl/vaultfmt/manifest/Session.hpp"
#include "vl/vaultfmt/vhf1/Writer.hpp"

#include <cstdint>
#include <ctime>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

// The database-free engine (vaulthalla-server design/core/vault-format-library.md, work item 9): one opaque_v1 vault
// kept in its bucket with no database and no server, as Vaulthalla Desktop runs a Desktop-only vault. The bucket is the
// database; what a server keeps in PostgreSQL the engine keeps in one state blob (State.hpp; docs/engine.md).
//
// It is the server's own logic over that state: manifest::Session for publishing (both modes), verifying, refusing,
// repair and GC; manifest::reconcile and applyPlan for taking in another writer's root, by the server applier's rules
// and order; the reader's load, base copy and blind rebuild for opening. What it adds: the working content (the last
// settled content plus every local change, journalled before an operation returns), the operations on it, and the
// streamed content seam (o/<uid>).
//
// Guarantees (each pinned by a test in tests/test_engine*.cpp; docs/engine.md lists them):
//   - an operation that returned is durable (its journal record is flushed); one that threw did not happen;
//   - nothing is published over a root the chain rules refuse, below the writer floor, or partially applied;
//   - a crash between a root's PUT and its record, a PUT that lands after the publish gave up, and another writer
//     building on a root of ours that was never recorded each end with every local change kept;
//   - a lost or damaged state re-anchors from the bucket: what was published stays, with "freshness unverified";
//     content uploaded and never published comes back under /Recovered (no names); keys are never lost (their
//     envelopes are PUT before a key version seals anything);
//   - plaintext reaches a read's sink only from chunks that authenticated.
//
// Threads: every method may be called from any thread; operations are serialized per vault, and network work (uploads,
// publishing, refreshing) runs outside the lock that local operations take.
namespace vl::vaultfmt::engine {

using manifest::Entry;
using manifest::Uid;

// The installation's keys: every version it holds (the Mac's keychain) and the one new objects are sealed under.
struct Keys {
    vhf1::KeyLookup lookup;
    std::function<uint32_t()> current;
};

struct Options {
    std::string node_id;                                    // this installation (the root's producer and writers)
    std::string software{"vl-vaultfmt"};                    // the root's producer.software
    std::function<std::time_t()> now{};                     // default: the system clock
    std::function<void(manifest::Notice, const std::string&)> note{};
    std::function<void(const manifest::Refusal&)> alert{};  // a refused root, once per root
    std::optional<std::string> create_name{};               // no state, no root in the bucket: a new vault of this name
    bool recover_unnamed{true};                             // re-anchor: objects no root names go under /Recovered
    std::size_t compact_after{256};                         // journal records between snapshots
    unsigned publish_rounds{4};                             // a publish applies another writer's root at most this often
    std::function<void()> after_root_put{};                 // tests: between a root's PUT and its record
};

// Why an operation was refused; nothing changed. Stable names (to_string) for the C API.
enum class Refusal {
    NotFound,           // no such entry (or not one this operation takes)
    NotADirectory,      // the parent is not a live directory
    NameExists,         // a live entry of that name is in the folder
    InvalidName,        // empty, "." or "..", a '/', a NUL, more than 255 bytes, or not UTF-8
    InvalidMove,        // the vault root, or into itself or below itself
    KeyNotAdded,        // the current key version was never added (keyAdd): its envelopes may not be in the bucket
    RecipientRequired,  // keyAdd without an envelope
    KeyMismatch,        // keyAdd's key is not the one the keys callback holds for that version
    KeyVersion,         // keyAdd's version is not above every version the vault has
    BadEnvelope,        // an envelope that is not KEV1 of this vault, this version and the customer class
    NoVault,            // nothing to open: no state, no root, and no create_name
    Busy,               // a write's target changed while it streamed (overwritten, moved away or removed)
};
[[nodiscard]] std::string_view to_string(Refusal refusal);

class Refused : public std::runtime_error {
public:
    Refused(Refusal why, const std::string& message) : std::runtime_error(message), why_(why) {}
    [[nodiscard]] Refusal why() const noexcept { return why_; }

private:
    Refusal why_;
};

// A head the engine won't take in (nothing applied, nothing published): code() is the server applier's
// (manifest_key_missing, manifest_key_mismatch, manifest_head_incomplete, manifest_own_unexplained).
class ApplyStopped : public std::runtime_error {
public:
    ApplyStopped(std::string code, const std::string& message) : std::runtime_error(message), code_(std::move(code)) {}
    [[nodiscard]] const std::string& code() const noexcept { return code_; }

private:
    std::string code_;
};

enum class Anchor {
    State,        // the state blob held the vault
    Reanchored,   // the state was missing or damaged: read from the bucket (spec 06 §5.1, C1 without an anchor)
    Created,      // a new vault
};

struct OpenReport {
    Anchor anchor{Anchor::State};
    StateLoad state;
    manifest::Freshness freshness{manifest::Freshness::Verified};   // Reanchored: Unverified (nothing bounds replay)
    std::size_t recovered{};                                        // objects placed under /Recovered
    std::optional<manifest::Known> known;
};

struct RefreshReport {
    bool moved{false};       // the bucket's head is not the root recorded before
    bool applied{false};     // another writer's root was taken into the working content and recorded
    bool adopted{false};     // our own root, PUT and not recorded, was recorded
    bool root_missing{false};   // the bucket has no readable root (the next publish rebuilds it)
    std::optional<manifest::Known> known;
    std::string producer;    // the applied head's
    bool union_base{false};  // no usable base copy: the merge was a union (nothing deleted)
    std::vector<manifest::Conflict> conflicts;   // decided, and content edit/edit (both generations kept)
    std::size_t changed{};   // entries the apply changed
};

struct PublishResult {
    bool published{false};   // a new root is the bucket's head
    manifest::Known known;
    unsigned rounds{0};      // HeadMoved rounds (another writer's root applied first)
    unsigned segments_written{};
    unsigned segments_reused{};
    std::size_t purged{};    // objects of purged files deleted after the root settled
};

struct Status {
    std::optional<manifest::Known> known;
    std::optional<std::string> refused;   // a refused root's reason: nothing is published until the chain moves on
    bool update_needed{false};            // a head above this engine's writer revision was seen
    bool unpublished{false};              // local changes not in the bucket's root yet
    uint64_t generation{};
    uint64_t revision{};
    std::size_t pending_purges{};
};

// A content edit made from a stale generation ended as a conflict: both are kept (ours current, theirs a version).
struct WriteResult {
    Entry entry;
    bool conflict{false};
};

class Session;

// One streamed write: seal under the current key, upload, record the version (finish). Destroyed unfinished, it aborts
// the upload and records nothing.
class Writer {
public:
    ~Writer();
    Writer(const Writer&) = delete;
    Writer& operator=(const Writer&) = delete;
    void write(std::span<const uint8_t> plaintext);
    WriteResult finish();

private:
    friend class Session;
    struct State;
    explicit Writer(std::unique_ptr<State> state);
    std::unique_ptr<State> s_;
};

class Session {
public:
    // Opens the vault: from the state blob (no request), or, when it is missing or damaged, from the bucket (re-anchor),
    // or a new vault (create_name, with no root in the bucket). The store's mode() must be Conditional or VersionLog
    // (the engine never probes; a Desktop-only vault is VersionLog from creation, design decision 9).
    static std::unique_ptr<Session> open(const Uid& vaultUid, std::shared_ptr<BucketStore> store, Keys keys,
                                         std::shared_ptr<StateBlob> state, Options options,
                                         OpenReport* report = nullptr);
    ~Session();
    Session(const Session&) = delete;
    Session& operator=(const Session&) = delete;

    // ---- reading the working content -----------------------------------------------------------------------------------
    [[nodiscard]] std::string rootUid() const;
    // The live entries of a directory, in uid order. Refused(NotFound / NotADirectory).
    [[nodiscard]] std::vector<Entry> list(const std::string& dirUid) const;
    // Any entry (live, trashed), nullopt when there is none.
    [[nodiscard]] std::optional<Entry> stat(const std::string& uid) const;
    [[nodiscard]] std::vector<Entry> trash() const;
    [[nodiscard]] ChangeLog changes(uint64_t generation, uint64_t after) const;

    // ---- content -------------------------------------------------------------------------------------------------------
    // Plaintext [offset, offset + length) of a file's current object, or of one of its versions (version id), clipped
    // to the file's size. Only chunks that authenticated reach the sink (in order, in pieces of at most 4 MiB).
    void read(const std::string& uid, const std::optional<std::string>& versionId, uint64_t offset, uint64_t length,
              const std::function<void(std::span<const uint8_t>)>& sink) const;
    // A new file in `parentUid` named `name`, or (uid set) new content for that file. `expectedGeneration`: the
    // generation the local edit started from; another one at finish is a conflict (both kept).
    [[nodiscard]] std::unique_ptr<Writer> writeBegin(const std::string& parentUid, const std::string& name,
                                                     const std::optional<std::string>& uid = std::nullopt,
                                                     const std::optional<std::string>& expectedGeneration = std::nullopt,
                                                     std::optional<uint64_t> size = std::nullopt);

    // ---- tree changes (journalled) -----------------------------------------------------------------------------------
    Entry mkdir(const std::string& parentUid, const std::string& name);
    Entry rename(const std::string& uid, const std::string& name);
    Entry move(const std::string& uid, const std::string& parentUid, const std::optional<std::string>& name = std::nullopt);
    // A file into the trash; a directory's files into the trash and its directories and symlinks removed.
    void trash(const std::string& uid);
    // A trashed file back to `parentUid` (default: where it was, else the vault root) under `name` (default: its own).
    Entry restore(const std::string& uid, const std::optional<std::string>& parentUid = std::nullopt,
                  const std::optional<std::string>& name = std::nullopt);
    // A trashed file, or a live entry (a directory with everything below it), gone. Its objects are deleted once a
    // root without it settled, while this installation is the vault's only writer.
    void purge(const std::string& uid);

    // ---- keys ----------------------------------------------------------------------------------------------------------
    // A new key version: `key` must be what the keys callback returns for it; every envelope (KEV1 of this vault and
    // version, customer class; at least one) is PUT before the version is recorded, so nothing is ever sealed under a
    // version the bucket holds no envelope for (spec 03 §5.8 order).
    void keyAdd(uint32_t version, std::span<const uint8_t> key, const std::vector<std::vector<uint8_t>>& envelopes,
                const std::optional<std::string>& keyCheck = std::nullopt);

    // ---- the bucket ----------------------------------------------------------------------------------------------------
    // One HEAD while nothing moved. A new canonical root is reconciled into the working content (another writer's), or
    // recorded (our own, PUT and not recorded). Throws ChainRejected (recorded, alerted once), WriterFloorRefused
    // (status().update_needed), ApplyStopped, and the store's errors.
    RefreshReport refresh();
    // Publishes the working content when it has local changes (the vault's mode, from the store), applying another
    // writer's root first when one won (at most publish_rounds times, then PublishConflict); then deletes the objects
    // of purged files that root no longer names.
    PublishResult publish();
    // Adds this installation to the root's writers at the next publish (it opened the vault from the bucket: another
    // Mac's). Persisted until a recorded root names it. Key hand-over is the caller's (the keys callback must hold
    // every version the vault uses).
    void join();
    // GC and the root janitor, once a day (ChainState::gc_at).
    std::optional<manifest::GcReport> gcIfDue(std::time_t now);
    [[nodiscard]] Status status() const;

private:
    friend class Writer;
    struct Impl;
    explicit Session(std::unique_ptr<Impl> impl);
    std::unique_ptr<Impl> impl_;
};

}
