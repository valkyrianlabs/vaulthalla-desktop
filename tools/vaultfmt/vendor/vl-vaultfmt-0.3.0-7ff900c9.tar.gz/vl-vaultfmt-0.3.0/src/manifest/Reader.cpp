// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/vaultfmt/manifest/Reader.hpp"

#include "vl/vaultfmt/manifest/Objects.hpp"
#include "vl/vaultfmt/manifest/VersionLog.hpp"

#include <format>

#include <algorithm>

namespace vl::vaultfmt::manifest {

namespace reader_detail {

struct RootCandidate {
    RootDocument root;
    std::string sha;
    std::optional<std::string> etag;
    std::vector<uint8_t> bytes;
};

std::optional<RootDocument> tryOpenRoot(const std::vector<uint8_t>& bytes, const Uid& vaultUid,
                                        const vhf1::KeyLookup& keys) {
    try {
        return openRoot(bytes, vaultUid, keys);
    } catch (const vhf1::Error&) {
    } catch (const FormatError&) {
    }
    return std::nullopt;
}

// Root versions read at most (newest first): bounds the GETs a fallback or gap walk costs on a bucket that keeps a long
// history.
constexpr std::size_t kMaxRetainedRootsScanned = 64;

// The authentic roots among the provider's versions of .vaulthalla/root, newest first; listed once, on first use.
class RetainedRoots {
public:
    RetainedRoots(ObjectStore& store, const Uid& vaultUid, const vhf1::KeyLookup& keys, const bool enabled)
        : store_(store), vaultUid_(vaultUid), keys_(keys), enabled_(enabled) {}

    const std::vector<RootCandidate>& all() {
        if (listed_ || !enabled_) return roots_;
        listed_ = true;
        std::vector<StoredVersion> versions;
        try {
            versions = store_.versions(std::string(kRootKey));
        } catch (const std::exception&) {
            return roots_;  // the provider keeps no versions we can list: nothing retained
        }
        std::size_t scanned = 0;
        for (const auto& v : versions) {
            if (v.delete_marker) continue;
            if (++scanned > kMaxRetainedRootsScanned) break;  // newest first: older ones can't matter more
            const auto obj = store_.get(std::string(kRootKey), v.version_id);
            if (!obj) continue;
            if (auto root = tryOpenRoot(obj->bytes, vaultUid_, keys_))
                roots_.push_back({std::move(*root), sha256Hex(obj->bytes), std::nullopt, obj->bytes});
        }
        return roots_;
    }

    std::optional<RootDocument> bySha(const std::string& sha) {
        for (const auto& r : all())
            if (r.sha == sha) return r.root;
        return std::nullopt;
    }

private:
    ObjectStore& store_;
    const Uid& vaultUid_;
    const vhf1::KeyLookup& keys_;
    bool enabled_;
    bool listed_{false};
    std::vector<RootCandidate> roots_;
};

// Fetches and opens the segment `ref` pins: the document, or the problem's name.
struct SegmentAttempt {
    std::optional<SegmentDocument> doc;
    std::string problem;
};

SegmentAttempt openPinned(const SegmentRef& ref, const std::optional<StoredObject>& obj, const Uid& vaultUid,
                          const vhf1::KeyLookup& keys) {
    try {
        checkSegment(ref, obj ? &obj->bytes : nullptr);
        auto doc = openSegment(obj->bytes, vaultUid, parseUid(ref.sid, "bad_root", "segment sid"), keys);
        if (doc.range != ref.range || doc.entries.size() != ref.count)
            return {std::nullopt, "bad_segment"};
        return {std::move(doc), {}};
    } catch (const ChainRejected& e) {
        return {std::nullopt, std::string(chainErrorName(e.code()))};
    } catch (const vhf1::Error& e) {
        return {std::nullopt, std::string(vhf1::errorCodeName(e.code()))};
    } catch (const FormatError& e) {
        return {std::nullopt, e.code()};
    }
}

struct SnapshotAttempt {
    std::optional<SnapshotDocument> doc;
    std::string problem;
};

SnapshotAttempt openPinnedSnapshot(const SnapshotRef& ref, const std::optional<StoredObject>& obj, const Uid& vaultUid,
                                   const vhf1::KeyLookup& keys) {
    try {
        checkSnapshot(ref, obj ? &obj->bytes : nullptr);
        return {openSnapshot(obj->bytes, vaultUid, parseUid(ref.sid, "bad_root", "snapshot sid"), keys), {}};
    } catch (const ChainRejected& e) {
        return {std::nullopt, std::string(chainErrorName(e.code()))};
    } catch (const vhf1::Error& e) {
        return {std::nullopt, std::string(vhf1::errorCodeName(e.code()))};
    } catch (const FormatError& e) {
        return {std::nullopt, e.code()};
    }
}

// (a) for any pinned object: a provider version whose bytes match the pin.
template <typename Attempt, typename Open>
Attempt fromVersions(ObjectStore& store, const std::string& key, const uint64_t size, Open&& open) {
    Attempt last{};
    try {
        for (const auto& v : store.versions(key)) {
            if (v.delete_marker || v.size != size) continue;
            auto attempt = open(store.get(key, v.version_id));
            if (attempt.doc) return attempt;
            last = std::move(attempt);
        }
    } catch (const std::exception&) {
    }
    return last;
}

}

std::string_view to_string(const Resolution resolution) {
    switch (resolution) {
    case Resolution::ProviderVersion: return "provider_version";
    case Resolution::OlderRoot: return "older_root";
    case Resolution::Blind: return "blind";
    }
    return "blind";
}

std::string_view to_string(const Freshness freshness) {
    switch (freshness) {
    case Freshness::Unverified: return "unverified";
    case Freshness::Verified: return "verified";
    case Freshness::RollbackAccepted: return "rollback_accepted";
    }
    return "unverified";
}

Content contentOf(const RootDocument& root, const std::vector<SegmentDocument>& segments,
                  const std::vector<SnapshotDocument>& snapshots) {
    Content c;
    c.producer = root.producer;
    c.vault = root.vault;
    c.keys = root.keys;
    c.recovery_policy = root.recovery_policy;
    for (const auto& s : segments) c.entries.insert(c.entries.end(), s.entries.begin(), s.entries.end());
    for (const auto& s : snapshots) c.snapshots.push_back(s.snapshot);
    normalize(c);
    return c;
}

namespace reader_detail {

// version_log (spec 06 §5.3): the canonical head by rule C1, not the current object.
void chooseVersionLogRoot(ObjectStore& store, const Uid& vaultUid, const vhf1::KeyLookup& keys,
                          const LoadOptions& options, Loaded& out) {
    RootCache local;
    RootLog log(store, vaultUid, keys, options.root_cache ? *options.root_cache : local);
    // From a settled anchor the listing stops at the oldest version it needs (the settled window's base, else the
    // anchor); an anchor missing from that listing gets the whole log (the fallbacks below need it).
    std::optional<std::string> stopAt;
    if (options.known && options.settled) stopAt = options.settled->base_version_id;
    else if (options.known && options.known->version_id) stopAt = options.known->version_id;
    log.list(stopAt);
    if (stopAt && options.known->version_id && !log.indexOf(*options.known->version_id)) log.list();
    if (options.known && options.settled &&
        windowBroken(log, options.settled->base_version_id, options.settled->version_id, options.settled->window))
        throw ChainRejected(ChainError::OrderViolation,
                            "a version appeared between the settled root and its base: the provider's listing order "
                            "changed under a root this server had settled",
                            options.known->epoch, options.known->root_sha256);

    std::optional<Walk> w;
    if (options.known) {
        std::optional<std::size_t> anchor;
        if (options.known->version_id)
            if (const auto i = log.indexOf(*options.known->version_id))
                if (const auto* r = log.open(*i); r && r->sha256 == options.known->root_sha256) anchor = i;
        if (!anchor) anchor = log.findBySha(options.known->root_sha256);
        if (anchor) w = walk(log, *anchor);
        // An authentic root above the anchored head with a higher epoch: the chain from the anchor is incomplete (a
        // version missing in between, a reader whose anchor is behind the bucket, or a broken provider order). Read
        // the newest authentic state instead and judge it against what is known, as when the anchor is gone: a gap
        // when the walk back can't be completed, a fork when it contradicts the anchor. Never repaired away.
        if (w && !w->ahead.empty()) {
            w.reset();
            if (log.partial()) log.list();   // the walk back needs the whole log
        }
    }
    if (w) {
        const auto* head = log.open(w->head);
        out.acceptance = Acceptance{head->root.epoch, head->sha256, false};
    } else {
        // No anchor (a blind read), the anchor is gone from the bucket, or its chain is incomplete: the chain with the
        // highest head epoch, then the chain rules against what the reader knows (rollback, fork, gap), as on a
        // conditional bucket.
        w = walkBlind(log);
        if (!w)
            throw NoUsableRoot(log.versions().empty() ? "the bucket has no manifest root"
                                                      : "no version of the manifest root authenticates");
        const auto* head = log.open(w->head);
        out.acceptance = checkChain(head->root, head->sha256, options.known, [&](const std::string& sha) {
            const auto i = log.findBySha(sha);
            return i ? std::optional<RootDocument>(log.open(*i)->root) : std::nullopt;
        });
    }
    const auto& versions = log.versions();
    const auto* head = log.open(w->head);
    out.root = head->root;
    out.root_bytes = head->bytes;
    out.etag = versions[w->head].etag;
    out.source = RootSource::Current;
    out.version_id = versions[w->head].version_id;
    if (w->chain.size() > 1) {
        const auto base = w->chain[w->chain.size() - 2];
        out.base_version_id = versions[base].version_id;
        out.settle_window = idsBetween(log, base, w->head);
    }
    for (const auto i : w->strays) out.strays.push_back(versions[i].version_id);
    out.root_gets = log.gets();
}

}

Loaded load(ObjectStore& store, const Uid& vaultUid, const vhf1::KeyLookup& keys, const LoadOptions& options) {
    using namespace reader_detail;
    RetainedRoots retained(store, vaultUid, keys, options.use_provider_versions);

    Loaded out;
    bool versionLog = store.mode() == WriteCapability::VersionLog;
    std::optional<StoredObject> current;
    if (!versionLog && store.mode() != WriteCapability::Insufficient) {
        // A root published without conditional writes names its mode: a reader that doesn't know the bucket's
        // capability (a restore) follows it, and reads the canonical head rather than the current object.
        // When the current object is no root (a delete marker or a stray from a crashed write above the head), the
        // newest authentic version says it, as the conditional fallback below would read it anyway.
        current = options.root_object ? options.root_object : store.get(std::string(kRootKey));
        const auto declares = [](const RootDocument& r) { return r.publish == std::string(kPublishVersionLog); };
        if (options.use_provider_versions) {
            std::optional<RootDocument> currentRoot;
            if (current) currentRoot = tryOpenRoot(current->bytes, vaultUid, keys);
            if (currentRoot) versionLog = declares(*currentRoot);
            else if (const auto& all = retained.all(); !all.empty()) versionLog = declares(all.front().root);
        }
    }
    if (versionLog) {
        chooseVersionLogRoot(store, vaultUid, keys, options, out);
    } else {
        std::optional<RootCandidate> cand;
        RootSource source = RootSource::Current;
        if (!current) current = options.root_object ? options.root_object : store.get(std::string(kRootKey));
        if (current)
            if (auto root = tryOpenRoot(current->bytes, vaultUid, keys))
                cand = RootCandidate{std::move(*root), sha256Hex(current->bytes), current->etag, current->bytes};
        if (!cand) {
            if (const auto& all = retained.all(); !all.empty()) {
                cand = all.front();
                source = RootSource::ProviderVersion;
            }
        }
        if (!cand)
            throw NoUsableRoot(current ? "the manifest root does not authenticate, and no retained version does"
                                       : "the bucket has no manifest root");
        out.acceptance = checkChain(cand->root, cand->sha, options.known,
                                    [&](const std::string& sha) { return retained.bySha(sha); });
        out.root = cand->root;
        out.root_bytes = cand->bytes;
        out.etag = source == RootSource::Current ? cand->etag : std::nullopt;
        out.source = source;
    }

    std::vector<SegmentDocument> docs;
    for (const auto& ref : out.root.segments) {
        const auto key = segmentKey(ref.sid);
        const auto open = [&](const std::optional<StoredObject>& obj) { return openPinned(ref, obj, vaultUid, keys); };
        auto object = store.get(key);
        auto attempt = open(object);
        if (attempt.doc) {
            out.segments[ref.range] = {ref, canonicalJson(toJson(*attempt.doc)), std::move(object->bytes)};
            docs.push_back(std::move(*attempt.doc));
            continue;
        }
        SegmentIssue issue{ref.sid, ref.range, attempt.problem, Resolution::Blind, std::nullopt};

        if (options.use_provider_versions) {
            if (auto v = fromVersions<SegmentAttempt>(store, key, ref.size, open); v.doc) {
                issue.resolution = Resolution::ProviderVersion;
                out.issues.push_back(issue);
                out.segments[ref.range] = {ref, canonicalJson(toJson(*v.doc)), {}};
                docs.push_back(std::move(*v.doc));
                continue;
            }
        }

        bool fromOlder = false;
        for (const auto& old : retained.all()) {
            if (old.root.epoch >= out.root.epoch) continue;
            for (const auto& oldRef : old.root.segments) {
                if (oldRef.range.lo > ref.range.lo || oldRef.range.hi < ref.range.hi) continue;
                auto older = openPinned(oldRef, store.get(segmentKey(oldRef.sid)), vaultUid, keys);
                if (!older.doc) continue;
                std::erase_if(older.doc->entries, [&](const Entry& e) {
                    return !ref.range.contains(parseUid(e.uid, "bad_segment", "entry uid"));
                });
                older.doc->range = ref.range;
                issue.resolution = Resolution::OlderRoot;
                issue.from_epoch = old.root.epoch;
                docs.push_back(std::move(*older.doc));
                fromOlder = true;
                break;
            }
            if (fromOlder) break;
        }
        if (!fromOlder) out.blind_ranges.push_back(ref.range);
        out.issues.push_back(issue);
    }

    std::vector<SnapshotDocument> snaps;
    for (const auto& ref : out.root.snapshots) {
        const auto key = segmentKey(ref.sid);
        const auto open = [&](const std::optional<StoredObject>& obj) {
            return openPinnedSnapshot(ref, obj, vaultUid, keys);
        };
        auto object = store.get(key);
        auto attempt = open(object);
        std::vector<uint8_t> sealed;
        if (attempt.doc) sealed = std::move(object->bytes);
        if (!attempt.doc && options.use_provider_versions) {
            auto v = fromVersions<SnapshotAttempt>(store, key, ref.size, open);
            if (v.doc) {
                out.issues.push_back({ref.sid, std::nullopt, attempt.problem, Resolution::ProviderVersion, {}});
                attempt = std::move(v);
            }
        }
        if (!attempt.doc) {
            out.issues.push_back({ref.sid, std::nullopt, attempt.problem, Resolution::Blind, {}});
            continue;
        }
        out.snapshots[snapshotKey(attempt.doc->snapshot)] = {ref, canonicalJson(toJson(*attempt.doc)), std::move(sealed)};
        snaps.push_back(std::move(*attempt.doc));
    }

    out.content = contentOf(out.root, docs, snaps);
    return out;
}

std::optional<BaseCopy> baseCopyOf(const RootDocument& root, const std::vector<uint8_t>& rootBytes,
                                   const std::map<Range, LoadedSegment>& segments,
                                   const std::map<std::string, LoadedSnapshot>& snapshots) {
    if (rootBytes.empty()) return std::nullopt;
    BaseCopy copy;
    copy.root = rootBytes;
    for (const auto& [_, s] : segments)
        if (!s.sealed.empty() && std::ranges::any_of(root.segments, [&](const SegmentRef& r) { return r.sid == s.ref.sid; }))
            copy.objects[s.ref.sid] = s.sealed;
    for (const auto& [_, s] : snapshots)
        if (!s.sealed.empty() && std::ranges::any_of(root.snapshots, [&](const SnapshotRef& r) { return r.sid == s.ref.sid; }))
            copy.objects[s.ref.sid] = s.sealed;
    return copy;
}

std::optional<Content> openBaseCopy(const BaseCopy& copy, const Uid& vaultUid, const vhf1::KeyLookup& keys,
                                    const Known& known, std::string* why) {
    using namespace reader_detail;
    const auto fail = [&](std::string reason) -> std::optional<Content> {
        if (why) *why = std::move(reason);
        return std::nullopt;
    };
    if (copy.root.empty()) return fail("no root bytes");
    if (sha256Hex(copy.root) != known.root_sha256) return fail("the copy is of another root than the recorded one");
    const auto root = tryOpenRoot(copy.root, vaultUid, keys);
    if (!root) return fail("the root does not authenticate");
    if (root->epoch != known.epoch) return fail("the root's epoch is not the recorded one");
    std::vector<SegmentDocument> docs;
    for (const auto& ref : root->segments) {
        const auto it = copy.objects.find(ref.sid);
        if (it == copy.objects.end()) return fail("segment " + ref.sid + " is missing");
        const std::optional<StoredObject> obj = StoredObject{it->second, std::nullopt, std::nullopt};
        auto attempt = openPinned(ref, obj, vaultUid, keys);
        if (!attempt.doc) return fail("segment " + ref.sid + ": " + attempt.problem);
        docs.push_back(std::move(*attempt.doc));
    }
    std::vector<SnapshotDocument> snaps;
    for (const auto& ref : root->snapshots) {
        const auto it = copy.objects.find(ref.sid);
        if (it == copy.objects.end()) return fail("snapshot segment " + ref.sid + " is missing");
        const std::optional<StoredObject> obj = StoredObject{it->second, std::nullopt, std::nullopt};
        auto attempt = openPinnedSnapshot(ref, obj, vaultUid, keys);
        if (!attempt.doc) return fail("snapshot segment " + ref.sid + ": " + attempt.problem);
        snaps.push_back(std::move(*attempt.doc));
    }
    return contentOf(*root, docs, snaps);
}

BlindReport blindRebuild(ObjectStore& store, const Uid& vaultUid, const vhf1::KeyLookup& keys,
                         const std::optional<Range>& only) {
    BlindReport report;
    for (const auto& listed : store.list(std::string(kObjectPrefix))) {
        const auto uid = uidOfObjectKey(listed.key);
        if (!uid) {
            report.rejected.push_back(listed.key + ": not an o/<uid> key");
            continue;
        }
        if (only && !only->contains(*uid)) continue;
        const auto head = store.getRange(listed.key, 0, vhf1::kHeaderSize);
        if (!head) continue;  // deleted since the listing
        report.header_bytes += head->size();
        try {
            const auto header = vhf1::openHeader(
                *head, {vhf1::Kind::FileContent, vaultUid, *uid, std::nullopt}, keys);
            const auto layout = vhf1::layoutFor(listed.size, header.params().chunkLog2);
            RecoveredObject r;
            r.uid = *uid;
            r.key = listed.key;
            r.path = "/Recovered/" + uidText(*uid);
            r.object_size = listed.size;
            r.plaintext_size = layout.plaintextSize;
            r.key_version = header.params().keyVersion;
            for (const auto b : header.params().salt) r.generation += std::format("{:02x}", b);
            report.recovered.push_back(std::move(r));
        } catch (const vhf1::Error& e) {
            report.rejected.push_back(std::format("{}: {}", listed.key, vhf1::errorCodeName(e.code())));
        }
    }
    return report;
}

Loaded loadCanonicalRoot(ObjectStore& store, const Uid& vaultUid, const vhf1::KeyLookup& keys,
                         const LoadOptions& options) {
    Loaded out;
    reader_detail::chooseVersionLogRoot(store, vaultUid, keys, options, out);
    return out;
}

RestoreLoad loadForRestore(ObjectStore& store, const Uid& vaultUid, const vhf1::KeyLookup& keys,
                           const std::optional<Checkpoint>& checkpoint, const bool acceptRollback) {
    if (!checkpoint) return {load(store, vaultUid, keys, {}), Freshness::Unverified, std::string(kFreshnessUnverified)};
    try {
        LoadOptions options;
        options.known = Known{checkpoint->epoch, checkpoint->root_sha256};
        auto loaded = load(store, vaultUid, keys, options);
        auto report = std::format("freshness verified against the checkpoint of epoch {}: the root is epoch {}",
                                  checkpoint->epoch, loaded.root.epoch);
        return {std::move(loaded), Freshness::Verified, std::move(report)};
    } catch (const ChainRejected& e) {
        if (e.code() != ChainError::Rollback || !acceptRollback) throw;
    }
    auto loaded = load(store, vaultUid, keys, {});
    auto report = std::format("rollback accepted: the root is epoch {}, older than the checkpoint of epoch {}",
                              loaded.root.epoch, checkpoint->epoch);
    return {std::move(loaded), Freshness::RollbackAccepted, std::move(report)};
}

}
