/* SPDX-License-Identifier: AGPL-3.0-or-later */
/* Copyright (c) 2026 Valkyrian Labs LLC */
/*
 * A whole vault's lifecycle through the engine's C API alone, compiled as C (C11): an in-memory versioned bucket that
 * answers as Backblaze B2 does (version_log: conditional PUTs refused, every PUT a version), keys and a state blob, all
 * as C callbacks, the way Desktop's Swift implements them. test_c_engine.cpp runs it.
 */
#include "vl/vaultfmt/vl_vaultfmt_engine.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---- the bucket ---------------------------------------------------------------------------------------------------- */

typedef struct {
    char* key;
    char vid[24];
    uint8_t* body;
    size_t len;
    int marker;
    int gone;   /* removed by version id */
    int64_t at;
} version_t;

typedef struct {
    version_t* v;
    size_t n, cap;
    unsigned seq;
    unsigned requests;
} bucket_t;

static char* dup_text(const char* p, size_t n) {
    char* s = (char*)malloc(n + 1);
    if (!s) abort();
    if (n) memcpy(s, p, n);
    s[n] = '\0';
    return s;
}

static int key_is(const version_t* v, const char* key, size_t len) {
    return strlen(v->key) == len && memcmp(v->key, key, len) == 0;
}

static version_t* add_version(bucket_t* b, const char* key, size_t key_len, const uint8_t* body, size_t len, int marker) {
    version_t* v;
    if (b->n == b->cap) {
        b->cap = b->cap ? 2 * b->cap : 64;
        b->v = (version_t*)realloc(b->v, b->cap * sizeof *b->v);
        if (!b->v) abort();
    }
    v = &b->v[b->n++];
    memset(v, 0, sizeof *v);
    v->key = dup_text(key, key_len);
    snprintf(v->vid, sizeof v->vid, "v%06u", ++b->seq);
    v->body = (uint8_t*)malloc(len ? len : 1);
    if (!v->body) abort();
    if (len) memcpy(v->body, body, len);
    v->len = len;
    v->marker = marker;
    v->at = 1800000000 + (int64_t)b->seq;
    return v;
}

/* The newest version of key (or the version `vid`), NULL when none or a delete marker. */
static version_t* find_version(bucket_t* b, const char* key, size_t key_len, const char* vid, size_t vid_len) {
    size_t i;
    for (i = b->n; i-- > 0;) {
        version_t* v = &b->v[i];
        if (v->gone || !key_is(v, key, key_len)) continue;
        if (vid) {
            if (strlen(v->vid) == vid_len && memcmp(v->vid, vid, vid_len) == 0) return v->marker ? NULL : v;
            continue;
        }
        return v->marker ? NULL : v;
    }
    return NULL;
}

static void reply_meta(vl_vaultfmt_reply* r, const version_t* v) {
    char etag[32];
    snprintf(etag, sizeof etag, "\"e%s\"", v->vid);
    vl_vaultfmt_reply_etag(r, etag, strlen(etag));
    vl_vaultfmt_reply_version_id(r, v->vid, strlen(v->vid));
}

static vl_vaultfmt_status s_get(void* ctx, const char* key, size_t key_len, const char* vid, size_t vid_len,
                                vl_vaultfmt_reply* r) {
    bucket_t* b = (bucket_t*)ctx;
    version_t* v = find_version(b, key, key_len, vid, vid_len);
    ++b->requests;
    if (!v) return VL_VAULTFMT_ERR_NOT_FOUND;
    vl_vaultfmt_reply_body(r, v->body, v->len);
    reply_meta(r, v);
    return VL_VAULTFMT_OK;
}

static vl_vaultfmt_status s_get_range(void* ctx, const char* key, size_t key_len, const char* vid, size_t vid_len,
                                      uint64_t offset, uint64_t length, vl_vaultfmt_reply* r) {
    bucket_t* b = (bucket_t*)ctx;
    version_t* v = find_version(b, key, key_len, vid, vid_len);
    ++b->requests;
    if (!v) return VL_VAULTFMT_ERR_NOT_FOUND;
    if (offset < v->len) {
        uint64_t end = offset + length < v->len ? offset + length : v->len;
        vl_vaultfmt_reply_body(r, v->body + offset, (size_t)(end - offset));
    }
    vl_vaultfmt_reply_total(r, v->len);
    return VL_VAULTFMT_OK;
}

static vl_vaultfmt_status s_head(void* ctx, const char* key, size_t key_len, vl_vaultfmt_reply* r) {
    bucket_t* b = (bucket_t*)ctx;
    version_t* v = find_version(b, key, key_len, NULL, 0);
    ++b->requests;
    if (!v) return VL_VAULTFMT_ERR_NOT_FOUND;
    reply_meta(r, v);
    return VL_VAULTFMT_OK;
}

static vl_vaultfmt_status s_put(void* ctx, const char* key, size_t key_len, const uint8_t* bytes, size_t len,
                                int32_t condition, const char* if_match, size_t if_match_len, vl_vaultfmt_reply* r) {
    bucket_t* b = (bucket_t*)ctx;
    (void)if_match;
    (void)if_match_len;
    ++b->requests;
    if (condition != VL_VAULTFMT_PUT_PLAIN) return VL_VAULTFMT_ERR_STORE_CONDITIONS_UNSUPPORTED; /* as B2 answers */
    reply_meta(r, add_version(b, key, key_len, bytes, len, 0));
    return VL_VAULTFMT_OK;
}

static int cmp_text(const void* a, const void* b) { return strcmp(*(const char* const*)a, *(const char* const*)b); }

/* The distinct keys starting with prefix (exact: equal to it), ascending. The caller frees the array. */
static const char** keys_of(bucket_t* b, const char* prefix, size_t len, int exact, size_t* count) {
    const char** keys = (const char**)malloc((b->n + 1) * sizeof *keys);
    size_t i, j, n = 0;
    if (!keys) abort();
    for (i = 0; i < b->n; ++i) {
        const version_t* v = &b->v[i];
        int seen = 0;
        if (v->gone) continue;
        if (exact ? !key_is(v, prefix, len) : (strlen(v->key) < len || memcmp(v->key, prefix, len) != 0)) continue;
        for (j = 0; j < n; ++j)
            if (strcmp(keys[j], v->key) == 0) seen = 1;
        if (!seen) keys[n++] = v->key;
    }
    qsort(keys, n, sizeof *keys, cmp_text);
    *count = n;
    return keys;
}

static vl_vaultfmt_status s_list(void* ctx, const char* prefix, size_t len, vl_vaultfmt_reply* r) {
    bucket_t* b = (bucket_t*)ctx;
    size_t n, i;
    const char** keys = keys_of(b, prefix, len, 0, &n);
    ++b->requests;
    for (i = 0; i < n; ++i) {
        version_t* v = find_version(b, keys[i], strlen(keys[i]), NULL, 0);
        char etag[32];
        if (!v) continue;
        snprintf(etag, sizeof etag, "\"e%s\"", v->vid);
        vl_vaultfmt_reply_listed(r, v->key, strlen(v->key), v->len, v->at, etag, strlen(etag));
    }
    free((void*)keys);
    return VL_VAULTFMT_OK;
}

static vl_vaultfmt_status s_versions(void* ctx, const char* key, size_t key_len, const char* stop_at, size_t stop_len,
                                     int32_t under, vl_vaultfmt_reply* r) {
    bucket_t* b = (bucket_t*)ctx;
    size_t n, i, k;
    const char** keys = keys_of(b, key, key_len, !under, &n);
    (void)stop_at; /* listing everything is allowed: the library cuts at stop_at itself */
    (void)stop_len;
    ++b->requests;
    for (k = 0; k < n; ++k) {
        int latest = 1;
        for (i = b->n; i-- > 0;) {
            const version_t* v = &b->v[i];
            char etag[32] = "";
            if (v->gone || strcmp(v->key, keys[k]) != 0) continue;
            if (!v->marker) snprintf(etag, sizeof etag, "\"e%s\"", v->vid);
            vl_vaultfmt_reply_version(r, v->key, strlen(v->key), v->vid, strlen(v->vid), v->marker ? 0 : v->len, v->at,
                                      v->marker, etag, strlen(etag), latest);
            latest = 0;
        }
    }
    free((void*)keys);
    return VL_VAULTFMT_OK;
}

static vl_vaultfmt_status s_remove(void* ctx, const char* key, size_t key_len, const char* vid, size_t vid_len) {
    bucket_t* b = (bucket_t*)ctx;
    size_t i;
    ++b->requests;
    if (!vid) {
        add_version(b, key, key_len, NULL, 0, 1);
        return VL_VAULTFMT_OK;
    }
    for (i = 0; i < b->n; ++i)
        if (key_is(&b->v[i], key, key_len) && strlen(b->v[i].vid) == vid_len && memcmp(b->v[i].vid, vid, vid_len) == 0)
            b->v[i].gone = 1;
    return VL_VAULTFMT_OK;
}

typedef struct {
    char* key;
    uint8_t* buf;
    size_t len, cap;
} upload_t;

static vl_vaultfmt_status s_content_begin(void* ctx, const char* key, size_t key_len, uint64_t size, void** out) {
    upload_t* u = (upload_t*)calloc(1, sizeof *u);
    (void)ctx;
    if (!u) return VL_VAULTFMT_ERR_OUT_OF_MEMORY;
    u->key = dup_text(key, key_len);
    u->cap = size != VL_VAULTFMT_SIZE_UNKNOWN && size > 0 ? (size_t)size : 1024;
    u->buf = (uint8_t*)malloc(u->cap);
    if (!u->buf) abort();
    *out = u;
    return VL_VAULTFMT_OK;
}

static vl_vaultfmt_status s_content_write(void* ctx, void* upload, const uint8_t* bytes, size_t len) {
    upload_t* u = (upload_t*)upload;
    (void)ctx;
    while (u->len + len > u->cap) {
        u->cap *= 2;
        u->buf = (uint8_t*)realloc(u->buf, u->cap);
        if (!u->buf) abort();
    }
    memcpy(u->buf + u->len, bytes, len);
    u->len += len;
    return VL_VAULTFMT_OK;
}

static void s_content_abort(void* ctx, void* upload) {
    upload_t* u = (upload_t*)upload;
    (void)ctx;
    free(u->key);
    free(u->buf);
    free(u);
}

static vl_vaultfmt_status s_content_finish(void* ctx, void* upload, vl_vaultfmt_reply* r) {
    bucket_t* b = (bucket_t*)ctx;
    upload_t* u = (upload_t*)upload;
    ++b->requests;
    reply_meta(r, add_version(b, u->key, strlen(u->key), u->buf, u->len, 0));
    s_content_abort(ctx, upload);
    return VL_VAULTFMT_OK;
}

static void bucket_free(bucket_t* b) {
    size_t i;
    for (i = 0; i < b->n; ++i) {
        free(b->v[i].key);
        free(b->v[i].body);
    }
    free(b->v);
}

/* ---- keys and state ------------------------------------------------------------------------------------------------ */

typedef struct {
    uint8_t key[32];
} keys_t;

static vl_vaultfmt_status k_lookup(void* ctx, uint32_t version, uint8_t key[32]) {
    if (version != 1) return VL_VAULTFMT_ERR_NOT_FOUND;
    memcpy(key, ((keys_t*)ctx)->key, 32);
    return VL_VAULTFMT_OK;
}

static vl_vaultfmt_status k_current(void* ctx, uint32_t* version) {
    (void)ctx;
    *version = 1;
    return VL_VAULTFMT_OK;
}

typedef struct {
    uint8_t* bytes;
    size_t len;
    int has;
    unsigned saves, appends;
} blob_t;

static vl_vaultfmt_status st_load(void* ctx, vl_vaultfmt_reply* r) {
    blob_t* b = (blob_t*)ctx;
    if (!b->has) return VL_VAULTFMT_ERR_NOT_FOUND;
    return vl_vaultfmt_reply_body(r, b->bytes, b->len);
}

static vl_vaultfmt_status st_save(void* ctx, const uint8_t* bytes, size_t len) {
    blob_t* b = (blob_t*)ctx;
    free(b->bytes);
    b->bytes = (uint8_t*)malloc(len ? len : 1);
    if (!b->bytes) return VL_VAULTFMT_ERR_OUT_OF_MEMORY;
    memcpy(b->bytes, bytes, len);
    b->len = len;
    b->has = 1;
    ++b->saves;
    return VL_VAULTFMT_OK;
}

static vl_vaultfmt_status st_append(void* ctx, const uint8_t* bytes, size_t len) {
    blob_t* b = (blob_t*)ctx;
    uint8_t* grown = (uint8_t*)realloc(b->bytes, b->len + len);
    if (!grown) return VL_VAULTFMT_ERR_OUT_OF_MEMORY;
    b->bytes = grown;
    memcpy(b->bytes + b->len, bytes, len);
    b->len += len;
    ++b->appends;
    return VL_VAULTFMT_OK;
}

/* ---- the lifecycle ------------------------------------------------------------------------------------------------- */

typedef struct {
    uint8_t* bytes;
    size_t len;
} sink_t;

static int32_t collect(void* ctx, const uint8_t* bytes, size_t len) {
    sink_t* s = (sink_t*)ctx;
    uint8_t* grown = (uint8_t*)realloc(s->bytes, s->len + len);
    if (!grown) return 1;
    s->bytes = grown;
    memcpy(s->bytes + s->len, bytes, len);
    s->len += len;
    return 0;
}

static int64_t clock_now(void* ctx) { return (*(int64_t*)ctx)++; }

#define CHECK(call)                                                                                                    \
    do {                                                                                                               \
        vl_vaultfmt_status s_ = (call);                                                                                \
        if (s_ != VL_VAULTFMT_OK) {                                                                                    \
            snprintf(why, why_cap, "line %d: %s -> %s", __LINE__, #call, vl_vaultfmt_status_name(s_));                  \
            goto done;                                                                                                 \
        }                                                                                                              \
    } while (0)
#define REQUIRE(cond)                                                                                                  \
    do {                                                                                                               \
        if (!(cond)) {                                                                                                 \
            snprintf(why, why_cap, "line %d: %s", __LINE__, #cond);                                                    \
            goto done;                                                                                                 \
        }                                                                                                              \
    } while (0)

static vl_vaultfmt_status open_vault(const uint8_t uid[16], bucket_t* bucket, keys_t* keys, blob_t* blob,
                                     int64_t* clock, const char* create, vl_vaultfmt_open_info* info,
                                     vl_vaultfmt_vault** out) {
    vl_vaultfmt_store_table store;
    vl_vaultfmt_keys_table kt;
    vl_vaultfmt_state_table st;
    vl_vaultfmt_vault_options o;
    memset(&store, 0, sizeof store);
    store.ctx = bucket;
    store.mode = VL_VAULTFMT_MODE_VERSION_LOG;
    store.get = s_get;
    store.get_range = s_get_range;
    store.head = s_head;
    store.put = s_put;
    store.list = s_list;
    store.versions = s_versions;
    store.remove = s_remove;
    store.content_begin = s_content_begin;
    store.content_write = s_content_write;
    store.content_finish = s_content_finish;
    store.content_abort = s_content_abort;
    kt.ctx = keys;
    kt.lookup = k_lookup;
    kt.current = k_current;
    st.ctx = blob;
    st.load = st_load;
    st.save = st_save;
    st.append = st_append;
    memset(&o, 0, sizeof o);
    o.node_id = "desktop-c";
    o.node_id_len = strlen(o.node_id);
    o.software = "c lifecycle";
    o.software_len = strlen(o.software);
    o.create_name = create;
    o.create_name_len = create ? strlen(create) : 0;
    o.now = clock_now;
    o.now_ctx = clock;
    return vl_vaultfmt_vault_open(uid, &store, &kt, &st, &o, info, out);
}

int vl_vaultfmt_c_engine_lifecycle(const uint8_t key[32], const uint8_t* envelope, size_t envelope_len, char* why,
                                   size_t why_cap);

int vl_vaultfmt_c_engine_lifecycle(const uint8_t key[32], const uint8_t* envelope, size_t envelope_len, char* why,
                                   size_t why_cap) {
    int ok = 0;
    uint8_t uid[16];
    bucket_t bucket;
    keys_t keys;
    blob_t blob, empty;
    int64_t clock = 1800000000;
    vl_vaultfmt_vault* vault = NULL;
    vl_vaultfmt_vault* other = NULL;
    vl_vaultfmt_listing* listing = NULL;
    vl_vaultfmt_write* write = NULL;
    vl_vaultfmt_open_info info;
    vl_vaultfmt_publish_info pub;
    vl_vaultfmt_refresh_info ref;
    vl_vaultfmt_vault_status status;
    vl_vaultfmt_changes_info changes;
    vl_vaultfmt_entry entry;
    vl_vaultfmt_bytes env;
    sink_t sink = {NULL, 0};
    uint8_t* content = NULL;
    size_t content_len = 150000, i;
    char root[VL_VAULTFMT_UID_TEXT_SIZE + 1], docs[VL_VAULTFMT_UID_TEXT_SIZE + 1], file[VL_VAULTFMT_UID_TEXT_SIZE + 1];
    size_t len;
    int32_t conflict = -1;

    memset(&bucket, 0, sizeof bucket);
    memset(&blob, 0, sizeof blob);
    memset(&empty, 0, sizeof empty);
    memcpy(keys.key, key, 32);
    for (i = 0; i < 16; ++i) uid[i] = (uint8_t)(0x56 + i);
    content = (uint8_t*)malloc(content_len);
    if (!content) abort();
    for (i = 0; i < content_len; ++i) content[i] = (uint8_t)(i * 13 + (i >> 8));

    /* Nothing to open without a name; then a new vault. */
    REQUIRE(open_vault(uid, &bucket, &keys, &blob, &clock, NULL, &info, &vault) == VL_VAULTFMT_ERR_NO_VAULT);
    REQUIRE(info.message[0] != '\0');
    CHECK(open_vault(uid, &bucket, &keys, &blob, &clock, "Finance", &info, &vault));
    REQUIRE(info.anchor == VL_VAULTFMT_ANCHOR_CREATED);

    len = VL_VAULTFMT_UID_TEXT_SIZE;
    CHECK(vl_vaultfmt_vault_root(vault, root, &len));
    root[len] = '\0';
    /* No key yet: nothing is sealed. */
    REQUIRE(vl_vaultfmt_write_begin(vault, root, strlen(root), "x", 1, NULL, 0, NULL, 0, VL_VAULTFMT_SIZE_UNKNOWN,
                                    &write) == VL_VAULTFMT_ERR_KEY_NOT_ADDED);
    REQUIRE(vl_vaultfmt_vault_key_add(vault, 1, key, 32, NULL, 0, NULL, 0) == VL_VAULTFMT_ERR_RECIPIENT_REQUIRED);
    env.bytes = envelope;
    env.len = envelope_len;
    CHECK(vl_vaultfmt_vault_key_add(vault, 1, key, 32, &env, 1, NULL, 0));

    /* A folder and a file streamed in pieces. */
    CHECK(vl_vaultfmt_vault_mkdir(vault, root, strlen(root), "Docs", 4, &listing));
    CHECK(vl_vaultfmt_listing_entry(listing, 0, &entry));
    memcpy(docs, entry.uid, VL_VAULTFMT_UID_TEXT_SIZE);
    docs[VL_VAULTFMT_UID_TEXT_SIZE] = '\0';
    vl_vaultfmt_listing_free(listing);
    listing = NULL;
    REQUIRE(vl_vaultfmt_vault_mkdir(vault, root, strlen(root), "Docs", 4, NULL) == VL_VAULTFMT_ERR_NAME_EXISTS);
    CHECK(vl_vaultfmt_write_begin(vault, docs, strlen(docs), "report.pdf", 10, NULL, 0, NULL, 0, content_len, &write));
    for (i = 0; i < content_len; i += 40000)
        CHECK(vl_vaultfmt_write_chunk(write, content + i, content_len - i < 40000 ? content_len - i : 40000));
    CHECK(vl_vaultfmt_write_finish(write, &conflict, &listing));
    vl_vaultfmt_write_free(write);
    write = NULL;
    REQUIRE(conflict == 0);
    CHECK(vl_vaultfmt_listing_entry(listing, 0, &entry));
    REQUIRE(entry.kind == VL_VAULTFMT_ENTRY_FILE && entry.has_size && entry.size == content_len && entry.version_id);
    REQUIRE(vl_vaultfmt_listing_version_count(listing, 0) == 1);
    memcpy(file, entry.uid, VL_VAULTFMT_UID_TEXT_SIZE);
    file[VL_VAULTFMT_UID_TEXT_SIZE] = '\0';
    vl_vaultfmt_listing_free(listing);
    listing = NULL;

    /* Read back: only authenticated plaintext, all of it. */
    CHECK(vl_vaultfmt_vault_read(vault, file, strlen(file), NULL, 0, 0, UINT64_MAX, collect, &sink));
    REQUIRE(sink.len == content_len && memcmp(sink.bytes, content, content_len) == 0);
    REQUIRE(blob.appends >= 3);   /* every operation journalled */

    CHECK(vl_vaultfmt_vault_rename(vault, file, strlen(file), "final.pdf", 9));
    CHECK(vl_vaultfmt_vault_status_get(vault, &status));
    REQUIRE(status.unpublished == 1);
    CHECK(vl_vaultfmt_vault_publish(vault, &pub));
    REQUIRE(pub.published == 1 && pub.epoch == 1);
    CHECK(vl_vaultfmt_vault_status_get(vault, &status));
    REQUIRE(status.unpublished == 0 && status.has_known && status.epoch == 1);
    bucket.requests = 0;
    CHECK(vl_vaultfmt_vault_refresh(vault, &ref));
    REQUIRE(ref.moved == 0 && bucket.requests == 1);   /* one HEAD */

    /* Changes since an anchor. */
    CHECK(vl_vaultfmt_vault_changes(vault, status.generation, status.revision, &changes, &listing));
    REQUIRE(changes.expired == 0 && vl_vaultfmt_listing_count(listing) == 0);
    vl_vaultfmt_listing_free(listing);
    listing = NULL;
    CHECK(vl_vaultfmt_vault_trash_entry(vault, file, strlen(file)));
    CHECK(vl_vaultfmt_vault_changes(vault, status.generation, status.revision, &changes, &listing));
    REQUIRE(vl_vaultfmt_listing_count(listing) == 1);
    CHECK(vl_vaultfmt_listing_entry(listing, 0, &entry));
    REQUIRE(entry.trashed == 1);
    vl_vaultfmt_listing_free(listing);
    listing = NULL;
    CHECK(vl_vaultfmt_vault_restore(vault, file, strlen(file), NULL, 0, NULL, 0));
    CHECK(vl_vaultfmt_vault_publish(vault, &pub));
    REQUIRE(pub.published == 1 && pub.epoch == 2);

    /* Close and open again from the state: no request needed to list. */
    vl_vaultfmt_vault_free(vault);
    vault = NULL;
    CHECK(open_vault(uid, &bucket, &keys, &blob, &clock, NULL, &info, &vault));
    REQUIRE(info.anchor == VL_VAULTFMT_ANCHOR_STATE && info.state == VL_VAULTFMT_STATE_LOADED && info.epoch == 2);
    CHECK(vl_vaultfmt_vault_list(vault, docs, strlen(docs), &listing));
    REQUIRE(vl_vaultfmt_listing_count(listing) == 1);
    CHECK(vl_vaultfmt_listing_entry(listing, 0, &entry));
    REQUIRE(entry.name_len == 9 && memcmp(entry.name, "final.pdf", 9) == 0);
    vl_vaultfmt_listing_free(listing);
    listing = NULL;

    /* Another installation with no state re-anchors from the bucket and reads the file. */
    CHECK(open_vault(uid, &bucket, &keys, &empty, &clock, NULL, &info, &other));
    REQUIRE(info.anchor == VL_VAULTFMT_ANCHOR_REANCHORED && info.freshness_verified == 0 && info.epoch == 2);
    free(sink.bytes);
    sink.bytes = NULL;
    sink.len = 0;
    CHECK(vl_vaultfmt_vault_read(other, file, strlen(file), NULL, 0, 0, UINT64_MAX, collect, &sink));
    REQUIRE(sink.len == content_len && memcmp(sink.bytes, content, content_len) == 0);
    vl_vaultfmt_vault_free(other);
    other = NULL;

    /* Purge: the objects go once a root without the file settled. */
    CHECK(vl_vaultfmt_vault_purge(vault, file, strlen(file)));
    REQUIRE(vl_vaultfmt_vault_stat(vault, file, strlen(file), &listing) == VL_VAULTFMT_ERR_NOT_FOUND);
    CHECK(vl_vaultfmt_vault_publish(vault, &pub));
    REQUIRE(pub.published == 1 && pub.purged == 1);
    REQUIRE(vl_vaultfmt_vault_read(vault, file, strlen(file), NULL, 0, 0, 1, collect, &sink) == VL_VAULTFMT_ERR_NOT_FOUND);
    len = 0;
    REQUIRE(vl_vaultfmt_vault_last_error(vault, NULL, &len) == VL_VAULTFMT_ERR_BUFFER_TOO_SMALL && len > 0);
    ok = 1;

done:
    vl_vaultfmt_write_free(write);
    vl_vaultfmt_listing_free(listing);
    vl_vaultfmt_vault_free(other);
    vl_vaultfmt_vault_free(vault);
    bucket_free(&bucket);
    free(blob.bytes);
    free(empty.bytes);
    free(sink.bytes);
    free(content);
    return ok;
}
