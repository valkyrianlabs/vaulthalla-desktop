// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
// The database-free engine (include/vl/vaultfmt/engine/Session.hpp; docs/engine.md), on the in-memory bucket in both
// publish modes (a test's name ends in /VersionLog or /Conditional) and through the hooking store for crashes.
//
// EngineOps          the operations: tree changes, streamed writes and authenticated reads, keys, publish and refresh
// EngineDurability   decision 8: an operation that returned survives a crash; what a lost Mac can lose, and no more
// EngineCrash        a crash between a root's PUT and its record, a PUT that lands late, another writer building on
//                    our unrecorded root, and a crash before every request of a publish
// EngineTwoMacs      the applier's rules through refresh: edit beats delete, both generations of a two-sided content
//                    change, the head's placement, a publish that loses a round
// EngineFloor        a head above the engine's writer revision is neither applied nor published over

#include "engine_support.hpp"

#include "vl/vaultfmt/ObjectKeys.hpp"
#include "vl/vaultfmt/manifest/Objects.hpp"
#include "vl/vaultfmt/manifest/Publisher.hpp"

#include <gtest/gtest.h>

#include <algorithm>

namespace vl::vaultfmt::test_engine {

using namespace test_engine_support;

// Outside the anonymous namespace: the suites derive from it (GCC's -Wsubobject-linkage in a unity build).
class Modes : public ::testing::TestWithParam<mf::WriteCapability> {};

inline std::string modeName(const ::testing::TestParamInfo<mf::WriteCapability>& info) {
    return info.param == mf::WriteCapability::VersionLog ? "VersionLog" : "Conditional";
}

namespace {

// The entries a reader of the bucket sees, without what each writer stamps itself.
std::vector<mf::Entry> comparable(std::vector<mf::Entry> es) {
    for (auto& e : es) {
        e.names.clear();
        e.ctime.reset();   // each writer's own (reconcile keeps ours)
        if (e.kind == mf::EntryKind::Dir) e.mtime.reset();
        for (auto& v : e.versions) v.noncurrent_at.reset();
    }
    return es;
}

std::vector<mf::Entry> everything(const en::Session& e) {
    std::vector<mf::Entry> out;
    std::vector<std::string> dirs{e.rootUid()};
    out.push_back(*e.stat(e.rootUid()));
    for (std::size_t i = 0; i < dirs.size(); ++i)
        for (const auto& x : e.list(dirs[i])) {
            out.push_back(x);
            if (x.kind == mf::EntryKind::Dir) dirs.push_back(x.uid);
        }
    for (const auto& t : e.trash()) out.push_back(t);
    std::ranges::sort(out, {}, &mf::Entry::uid);
    return out;
}

}

// ---- EngineOps -------------------------------------------------------------------------------------------------------

class EngineOps : public Modes {};

TEST_P(EngineOps, AVaultLivesThroughTheOperationsAndAFreshReaderSeesWhatWasPublished) {
    World w(GetParam());
    Mac a(w, "mac-a");
    auto& e = created(a);
    EXPECT_EQ(a.report.anchor, en::Anchor::Created);
    const auto root = e.rootUid();
    const auto docs = e.mkdir(root, "Docs");
    const auto bytes = pattern(200'000, 3);   // four 64 KiB chunks
    const auto f = writeFile(e, docs.uid, "report.pdf", bytes);
    EXPECT_EQ(f.size, bytes.size());
    EXPECT_EQ(f.key_version, 1u);
    EXPECT_EQ(readAll(e, f.uid), bytes);
    std::vector<uint8_t> mid;
    e.read(f.uid, std::nullopt, 70'000, 1000, [&](auto b) { mid.insert(mid.end(), b.begin(), b.end()); });
    EXPECT_EQ(mid, std::vector<uint8_t>(bytes.begin() + 70'000, bytes.begin() + 71'000));
    (void)e.rename(f.uid, "final.pdf");
    const auto archive = e.mkdir(root, "Archive");
    (void)e.move(docs.uid, archive.uid);
    EXPECT_THROW((void)e.move(archive.uid, docs.uid), en::Refused);   // into itself
    EXPECT_THROW((void)e.mkdir(archive.uid, "Docs"), en::Refused);    // the name is taken
    EXPECT_TRUE(e.status().unpublished);
    const auto p = e.publish();
    EXPECT_TRUE(p.published);
    EXPECT_FALSE(e.status().unpublished);
    EXPECT_FALSE(e.publish().published);   // nothing changed: nothing written

    const auto h = head(w);
    EXPECT_EQ(h.root.publish, GetParam() == mf::WriteCapability::VersionLog ? "version_log" : "conditional");
    EXPECT_EQ(h.root.writers, std::optional<std::vector<std::string>>({"mac-a"}));
    EXPECT_EQ(comparable(h.content.entries), comparable(everything(e)));

    // Another Mac with no state reads it all from the bucket (re-anchor: freshness unverified).
    Mac b(w, "mac-b");
    auto& r = b.open();
    EXPECT_EQ(b.report.anchor, en::Anchor::Reanchored);
    EXPECT_EQ(b.report.freshness, mf::Freshness::Unverified);
    EXPECT_EQ(b.report.recovered, 0u);
    EXPECT_EQ(comparable(everything(r)), comparable(everything(e)));
    EXPECT_EQ(readAll(r, f.uid), bytes);
}

// A store that flips one byte of a content object on its way back (a bucket, or anyone on the path, altering it).
class TamperingStore final : public en::BucketStore {
public:
    TamperingStore(std::shared_ptr<en::BucketStore> inner, const uint64_t at) : inner_(std::move(inner)), at_(at) {}
    std::optional<mf::StoredObject> get(const std::string& k, const std::optional<std::string>& v) override { return inner_->get(k, v); }
    std::optional<std::vector<uint8_t>> getRange(const std::string& k, uint64_t o, uint64_t l) override { return inner_->getRange(k, o, l); }
    std::optional<std::string> headEtag(const std::string& k) override { return inner_->headEtag(k); }
    std::string putIfAbsent(const std::string& k, const std::vector<uint8_t>& b) override { return inner_->putIfAbsent(k, b); }
    std::string putIfMatch(const std::string& k, const std::vector<uint8_t>& b, const std::string& e) override {
        return inner_->putIfMatch(k, b, e);
    }
    mf::PutResult put(const std::string& k, const std::vector<uint8_t>& b) override { return inner_->put(k, b); }
    std::vector<mf::ListedObject> list(const std::string& p) override { return inner_->list(p); }
    std::vector<mf::StoredVersion> versions(const std::string& k) override { return inner_->versions(k); }
    std::vector<mf::StoredVersion> versionsUnder(const std::string& p) override { return inner_->versionsUnder(p); }
    void remove(const std::string& k) override { inner_->remove(k); }
    void removeVersion(const std::string& k, const std::string& v) override { inner_->removeVersion(k, v); }
    [[nodiscard]] mf::WriteCapability mode() const override { return inner_->mode(); }
    std::unique_ptr<en::ContentUpload> putContent(const std::string& k, std::optional<uint64_t> s) override {
        return inner_->putContent(k, s);
    }
    std::optional<en::ContentRange> getContent(const std::string& k, const std::optional<std::string>& v, uint64_t o,
                                               uint64_t l) override {
        auto r = inner_->getContent(k, v, o, l);
        if (r && tamper && at_ >= o && at_ - o < r->bytes.size()) r->bytes[at_ - o] ^= 0x01;
        return r;
    }
    bool tamper{false};

private:
    std::shared_ptr<en::BucketStore> inner_;
    uint64_t at_;
};

TEST_P(EngineOps, OnlyAuthenticatedChunksReachTheSink) {
    World w(GetParam());
    const auto tampering = std::make_shared<TamperingStore>(w.store, vhf1::kHeaderSize + 65536 + 16 + 5);   // chunk 1
    w.store = std::make_shared<test_support::HookedBucketStore>(tampering);
    Mac a(w, "mac-a");
    auto& e = created(a);
    const auto bytes = pattern(3 * 65536 + 10, 9);
    const auto f = writeFile(e, e.rootUid(), "a.bin", bytes);
    std::size_t received = 0;
    const auto sink = [&](const std::span<const uint8_t> b) { received += b.size(); };
    e.read(f.uid, std::nullopt, 0, UINT64_MAX, sink);
    EXPECT_EQ(received, bytes.size());
    received = 0;
    tampering->tamper = true;
    EXPECT_THROW(e.read(f.uid, std::nullopt, 0, UINT64_MAX, sink), vhf1::Error);
    EXPECT_EQ(received, 0u);   // the read's window covers the bad chunk: nothing of it leaves
    e.read(f.uid, std::nullopt, 0, 65536, sink);   // chunk 0 alone authenticates
    EXPECT_EQ(received, 65536u);
}

TEST_P(EngineOps, KeysAreAddedWithTheirEnvelopesBeforeAnythingIsSealedUnderThem) {
    World w(GetParam());
    Mac a(w, "mac-a");
    auto& e = a.open("Finance");
    EXPECT_THROW((void)e.writeBegin(e.rootUid(), "x"), en::Refused);   // key_not_added
    EXPECT_THROW(e.publish(), en::Refused);
    try {
        e.keyAdd(1, keyBytes(1), {});
        FAIL();
    } catch (const en::Refused& r) {
        EXPECT_EQ(r.why(), en::Refusal::RecipientRequired);
    }
    try {
        e.keyAdd(1, keyBytes(2), {w.envelope(1)});
        FAIL();
    } catch (const en::Refused& r) {
        EXPECT_EQ(r.why(), en::Refusal::KeyMismatch);
    }
    try {
        e.keyAdd(1, keyBytes(1), {w.envelope(2)});   // another version's envelope
        FAIL();
    } catch (const en::Refused& r) {
        EXPECT_EQ(r.why(), en::Refusal::BadEnvelope);
    }
    e.keyAdd(1, keyBytes(1), {w.envelope(1)});
    const auto kid = vl::keykit::kev1::kid(w.envelope(1));
    EXPECT_TRUE(w.bucket->current(vl::keykit::kev1::objectKey(kid)).has_value());
    const auto old = writeFile(e, e.rootUid(), "old", pattern(10, 1));
    // Rotation: version 2 sealed only after its envelope is in the bucket.
    w.hold(2);
    w.current = 2;
    EXPECT_THROW((void)e.writeBegin(e.rootUid(), "y"), en::Refused);
    e.keyAdd(2, keyBytes(2), {w.envelope(2)});
    const auto now = writeFile(e, e.rootUid(), "new", pattern(10, 2));
    EXPECT_EQ(now.key_version, 2u);
    EXPECT_EQ(readAll(e, old.uid), pattern(10, 1));
    (void)e.publish();
    const auto h = head(w);
    ASSERT_EQ(h.root.keys.size(), 2u);
    EXPECT_TRUE(h.root.keys[0].retired_at.has_value());
    EXPECT_EQ(h.root.keys[1].envelopes, std::optional<std::vector<std::string>>({vl::keykit::kev1::kid(w.envelope(2))}));
}

TEST_P(EngineOps, TrashRestoreAndPurge) {
    World w(GetParam());
    Mac a(w, "mac-a");
    auto& e = created(a);
    const auto root = e.rootUid();
    const auto d = e.mkdir(root, "D");
    const auto sub = e.mkdir(d.uid, "S");
    const auto f1 = writeFile(e, d.uid, "f1", pattern(100, 1));
    const auto f2 = writeFile(e, sub.uid, "f2", pattern(100, 2));
    (void)e.publish();
    e.trash(d.uid);
    EXPECT_TRUE(e.list(root).empty());
    ASSERT_EQ(e.trash().size(), 2u);
    EXPECT_EQ(e.stat(f2.uid)->trashed->path, std::optional<std::string>("/D/S/f2"));
    EXPECT_FALSE(e.stat(d.uid).has_value());
    const auto back = e.restore(f1.uid);   // its folder is gone: the vault root
    EXPECT_EQ(back.parent, root);
    EXPECT_EQ(readAll(e, f1.uid), pattern(100, 1));
    e.purge(f2.uid);
    EXPECT_FALSE(e.stat(f2.uid).has_value());
    const auto key2 = keys::contentKey(mf::parseUid(f2.uid, "bad_segment", "uid"));
    EXPECT_TRUE(w.bucket->current(key2).has_value());   // not before a root without it settled
    const auto p = e.publish();
    EXPECT_EQ(p.purged, 1u);
    EXPECT_FALSE(w.bucket->current(key2).has_value());
    if (GetParam() == mf::WriteCapability::VersionLog) {
        EXPECT_TRUE(w.bucket->history(key2).empty());   // every version
    }
    EXPECT_EQ(e.status().pending_purges, 0u);
}

TEST_P(EngineOps, ARefreshCostsOneHeadWhileNothingMoved) {
    World w(GetParam());
    Mac a(w, "mac-a");
    auto& e = created(a);
    (void)writeFile(e, e.rootUid(), "x", pattern(5, 5));
    (void)e.publish();
    std::vector<std::string> ops;
    w.store->before = [&](const std::string_view op, const std::string&) { ops.emplace_back(op); };
    const auto r = e.refresh();
    EXPECT_FALSE(r.moved);
    EXPECT_EQ(ops, std::vector<std::string>({"head"}));
    w.store->before = {};
}

TEST_P(EngineOps, ChangesSinceAnAnchor) {
    World w(GetParam());
    Mac a(w, "mac-a");
    auto& e = created(a);
    const auto start = e.changes(0, 0);
    EXPECT_TRUE(start.expired);   // generation 0 is nobody's
    const auto anchor = e.changes(start.generation, start.revision);
    EXPECT_FALSE(anchor.expired);
    EXPECT_TRUE(anchor.changed.empty());
    const auto d = e.mkdir(e.rootUid(), "D");
    const auto f = writeFile(e, d.uid, "f", pattern(1, 1));
    e.purge(d.uid);
    const auto c = e.changes(start.generation, start.revision);
    EXPECT_FALSE(c.expired);
    EXPECT_TRUE(c.changed.empty());
    EXPECT_EQ(c.removed.size(), 2u);
    EXPECT_TRUE(std::ranges::find(c.removed, f.uid) != c.removed.end());
    EXPECT_TRUE(e.changes(start.generation + 1, start.revision).expired);
}

INSTANTIATE_TEST_SUITE_P(, EngineOps, ::testing::Values(mf::WriteCapability::VersionLog, mf::WriteCapability::Conditional),
                         modeName);

// ---- EngineDurability ------------------------------------------------------------------------------------------------

class EngineDurability : public Modes {};

TEST_P(EngineDurability, AnOperationThatReturnedSurvivesACrashAndOneThatThrewNeverHappened) {
    World w(GetParam());
    Mac a(w, "mac-a");
    auto& e = created(a);
    const auto d = e.mkdir(e.rootUid(), "D");
    const auto f = writeFile(e, d.uid, "f", pattern(1000, 4));
    (void)e.rename(f.uid, "g");
    const auto appends = a.blob->appends();
    EXPECT_GE(appends, 3u);   // one durable record per operation
    auto& r = a.restart();
    EXPECT_EQ(r.stat(f.uid)->name, "g");
    EXPECT_EQ(readAll(r, f.uid), pattern(1000, 4));
    // A journal write that fails: the operation throws and leaves nothing, in memory or on disk.
    a.blob->failNext();
    EXPECT_THROW((void)r.mkdir(d.uid, "lost"), en::StateFailed);
    EXPECT_FALSE(named(r, d.uid, "lost"));
    // A crash during an append (a torn record): the operation never returned and the state still opens.
    a.blob->tearNextAppend(7);
    EXPECT_THROW((void)r.mkdir(d.uid, "torn"), en::StateFailed);
    auto& t = a.restart();
    EXPECT_TRUE(a.report.state.torn_tail);
    EXPECT_FALSE(named(t, d.uid, "torn"));
    EXPECT_EQ(t.stat(f.uid)->name, "g");
    (void)t.mkdir(d.uid, "after");   // appends land after valid bytes again
    auto& u = a.restart();
    EXPECT_FALSE(a.report.state.torn_tail);
    EXPECT_TRUE(named(u, d.uid, "after"));
}

// Design decision 8: a lost Mac costs at most the names of the changes not yet published: never file bytes (blind
// rebuild) or keys (envelopes go first).
TEST_P(EngineDurability, ALostMacLosesAtMostTheNamesOfUnpublishedChanges) {
    World w(GetParam());
    Mac a(w, "mac-a");
    auto& e = created(a);
    const auto root = e.rootUid();
    const auto docs = e.mkdir(root, "Docs");
    const auto kept = writeFile(e, docs.uid, "kept.txt", pattern(5000, 1));
    (void)e.publish();
    // Unpublished: a folder, a rename, new content of a published file, a new file, and a key version.
    (void)e.mkdir(root, "Unpublished");
    (void)e.rename(kept.uid, "renamed.txt");
    w.hold(2);
    w.current = 2;
    e.keyAdd(2, keyBytes(2), {w.envelope(2)});
    const auto fresh = writeFile(e, docs.uid, "fresh.bin", pattern(90'000, 2));
    (void)writeFile(e, docs.uid, "kept.txt", pattern(6000, 3), kept.uid);

    // The Mac is lost: a new installation (or this one, its state gone) opens the vault from the bucket alone.
    Mac b(w, "mac-a");
    auto& r = b.open();
    EXPECT_EQ(b.report.anchor, en::Anchor::Reanchored);
    EXPECT_EQ(b.report.freshness, mf::Freshness::Unverified);
    // What was published is there, under its published names.
    const auto docs2 = named(r, root, "Docs");
    ASSERT_TRUE(docs2);
    EXPECT_TRUE(named(r, docs2->uid, "kept.txt"));
    EXPECT_FALSE(named(r, root, "Unpublished"));   // lost: a name only
    // The published content of kept.txt reads; the unpublished file's bytes are under /Recovered, without a name.
    if (GetParam() == mf::WriteCapability::VersionLog) {
        EXPECT_EQ(readAll(r, kept.uid), pattern(5000, 1));
    }
    const auto recovered = named(r, root, std::string(mf::kRecoveredName));
    ASSERT_TRUE(recovered);
    const auto again = r.stat(fresh.uid);
    ASSERT_TRUE(again);
    EXPECT_EQ(again->parent, recovered->uid);
    EXPECT_EQ(again->name, fresh.uid);
    EXPECT_EQ(readAll(r, fresh.uid), pattern(90'000, 2));
    EXPECT_GE(b.report.recovered, 1u);
    // Every key version that sealed anything has its envelope in the bucket.
    for (const uint32_t v : {1u, 2u})
        EXPECT_TRUE(w.bucket->current(vl::keykit::kev1::objectKey(vl::keykit::kev1::kid(w.envelope(v)))));
    // The key version that was never published is added again before anything is sealed under it (its envelope is
    // already in the bucket), then the recovered file is published by the new installation.
    EXPECT_TRUE(r.status().unpublished);
    EXPECT_THROW((void)r.publish(), en::Refused);
    r.keyAdd(2, keyBytes(2), {w.envelope(2)});
    EXPECT_TRUE(r.publish().published);
}

TEST_P(EngineDurability, ADamagedStateReanchorsFromTheBucket) {
    World w(GetParam());
    Mac a(w, "mac-a");
    auto& e = created(a);
    const auto f = writeFile(e, e.rootUid(), "f", pattern(10, 1));
    (void)e.publish();
    a.engine.reset();
    a.blob->corrupt(30);   // inside the snapshot record
    auto& r = a.restart();
    EXPECT_EQ(a.report.state.condition, en::StateCondition::Damaged);
    EXPECT_EQ(a.report.anchor, en::Anchor::Reanchored);
    EXPECT_EQ(readAll(r, f.uid), pattern(10, 1));
    EXPECT_FALSE(r.status().unpublished);
    // A state is never opened for another vault, nor over its own blob.
    a.engine.reset();
    mf::Uid other{};
    other.fill(0x01);
    en::Options o;
    o.node_id = "mac-a";
    EXPECT_THROW((void)en::Session::open(other, w.store, w.keys(), a.blob, o), en::StateOfAnotherVault);
}

INSTANTIATE_TEST_SUITE_P(, EngineDurability,
                         ::testing::Values(mf::WriteCapability::VersionLog, mf::WriteCapability::Conditional), modeName);

// ---- EngineCrash -----------------------------------------------------------------------------------------------------

class EngineCrash : public Modes {};

TEST_P(EngineCrash, BetweenARootsPutAndItsRecordTheRootIsAdoptedAndNothingIsLost) {
    World w(GetParam());
    Mac a(w, "mac-a");
    auto& e = created(a);
    (void)e.publish();
    const auto f = writeFile(e, e.rootUid(), "f", pattern(10, 1));
    a.afterRootPut = [] { throw Crash{}; };
    EXPECT_THROW(e.publish(), Crash);
    a.afterRootPut = {};
    auto& r = a.restart();
    const auto before = everything(r);
    const auto refreshed = r.refresh();
    EXPECT_TRUE(refreshed.adopted);   // our own root: recorded, never reconciled
    EXPECT_FALSE(refreshed.applied);
    EXPECT_EQ(everything(r), before);
    (void)r.publish();
    EXPECT_EQ(comparable(head(w).content.entries), comparable(everything(r)));
    EXPECT_TRUE(r.stat(f.uid));
}

TEST_P(EngineCrash, AnotherWriterBuildingOnOurUnrecordedRootIsTheBaseOfTheApply) {
    World w(GetParam());
    Mac a(w, "mac-a");
    auto& e = created(a);
    const auto f = writeFile(e, e.rootUid(), "f", pattern(10, 1));
    (void)e.publish();
    Mac b(w, "mac-b");
    b.open().join();
    (void)b->publish();
    (void)e.refresh();   // A takes in B's root (both writers now)
    (void)e.rename(f.uid, "first");
    a.afterRootPut = [] { throw Crash{}; };
    EXPECT_THROW(e.publish(), Crash);   // P: PUT, never recorded
    a.afterRootPut = {};
    // B applies P and publishes Q on it.
    (void)b->refresh();
    EXPECT_EQ(b->stat(f.uid)->name, "first");
    (void)b->mkdir(b->rootUid(), "from-b");
    (void)b->publish();
    // A restarts, renames again (after P), then refreshes: P is its base, so the second rename is ours, not undone.
    auto& r = a.restart();
    (void)r.rename(f.uid, "second");
    const auto refreshed = r.refresh();
    EXPECT_TRUE(refreshed.applied);
    EXPECT_EQ(r.stat(f.uid)->name, "second");
    EXPECT_TRUE(named(r, r.rootUid(), "from-b"));
    (void)r.publish();
    (void)b->refresh();
    EXPECT_EQ(b->stat(f.uid)->name, "second");
    EXPECT_EQ(comparable(everything(*b.engine)), comparable(everything(r)));
}

// version_log: a root PUT whose outcome is unknown and that lands after the publish gave up.
TEST(EngineCrashVersionLog, APutThatLandsLateIsAdoptedOrRepairedAndNothingIsLost) {
    for (const bool landsBeforeTheRetry : {true, false}) {
        SCOPED_TRACE(landsBeforeTheRetry);
        World w(mf::WriteCapability::VersionLog);
        Mac a(w, "mac-a");
        auto& e = created(a);
        (void)e.publish();
        const auto f = writeFile(e, e.rootUid(), "f", pattern(10, 1));
        bool lost = false;
        w.store->before = [&](const std::string_view op, const std::string& key) {
            if (op == "put" && key == mf::kRootKey && !std::exchange(lost, true))
                throw mf::PutOutcomeUnknown("the PUT's reply was lost (test)");   // and it has not landed yet
        };
        EXPECT_ANY_THROW(e.publish());
        w.store->before = {};
        // The root the engine noted before its PUT is in its state: replay it as the PUT landing late.
        const auto state = std::make_shared<en::StateFile>(a.blob->crash(), w.vault, [] { return std::time_t{0}; });
        (void)state->load(mf::kBaselineWriterRevision);
        const auto chain = state->state();
        ASSERT_GE(chain.publishing_roots.size(), 2u);
        const auto late = state->pendingBase(chain.publishing_roots.back());
        ASSERT_TRUE(late);
        if (landsBeforeTheRetry) w.bucket->seed(std::string(mf::kRootKey), late->root);
        (void)e.mkdir(e.rootUid(), "later");
        const auto p = e.publish();
        if (!landsBeforeTheRetry) w.bucket->seed(std::string(mf::kRootKey), late->root);   // after: a stray
        (void)e.refresh();
        (void)e.publish();
        EXPECT_TRUE(p.published || p.rounds > 0);
        const auto h = head(w);
        EXPECT_EQ(comparable(h.content.entries), comparable(everything(e)));
        EXPECT_TRUE(e.stat(f.uid));
        EXPECT_TRUE(named(e, e.rootUid(), "later"));
        EXPECT_TRUE(h.strays.empty());
    }
}

// A crash before each request of a publish (and before each of its state writes), then a restart: nothing is lost and
// the bucket converges on the working content.
TEST_P(EngineCrash, ACrashBeforeEveryRequestOfAPublishLosesNothing) {
    for (std::size_t at = 0;; ++at) {
        SCOPED_TRACE(at);
        World w(GetParam());
        Mac a(w, "mac-a");
        auto& e = created(a);
        (void)e.publish();
        const auto d = e.mkdir(e.rootUid(), "D");
        const auto f = writeFile(e, d.uid, "f", pattern(70'000, 8));
        std::size_t seen = 0;
        bool crashed = false;
        w.store->before = [&](const std::string_view, const std::string&) {
            if (seen++ == at) {
                crashed = true;
                throw Crash{};
            }
        };
        try {
            (void)e.publish();
        } catch (const Crash&) {
        }
        w.store->before = {};
        auto& r = a.restart();
        (void)r.refresh();
        (void)r.publish();
        EXPECT_EQ(r.stat(f.uid)->parent, d.uid);
        EXPECT_EQ(readAll(r, f.uid), pattern(70'000, 8));
        EXPECT_EQ(comparable(head(w).content.entries), comparable(everything(r)));
        EXPECT_FALSE(r.status().unpublished);
        if (!crashed) break;
    }
}

INSTANTIATE_TEST_SUITE_P(, EngineCrash, ::testing::Values(mf::WriteCapability::VersionLog, mf::WriteCapability::Conditional),
                         modeName);

// ---- EngineTwoMacs ---------------------------------------------------------------------------------------------------

class EngineTwoMacs : public Modes {
protected:
    // Two Macs writing one vault: B joined from the bucket; both at the same root.
    struct Pair {
        World w;
        Mac a, b;
        explicit Pair(const mf::WriteCapability m) : w(m), a(w, "mac-a"), b(w, "mac-b") {
            (void)created(a);
            (void)a->publish();
            b.open().join();
            (void)b->publish();
            (void)a->refresh();
        }
    };
};

TEST_P(EngineTwoMacs, AnEditBeatsADeleteInBothDirections) {
    Pair p(GetParam());
    const auto root = p.a->rootUid();
    const auto f = writeFile(*p.a.engine, root, "f", pattern(10, 1));
    const auto g = writeFile(*p.a.engine, root, "g", pattern(10, 2));
    (void)p.a->publish();
    (void)p.b->refresh();
    // A trashes f and edits g; B edits f and trashes g.
    p.a->trash(f.uid);
    (void)writeFile(*p.a.engine, root, "g", pattern(20, 3), g.uid);
    (void)writeFile(*p.b.engine, root, "f", pattern(20, 4), f.uid);
    p.b->trash(g.uid);
    (void)p.b->publish();
    const auto r = p.a->refresh();
    EXPECT_TRUE(r.applied);
    EXPECT_FALSE(p.a->stat(f.uid)->trashed);   // B's edit beats A's trash
    EXPECT_FALSE(p.a->stat(g.uid)->trashed);   // A's edit beats B's trash
    EXPECT_EQ(readAll(*p.a.engine, f.uid), pattern(20, 4));
    EXPECT_EQ(readAll(*p.a.engine, g.uid), pattern(20, 3));
    (void)p.a->publish();
    (void)p.b->refresh();
    EXPECT_EQ(comparable(everything(*p.a.engine)), comparable(everything(*p.b.engine)));
}

TEST(EngineTwoMacsVersionLog, ATwoSidedContentChangeKeepsBothGenerations) {
    World w(mf::WriteCapability::VersionLog);
    Mac a(w, "mac-a"), b(w, "mac-b");
    (void)created(a);
    const auto f = writeFile(*a.engine, a->rootUid(), "f", pattern(10, 1));
    (void)a->publish();
    b.open().join();
    (void)b->publish();
    (void)a->refresh();
    (void)writeFile(*a.engine, a->rootUid(), "f", pattern(30, 5), f.uid);
    const auto theirs = writeFile(*b.engine, b->rootUid(), "f", pattern(40, 6), f.uid);
    (void)b->publish();
    const auto r = a->refresh();
    ASSERT_TRUE(std::ranges::any_of(r.conflicts, [](const mf::Conflict& c) {
        return c.kind == mf::ConflictKind::ContentEditEdit;
    }));
    EXPECT_EQ(readAll(*a.engine, f.uid), pattern(30, 5));   // ours stays current
    EXPECT_EQ(readAll(*a.engine, f.uid, theirs.object->version_id), pattern(40, 6));   // theirs is a version
    (void)a->publish();
    (void)b->refresh();
    EXPECT_EQ(readAll(*b.engine, f.uid), pattern(30, 5));
    EXPECT_EQ(readAll(*b.engine, f.uid, theirs.object->version_id), pattern(40, 6));
    EXPECT_EQ(comparable(everything(*a.engine)), comparable(everything(*b.engine)));
}

TEST_P(EngineTwoMacs, TheHeadsPlacementWinsAndAPublishThatLosesARoundAppliesFirst) {
    Pair p(GetParam());
    const auto root = p.a->rootUid();
    const auto f = writeFile(*p.a.engine, root, "f", pattern(10, 1));
    (void)p.a->publish();
    (void)p.b->refresh();
    (void)p.a->rename(f.uid, "by-a");
    (void)p.a->mkdir(root, "only-a");
    (void)p.b->rename(f.uid, "by-b");
    (void)p.b->publish();
    const auto pub = p.a->publish();   // the head moved: apply B's root, then publish
    EXPECT_EQ(pub.rounds, 1u);
    EXPECT_TRUE(pub.published);
    EXPECT_EQ(p.a->stat(f.uid)->name, "by-b");   // the head's placement
    EXPECT_TRUE(named(*p.a.engine, root, "only-a"));
    (void)p.b->refresh();
    EXPECT_EQ(comparable(everything(*p.a.engine)), comparable(everything(*p.b.engine)));
    EXPECT_EQ(head(p.w).root.writers->size(), 2u);
}

INSTANTIATE_TEST_SUITE_P(, EngineTwoMacs, ::testing::Values(mf::WriteCapability::VersionLog, mf::WriteCapability::Conditional),
                         modeName);

// ---- EngineFloor -----------------------------------------------------------------------------------------------------

TEST(EngineFloor, AHeadAboveTheEnginesRevisionIsNeitherAppliedNorPublishedOver) {
    World w(mf::WriteCapability::VersionLog);
    Mac a(w, "mac-a");
    auto& e = created(a);
    (void)e.publish();
    // A newer writer (revision 2) publishes a root with floor 2 on top.
    mf::PublisherCache cache;
    mf::PublishOptions o;
    o.now = "2026-11-15T12:00:00Z";
    o.self_node = "mac-new";
    o.writer_revision = 2;
    o.writer_floor = 2;
    o.sleep = [](std::chrono::milliseconds) {};
    o.writers_change = mf::WritersChange{mf::WritersChange::Kind::Add, "mac-new"};
    auto newer = head(w);
    auto content = newer.content;
    content.producer = {"mac-new", std::nullopt, "newer"};
    (void)mf::publish(*w.store, w.vault, w.keys().lookup, {1, w.keyring.at(1)}, content, newer.known(), cache, o);
    (void)e.mkdir(e.rootUid(), "mine");
    EXPECT_THROW((void)e.refresh(), mf::WriterFloorRefused);
    EXPECT_TRUE(e.status().update_needed);
    EXPECT_TRUE(named(e, e.rootUid(), "mine"));   // the local change stays, unpublished
    EXPECT_ANY_THROW((void)e.publish());
    EXPECT_EQ(mf::writerFloorOf(head(w).root), 2u);
    // A state written by a newer engine is never read into this one.
    const auto s = std::make_shared<en::StateFile>(a.blob->crash(), w.vault, [] { return std::time_t{0}; });
    EXPECT_THROW((void)s->load(0), en::StateTooNew);
}

}
