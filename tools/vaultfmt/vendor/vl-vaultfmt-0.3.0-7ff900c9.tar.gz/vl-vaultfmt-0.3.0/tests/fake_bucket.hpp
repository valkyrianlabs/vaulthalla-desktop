// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// Test-only: the part of vaulthalla-server's HTTP-level fake bucket (core/tests/helpers/versioned_bucket.hpp) that the
// manifest protocol suites (test_manifest_protocol.cpp) use, rebuilt over the library's own doubles
// (vl/vaultfmt/testing/memory_store.hpp). FakeBucket is the provider's state: a MemoryBucket plus what it doesn't
// have (request counters, injected failures, lost responses, refused DELETEs, in-place corruption, a lifecycle rule,
// paged version listings, the set of keys). FakeStore is one client of it with its bucket mode, the manifest
// ObjectStore the protocol runs on: it meters every request and applies those knobs around a MemoryStore.
//
// Counters count store requests the way the server's S3 adapter turns them into HTTP requests: one per GET, ranged
// GET, HEAD, PUT and DELETE; a listing of objects one per 1000 keys, a version listing one per versionPageSize
// entries (at least one). body_gets counts the GETs that delivered bytes, bytes_served their bytes. Seeding and
// inspection (seed, seedDeleteMarker, purgeVersion, tamper, history, current, version, keys) are never metered.
// ETags are always the quoted MD5 of the body (the server's fake answers that with md5Etags; without it, FNV hashes).

#include "vl/vaultfmt/manifest/Store.hpp"
#include "vl/vaultfmt/testing/memory_store.hpp"

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <ctime>
#include <deque>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace vl::vaultfmt::test_fake_bucket {

enum class Versioning { Unversioned, Enabled };

class FakeBucket {
public:
    using Version = test_support::MemoryBucket::Version;
    using Order = test_support::MemoryBucket::Order;

    enum class Op { Any, List, Head, Get, Put, Delete };
    enum class Failure { Transport, Http503 };
    // Supported evaluates a condition (412 when it doesn't hold), Reject501 refuses to evaluate it and writes nothing
    // (Backblaze B2), Ignore writes as if it weren't there.
    enum class ConditionalPuts { Supported, Reject501, Ignore };

    struct Counters {
        uint64_t list{}, head{}, get{}, put{}, del{};
        uint64_t body_gets{};
        uint64_t bytes_served{};
    };

    explicit FakeBucket(const Versioning mode = Versioning::Unversioned)
        : versioned_(mode == Versioning::Enabled),
          memory_(std::make_shared<test_support::MemoryBucket>(versioned_)) {
        memory_->setNow(1'760'000'000);
    }

    // ---- knobs --------------------------------------------------------------------------------------------------------

    std::atomic<bool> refuseDeletes{false};      // every DELETE answers 403
    std::atomic<unsigned> loseResponses{0};      // the next n PUTs are applied, then fail as if the answer was lost
    std::atomic<unsigned> versionPageSize{1000};  // a version listing pages at most this many entries

    void conditionalPuts(const ConditionalPuts how) {
        using M = test_support::MemoryBucket::ConditionalPuts;
        memory_->conditionalPuts(how == ConditionalPuts::Supported ? M::Supported
                                 : how == ConditionalPuts::Reject501 ? M::Reject
                                                                     : M::Ignore);
    }

    // The next `times` requests of `op` (Op::Any: any kind) fail after being metered, before any effect.
    void failNext(const Op op, const Failure failure, const unsigned times = 1) {
        std::scoped_lock lock(mutex_);
        for (unsigned i = 0; i < times; ++i) failures_.push_back({op, failure});
    }

    // spec 06 §4's A3 and A4, broken on purpose (MemoryBucket's own knobs).
    void listingLag(const std::time_t seconds) { memory_->listingLag(seconds); }
    void orderBy(const Order order) { memory_->orderBy(order); }
    void holdPut(const std::string& key) { memory_->holdPut(key); }

    // A6 broken on purpose: a lifecycle rule; advance() then purges versions of keys under `prefix` that have been
    // noncurrent (superseded by a newer version or a marker) for more than `days`.
    void expireNoncurrent(std::string prefix, const unsigned days) {
        std::scoped_lock lock(mutex_);
        expirePrefix_ = std::move(prefix);
        expireDays_ = days;
    }

    // Flips one byte of a stored version (a provider-side corruption): every read of that version sees it.
    void tamper(const std::string& key, const std::string& versionId, const std::size_t at = 0) {
        const auto v = memoryVersion(key, versionId);
        if (!v || at >= v->body.size()) throw std::invalid_argument("nothing to tamper with: " + key);
        std::scoped_lock lock(mutex_);
        tampered_[{key, versionId}] = at;
    }

    // ---- the clock ----------------------------------------------------------------------------------------------------

    void setNow(const std::time_t now) { memory_->setNow(now); }
    [[nodiscard]] std::time_t now() const { return memory_->now(); }

    void advance(const std::time_t seconds) {
        memory_->advance(seconds);
        std::optional<std::string> prefix;
        unsigned days = 0;
        {
            std::scoped_lock lock(mutex_);
            prefix = expirePrefix_;
            days = expireDays_;
        }
        if (!prefix) return;
        const auto maxAge = static_cast<std::time_t>(days) * 24 * 60 * 60;
        const auto t = now();
        for (const auto& key : keys()) {
            if (!key.starts_with(*prefix)) continue;
            const auto newestFirst = memory_->history(key);
            // A version became noncurrent when the next (newer) one was written.
            for (std::size_t i = 1; i < newestFirst.size(); ++i)
                if (t - newestFirst[i - 1].last_modified > maxAge)
                    memory_->removeVersion(key, newestFirst[i].version_id);
        }
    }

    // ---- seeding and inspection (never metered) -----------------------------------------------------------------------

    // Writes a version as a PUT would. Returns its version id ("null" on an unversioned bucket).
    std::string seed(const std::string& key, std::vector<uint8_t> body) {
        touch(key);
        return memory_->seed(key, std::move(body));
    }
    std::string seed(const std::string& key, const std::string& body) {
        return seed(key, std::vector<uint8_t>(body.begin(), body.end()));
    }

    // DeleteObject semantics. Returns the delete marker's id (empty when unversioned: the key is gone).
    std::string seedDeleteMarker(const std::string& key) {
        touch(key);
        memory_->remove(key);
        if (!versioned_) return {};
        return memory_->history(key).front().version_id;
    }

    // Permanently removes one version. false when there was none.
    bool purgeVersion(const std::string& key, const std::string& versionId) {
        if (!memoryVersion(key, versionId)) return false;
        memory_->removeVersion(key, versionId);
        return true;
    }

    // Newest first; empty when the key has no versions.
    [[nodiscard]] std::vector<Version> history(const std::string& key) const {
        auto out = memory_->history(key);
        for (auto& v : out) patch(key, v);
        return out;
    }

    // The newest version unless it is a delete marker.
    [[nodiscard]] std::optional<Version> current(const std::string& key) const {
        auto v = memory_->current(key);
        if (v) patch(key, *v);
        return v;
    }

    [[nodiscard]] std::optional<Version> version(const std::string& key, const std::string& versionId) const {
        auto v = memoryVersion(key, versionId);
        if (v) patch(key, *v);
        return v;
    }

    // Every key holding a version or a delete marker, ascending.
    [[nodiscard]] std::vector<std::string> keys() const {
        std::set<std::string> seen;
        {
            std::scoped_lock lock(mutex_);
            seen = seen_;
        }
        std::vector<std::string> out;
        for (const auto& key : seen)
            if (!memory_->history(key).empty()) out.push_back(key);
        return out;
    }

    [[nodiscard]] Counters counters() const {
        std::scoped_lock lock(mutex_);
        return counters_;
    }
    void resetCounters() {
        std::scoped_lock lock(mutex_);
        counters_ = {};
    }

private:
    friend class FakeStore;

    struct Injected {
        Op op;
        Failure failure;
    };

    [[nodiscard]] std::optional<Version> memoryVersion(const std::string& key, const std::string& versionId) const {
        for (auto& v : memory_->history(key))
            if (v.version_id == versionId) return v;
        return std::nullopt;
    }

    void patch(const std::string& key, Version& v) const {
        std::scoped_lock lock(mutex_);
        if (const auto it = tampered_.find({key, v.version_id}); it != tampered_.end() && it->second < v.body.size())
            v.body[it->second] ^= 0xff;
    }

    void patchCurrent(const std::string& key, std::vector<uint8_t>& bytes, const std::optional<std::string>& versionId) const {
        {
            std::scoped_lock lock(mutex_);
            if (tampered_.empty()) return;
        }
        std::string id;
        if (versionId) id = *versionId;
        else if (const auto v = memory_->current(key)) id = v->version_id;
        std::scoped_lock lock(mutex_);
        if (const auto it = tampered_.find({key, id}); it != tampered_.end() && it->second < bytes.size())
            bytes[it->second] ^= 0xff;
    }

    void touch(const std::string& key) {
        std::scoped_lock lock(mutex_);
        seen_.insert(key);
    }

    // Meters one request of `op` (`n` for a paged listing), then throws an injected failure if one is due.
    void meter(const Op op, const uint64_t n = 1) {
        std::scoped_lock lock(mutex_);
        switch (op) {
        case Op::List: counters_.list += n; break;
        case Op::Head: counters_.head += n; break;
        case Op::Get: counters_.get += n; break;
        case Op::Put: counters_.put += n; break;
        case Op::Delete: counters_.del += n; break;
        case Op::Any: break;
        }
        for (auto it = failures_.begin(); it != failures_.end(); ++it) {
            if (it->op != Op::Any && it->op != op) continue;
            const auto failure = it->failure;
            failures_.erase(it);
            throw std::runtime_error(failure == Failure::Transport ? "request failed: transport (test)"
                                                                   : "request failed (HTTP 503 SlowDown, test)");
        }
    }

    void served(const std::size_t bytes) {
        std::scoped_lock lock(mutex_);
        ++counters_.body_gets;
        counters_.bytes_served += bytes;
    }

    // true once when a lost response is due.
    bool loseResponse() {
        auto n = loseResponses.load();
        while (n > 0 && !loseResponses.compare_exchange_weak(n, n - 1)) {}
        return n > 0;
    }

    bool versioned_;
    std::shared_ptr<test_support::MemoryBucket> memory_;
    mutable std::mutex mutex_;
    Counters counters_;
    std::deque<Injected> failures_;
    std::map<std::pair<std::string, std::string>, std::size_t> tampered_;
    std::set<std::string> seen_;
    std::optional<std::string> expirePrefix_;
    unsigned expireDays_{0};
};

// The manifest ObjectStore over a FakeBucket: a MemoryStore with metering and the bucket's fault knobs. Failures
// surface as the server's S3 adapter surfaces them: a conditional PUT's PreconditionFailed / ConditionsUnsupported
// as is, any other failure of a plain PUT (an injected 5xx, a lost response) as PutOutcomeUnknown, everything else
// as std::runtime_error.
class FakeStore final : public manifest::ObjectStore {
public:
    explicit FakeStore(std::shared_ptr<FakeBucket> bucket,
                       const manifest::WriteCapability mode = manifest::WriteCapability::Unknown)
        : bucket_(std::move(bucket)), inner_(bucket_ ? bucket_->memory_ : nullptr, mode), mode_(mode) {}

    std::optional<manifest::StoredObject> get(const std::string& key,
                                              const std::optional<std::string>& versionId) override {
        bucket_->meter(FakeBucket::Op::Get);
        auto o = inner_.get(key, versionId);
        if (!o) return std::nullopt;
        bucket_->patchCurrent(key, o->bytes, versionId);
        bucket_->served(o->bytes.size());
        return o;
    }
    std::optional<std::vector<uint8_t>> getRange(const std::string& key, const uint64_t offset,
                                                 const uint64_t length) override {
        if (length == 0) return std::vector<uint8_t>{};
        bucket_->meter(FakeBucket::Op::Get);
        auto bytes = inner_.getRange(key, offset, length);
        if (bytes) bucket_->served(bytes->size());
        return bytes;
    }
    std::optional<std::string> headEtag(const std::string& key) override {
        bucket_->meter(FakeBucket::Op::Head);
        return inner_.headEtag(key);
    }
    std::string putIfAbsent(const std::string& key, const std::vector<uint8_t>& bytes) override {
        bucket_->meter(FakeBucket::Op::Put);
        bucket_->touch(key);
        auto etag = inner_.putIfAbsent(key, bytes);
        if (bucket_->loseResponse()) throw std::runtime_error("connection reset after the PUT was applied (test)");
        return etag;
    }
    std::string putIfMatch(const std::string& key, const std::vector<uint8_t>& bytes, const std::string& etag) override {
        bucket_->meter(FakeBucket::Op::Put);
        bucket_->touch(key);
        auto out = inner_.putIfMatch(key, bytes, etag);
        if (bucket_->loseResponse()) throw std::runtime_error("connection reset after the PUT was applied (test)");
        return out;
    }
    manifest::PutResult put(const std::string& key, const std::vector<uint8_t>& bytes) override {
        try {
            bucket_->meter(FakeBucket::Op::Put);
        } catch (const std::runtime_error& e) {
            throw manifest::PutOutcomeUnknown(e.what());
        }
        bucket_->touch(key);
        auto out = inner_.put(key, bytes);
        if (bucket_->loseResponse())
            throw manifest::PutOutcomeUnknown("connection reset after the PUT was applied (test)");
        return out;
    }
    std::vector<manifest::ListedObject> list(const std::string& prefix) override {
        auto out = inner_.list(prefix);
        bucket_->meter(FakeBucket::Op::List, std::max<uint64_t>(1, (out.size() + 999) / 1000));
        return out;
    }
    std::vector<manifest::StoredVersion> versions(const std::string& key) override {
        return versionsSince(key, std::nullopt);
    }
    // Pages of versionPageSize, newest first, the last page read the one holding `stopAt`.
    std::vector<manifest::StoredVersion> versionsSince(const std::string& key,
                                                       const std::optional<std::string>& stopAt) override {
        const auto all = inner_.versions(key);
        const std::size_t page = std::max(1u, bucket_->versionPageSize.load());
        std::vector<manifest::StoredVersion> out;
        std::size_t i = 0;
        do {
            bucket_->meter(FakeBucket::Op::List);
            for (const auto end = std::min(all.size(), i + page); i < end; ++i) {
                out.push_back(all[i]);
                if (stopAt && all[i].version_id == *stopAt) return out;
            }
        } while (i < all.size());
        return out;
    }
    std::vector<manifest::StoredVersion> versionsUnder(const std::string& prefix) override {
        auto out = inner_.versionsUnder(prefix);
        const uint64_t page = std::max(1u, bucket_->versionPageSize.load());
        bucket_->meter(FakeBucket::Op::List, std::max<uint64_t>(1, (out.size() + page - 1) / page));
        return out;
    }
    void remove(const std::string& key) override {
        bucket_->meter(FakeBucket::Op::Delete);
        if (bucket_->refuseDeletes.load()) throw std::runtime_error("DELETE refused (HTTP 403 AccessDenied, test)");
        inner_.remove(key);
    }
    void removeVersion(const std::string& key, const std::string& versionId) override {
        bucket_->meter(FakeBucket::Op::Delete);
        if (bucket_->refuseDeletes.load() && bucket_->memoryVersion(key, versionId))
            throw std::runtime_error("DELETE refused (HTTP 403 AccessDenied, test)");
        inner_.removeVersion(key, versionId);   // a version that is gone is not an error
    }
    [[nodiscard]] manifest::WriteCapability mode() const override { return mode_; }

private:
    std::shared_ptr<FakeBucket> bucket_;
    test_support::MemoryStore inner_;
    manifest::WriteCapability mode_;
};

}
