// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include "vl/keykit/secret.hpp"
#include "vl/keykit/uid.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

// The sealed storage credential (vaulthalla-cloud docs/design/managed-storage.md, "Credentials"; vaulthalla-server
// design/cloud/managed-remotes.md step 4): a managed bucket's application key secret, sealed by the cloud in the
// request that creates it to the one-time X25519 key the server sent, so it is never stored usable at the cloud and
// passes nginx and the proxy hop sealed. The JSON field `sealed_secret` is base64url (base64url.hpp) of these bytes.
// Vectors: vectors/vhc.json `storage_credential`.
//
//   offset  len  field
//    0       8   magic 89 56 48 43 0D 0A 1A 0A ("\x89VHC\r\n\x1a\n")
//    8       2   version 1
//   10       2   suite 1 (X25519 + HKDF-SHA-256 + AES-256-GCM; the only one)
//   12      32   epk, fresh per credential
//   44   n + 16  AES-256-GCM(K, nonce 0^12, secret (n = 1-1024 bytes), AAD = bytes[0 .. 44) ‖ context)
//
//   K       = HKDF-Expand(HKDF-Extract(salt = epk ‖ server public key, IKM = Z),
//                         "vhc-storage-credential-v1" ‖ bytes[0 .. 44), 32)
//   context = "vhc-storage-credential-v1\n" ‖ installation_id ‖ "\n" ‖ base32(vault_uid) ‖ "\n" ‖ key_id
//
// installation_id is the installation's 26-symbol id (the canonical base32 of 16 bytes, uid.hpp); key_id the
// provider's application key id, 1-128 bytes of printable ASCII (0x21-0x7E). A credential opened under another
// installation, vault or key id fails authentication. Reader checks, in order: bad_magic, unsupported_version,
// unsupported_suite, bad_length, bad_ephemeral, auth_failed.
namespace vl::keykit::credential {

inline constexpr std::array<uint8_t, 8> kMagic{0x89, 0x56, 0x48, 0x43, 0x0D, 0x0A, 0x1A, 0x0A};
inline constexpr uint16_t kVersion = 1;
inline constexpr std::size_t kPrefixSize = 44;
inline constexpr std::size_t kMaxSecretSize = 1024;
inline constexpr std::size_t kMaxKeyIdSize = 128;

enum class ErrorCode : uint8_t {
    BadMagic,
    UnsupportedVersion,
    UnsupportedSuite,
    BadLength,
    BadEphemeral,
    AuthFailed,
};

[[nodiscard]] std::string_view errorCodeName(ErrorCode code);

class Error : public std::runtime_error {
public:
    explicit Error(ErrorCode code);
    [[nodiscard]] ErrorCode code() const noexcept { return code_; }

private:
    ErrorCode code_;
};

// What the credential is bound to. Both sides build it from what they know: the server from its own installation id,
// the vault it asked for and the key_id in the response; the cloud from the request's VHC1 identity.
struct Context {
    std::string installation_id{};
    Uid vault_uid{};
    std::string key_id{};
};

// Throws std::invalid_argument for a context outside the ranges above.
void validate(const Context& context);

// The cloud's side: seals `secret` to the server's one-time public key. Throws std::invalid_argument for a secret of
// 0 or more than 1024 bytes, a bad context or a public key that isn't a valid X25519 key.
[[nodiscard]] std::vector<uint8_t> seal(std::span<const uint8_t> secret, const Context& context,
                                        std::span<const uint8_t> serverPublicKey,
                                        std::span<const uint8_t> ephemeralSecretForTesting = {});

// The server's side, with the one-time secret key it kept in memory. Throws Error, or std::invalid_argument for a
// bad context or a secret key that is not 32 bytes.
[[nodiscard]] SecretBytes open(std::span<const uint8_t> sealed, std::span<const uint8_t> serverSecretKey,
                               const Context& context);

}
