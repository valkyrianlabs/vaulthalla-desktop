// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <string_view>

// The comparison codes two screens show so a person can check they are looking at the same request (vaulthalla-cloud
// docs/design/key-manager.md, "Desktop: reads, and the hand-off" and "Transfers"; recovery-restore.md, "The restore
// code"). Each device computes its code itself from what it sent or received; the cloud's copy is a convenience only.
// Moved here from vaulthalla-cloud (vhc::keys::requestCode, transferCode; vhc::recovery::restoreCode), byte for byte.
// Vectors: vectors/vhc.json `codes`.
//
//   code = the first 8 bytes of SHA-256(input), as four groups of four lower-case hex digits joined by '-' (19
//          characters, "xxxx-xxxx-xxxx-xxxx")
//
//   request:  input = "vhc-key-request-v1\n"  ‖ request id ‖ "\n" ‖ hex(SHA-256(payload))   (lower-case hex)
//   transfer: input = "vhc-key-transfer-v1\n" ‖ account public_id ‖ "\n" ‖ base64(temporary public key)
//   restore:  input = "vhc-restore-v1\n"      ‖ vault uid text    ‖ "\n" ‖ base64(temporary public key)
//
// base64 is standard with padding (RFC 4648 §4), as the requests send the keys. The request id is the id the cloud
// assigned and the vault uid its text form, each 26 symbols of uid.hpp's alphabet as given (the padding bits are not
// checked: the cloud's own design vectors use an id whose last symbol sets them). The payload is the action's JSON
// document exactly as sent (the request's `payload` text). A transfer's temporary key is X25519 (32 bytes) or P-256
// (the 65-byte uncompressed point), a restore's X25519.
namespace vl::keykit::codes {

inline constexpr std::size_t kCodeTextSize = 19;

// Throws std::invalid_argument for an id that isn't 26 symbols of the alphabet.
[[nodiscard]] std::string requestCode(std::string_view requestId, std::string_view payload);
// Throws std::invalid_argument for a public id that isn't canonical UUID text, or a key that is neither 32 bytes nor a
// 65-byte point starting 0x04.
[[nodiscard]] std::string transferCode(std::string_view publicId, std::span<const uint8_t> temporaryPublicKey);
// Throws std::invalid_argument for a vault uid that isn't 26 symbols of the alphabet or a key that isn't 32 bytes.
[[nodiscard]] std::string restoreCode(std::string_view vaultUid, std::span<const uint8_t> temporaryPublicKey);

}
