// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include "vl/keykit/account_key.hpp"
#include "vl/keykit/kev1.hpp"
#include "vl/keykit/seed.hpp"

#include <cstdint>
#include <span>
#include <string>
#include <string_view>

// The holder proof (vaulthalla-cloud docs/design/key-manager.md, "Holders"): what a Desktop presents with
// POST /v1/keys/holders to register as a holder of the account key. The account key's Ed25519 key, of the generation
// the proof names, signs the holder's installation and its own public key, on a device that holds the seed. Moved here
// from vaulthalla-cloud (include/vhc/keys/HolderProof.hpp), byte for byte. Vectors: vectors/vhc.json `holder_proof`.
//
// Seven lines joined by '\n', no trailing newline; the first keeps its signatures apart from every other the account
// key makes (a statement starts "vhc-account-key-v1", a policy "vhc-recovery-policy-v1", and neither parser accepts
// it):
//
//   vhc-account-key-holder-v1
//   <account public_id>      canonical UUID text, as in the statement
//   <generation>             decimal, the account key generation whose Ed25519 key signs
//   <fingerprint>            that generation's fingerprint text (account_key.hpp)
//   <installation id>        the holder's installation: 26 lower-case base32 symbols, the canonical form of 16 bytes
//   <suite>                  "1" (X25519, a 32-byte key) or "2" (P-256, the 65-byte uncompressed point)
//   <holder public key>      base64url without padding
//
// The proof is Ed25519 (RFC 8032) over the exact bytes. Checks, in order: bad_installation_id, unsupported_suite,
// bad_key (a key of the wrong size for its suite, an X25519 key that is non-canonical or of low order, or a P-256 point
// that isn't on the curve: a key KAK1 can't wrap to), then bad_signature.
namespace vl::keykit::account {

inline constexpr std::string_view kHolderMagic = "vhc-account-key-holder-v1";

// The text a holder proof signs, for the generation `key`. Throws Error (bad_installation_id, unsupported_suite,
// bad_key) for inputs the checks above refuse, and std::invalid_argument for a statement encode would refuse.
[[nodiscard]] std::string holderMessage(const KeyStatement& key, std::string_view installationId, kev1::Suite suite,
                                        std::span<const uint8_t> holderPublicKey);

// The proof: holderMessage signed with the account key `seed` of generation `key`. Throws what holderMessage throws,
// and std::invalid_argument when the seed's keys aren't the statement's.
[[nodiscard]] Signature signHolderProof(const KeyStatement& key, const RecoverySeed& seed,
                                        std::string_view installationId, kev1::Suite suite,
                                        std::span<const uint8_t> holderPublicKey);

// The verifier's checks above: throws Error with the first that fails (bad_signature when the proof isn't the
// Ed25519 key of `key` signing holderMessage), or std::invalid_argument for a statement encode would refuse.
void checkHolderProof(const KeyStatement& key, std::string_view installationId, kev1::Suite suite,
                      std::span<const uint8_t> holderPublicKey, const Signature& proof);

// The same as a predicate (the cloud's): false for anything checkHolderProof refuses.
[[nodiscard]] bool verifyHolderProof(const KeyStatement& key, std::string_view installationId, kev1::Suite suite,
                                     std::span<const uint8_t> holderPublicKey, const Signature& proof) noexcept;

}
