// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include "vl/keykit/account_key.hpp"
#include "vl/keykit/uid.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

// A vault's display name sealed to the account key (vaulthalla-cloud docs/design/account-model.md, "What the cloud
// knows about a vault"): a server seals it to its pinned account key and sends it with PUT /v1/vaults/{uid}/label;
// Desktop and the portal open it with the unlocked account key; the cloud stores bytes it can't read. KEV1 suite 1's
// construction under its own label, with the account, the vault and the key generation in the authenticated prefix,
// and the name padded to 128 bytes so its length doesn't show. Vectors: vectors/vhc.json `vault_label`.
//
//   offset  len  field
//    0       8   magic 89 56 48 4C 0D 0A 1A 0A ("\x89VHL\r\n\x1a\n")
//    8       2   version 1
//   10       2   suite 1 (X25519 + HKDF-SHA-256 + AES-256-GCM; the only one)
//   12       4   generation of the account key it is sealed to
//   16      16   account public_id (the UUID's 16 bytes)
//   32      16   vault_uid
//   48      16   fingerprint of that generation
//   64      32   epk, fresh per label
//   96     144   AES-256-GCM(K, nonce 0^12, name ‖ 0^(128 - len), AAD = bytes[0 .. 96))
//
//   K = HKDF-Expand(HKDF-Extract(salt = epk ‖ account X25519 public key, IKM = Z), "vh.vault-label.v1" ‖ prefix, 32)
//
// 240 bytes. The name is 1-128 bytes of UTF-8 without control characters (so without NUL); everything after it is
// zero. Reader checks, in order: bad_magic, unsupported_version, unsupported_suite, account_mismatch, vault_mismatch,
// key_mismatch (another generation or fingerprint than the reader's statement), bad_length, bad_ephemeral,
// auth_failed, bad_label (an empty name, bytes after the padding starts that aren't zero, or not plain UTF-8).
namespace vl::keykit::label {

inline constexpr std::array<uint8_t, 8> kMagic{0x89, 0x56, 0x48, 0x4C, 0x0D, 0x0A, 0x1A, 0x0A};
inline constexpr uint16_t kVersion = 1;
inline constexpr std::size_t kPrefixSize = 96;
inline constexpr std::size_t kPaddedSize = 128;
inline constexpr std::size_t kSealedSize = kPrefixSize + kPaddedSize + 16;

enum class ErrorCode : uint8_t {
    BadMagic,
    UnsupportedVersion,
    UnsupportedSuite,
    AccountMismatch,
    VaultMismatch,
    KeyMismatch,
    BadLength,
    BadEphemeral,
    AuthFailed,
    BadLabel,
};

[[nodiscard]] std::string_view errorCodeName(ErrorCode code);

class Error : public std::runtime_error {
public:
    explicit Error(ErrorCode code);
    [[nodiscard]] ErrorCode code() const noexcept { return code_; }

private:
    ErrorCode code_;
};

// Whether `name` can be sealed: 1-128 bytes of UTF-8 without control characters. A server truncates or refuses
// longer names before sealing.
[[nodiscard]] bool isSealableName(std::string_view name);

// Seals `name` for vault `vaultUid` to the account key of `pinned` (its X25519 key). Throws std::invalid_argument for
// a name isSealableName refuses or a statement encode would refuse.
[[nodiscard]] std::vector<uint8_t> seal(std::string_view name, const account::KeyStatement& pinned, const Uid& vaultUid,
                                        std::span<const uint8_t> ephemeralSecretForTesting = {});

// Opens a label with the account key's X25519 secret (RecoverySeed::x25519SecretKey) of the generation `statement`.
// Throws Error with the first check that fails. A name is not a secret, so it comes back as a plain string.
[[nodiscard]] std::string open(std::span<const uint8_t> sealed, std::span<const uint8_t> accountX25519Secret,
                               const account::KeyStatement& statement, const Uid& vaultUid);

// The generation a label is sealed to, read without a key (a server finding labels to reseal after a replacement).
// Applies the structural checks (magic, version, suite, length).
[[nodiscard]] uint32_t sealedGeneration(std::span<const uint8_t> sealed);

}
