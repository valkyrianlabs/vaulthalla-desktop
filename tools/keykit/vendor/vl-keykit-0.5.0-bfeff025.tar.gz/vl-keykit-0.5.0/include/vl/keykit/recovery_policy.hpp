// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include "vl/keykit/account_key.hpp"

#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <string_view>
#include <vector>

// The account's signed recovery policy (vaulthalla-server design/cloud/key-manager.md, "The account's recovery
// policy"; vaulthalla-cloud docs/design/key-manager.md): the recovery recipients the account holder authorizes besides
// the account key itself, signed with the account key's Ed25519 key on a device that holds it, and verified by every
// server against its own pin. Vectors: vectors/vhc.json `recovery_policy`.
//
// Lines joined by '\n', no trailing newline:
//
//   vhc-recovery-policy-v1
//   <account public_id>     canonical UUID text, as in the key statement
//   <sequence>              decimal, 1 to 2^32 - 1, no leading zero: 1, then one more per change
//   <generation>            the account key generation whose Ed25519 key signs
//   <issued_at>             UTC "YYYY-MM-DDTHH:MM:SSZ" (informational: the sequence orders policies)
//   <recipient>             zero to 64 lines, strictly increasing by recipient_id bytes (so no duplicates), each six
//                           fields separated by one space:
//     <recipient_id> <x25519 public key> <suite> <class> <label> <scope>
//       recipient_id        base64url SHA-256 of the public key (43 characters)
//       x25519 public key   base64url (43 characters); canonical and not of low order, as in the key statement
//       suite               "1" (KEV1 suite 1, X25519)
//       class               "customer"
//       label               base64url of 1-128 bytes of UTF-8 without control characters
//       scope               "account": every vault the account key covers (a list of vaults is reserved, not built)
//
// The signature is Ed25519 over the exact bytes. Parsing errors, in the order checked: unsupported_version (a first
// line "vhc-recovery-policy-v<digits>" other than v1), bad_policy (any other first line, or fewer than five lines),
// bad_public_id, bad_sequence, bad_generation, bad_issued_at, too_many_recipients, then per recipient line:
// bad_recipient (not six fields, or a recipient_id that is not 32 bytes), bad_base64url, bad_key,
// recipient_id_mismatch, unsupported_suite, unsupported_class, bad_label, unsupported_scope, unsorted_recipients.
// Verification adds account_mismatch, generation_mismatch, bad_signature and account_key_listed (the account key is a
// recipient through the pin, never through the policy).
namespace vl::keykit::account {

inline constexpr std::string_view kPolicyMagic = "vhc-recovery-policy-v1";
inline constexpr std::size_t kMaxPolicyRecipients = 64;
inline constexpr std::size_t kMaxRecipientLabelSize = 128;

struct PolicyRecipient {
    PublicKey x25519_public{};
    std::string label{};  // UTF-8, 1-128 bytes, no control characters
    // The suite (1), class (customer) and scope (account) are the only ones v1 has.
    [[nodiscard]] Digest recipientId() const;  // SHA-256 of the public key
    [[nodiscard]] bool operator==(const PolicyRecipient&) const = default;
};

struct RecoveryPolicy {
    std::string public_id{};
    uint32_t sequence{};
    uint32_t generation{};
    std::string issued_at{};
    std::vector<PolicyRecipient> recipients{};  // in canonical order after parse; any order for encode
    [[nodiscard]] bool operator==(const RecoveryPolicy&) const = default;
};

// The canonical text, recipients sorted by recipient_id. Throws std::invalid_argument for a policy parse would refuse
// (including two recipients with the same key).
[[nodiscard]] std::string encode(const RecoveryPolicy& policy);
// Strict: the only accepted text is encode's. Throws Error.
[[nodiscard]] RecoveryPolicy parsePolicy(std::string_view text);

// SHA-256 of the policy's bytes: what a server keeps beside the accepted sequence.
[[nodiscard]] Digest policyHash(std::string_view text);

struct SignedPolicy {
    std::string policy{};
    Signature signature{};
};

// Signs encode(policy) with the account key of `current` (the generation the policy names; `key` must be its seed).
// Throws std::invalid_argument when the policy names another account or generation or the seed doesn't match.
[[nodiscard]] SignedPolicy signPolicy(const RecoveryPolicy& policy, const RecoverySeed& key,
                                      const KeyStatement& current);

struct VerifiedPolicy {
    RecoveryPolicy policy{};
    Digest hash{};
};

// Verification against a server's pinned account key (the statement of its pinned generation): parse; the policy's
// public_id is the pin's (account_mismatch); its generation is the pinned one (generation_mismatch: another generation,
// pending, refused or superseded, signs nothing); the signature verifies under the pinned Ed25519 key (bad_signature);
// no recipient is the account key's own X25519 key (account_key_listed). Throws Error. The sequence floor is the
// caller's: compare the result with compareToFloor.
[[nodiscard]] VerifiedPolicy verifyPolicy(const SignedPolicy& signedPolicy, const KeyStatement& pinned);

// The highest policy a server (or the cloud) has accepted: its sequence (0 when none) and policyHash.
struct PolicyFloor {
    uint32_t sequence{};
    Digest hash{};
};
[[nodiscard]] PolicyFloor floorOf(const VerifiedPolicy& policy) noexcept;

enum class SequenceVerdict : uint8_t {
    Newer,      // above the floor: apply it, then store floorOf(it)
    Unchanged,  // the floor's own policy: nothing to do
    Older,      // below the floor: refuse (a rollback)
    Conflict,   // the floor's sequence with other bytes: two different policies signed under one number; refuse
};
[[nodiscard]] std::string_view sequenceVerdictName(SequenceVerdict verdict);

// The server's rule: a policy is applied only above the floor it keeps under its pin's MAC. Taking whichever of two
// valid policies (the cloud's and a bucket root's) is newer is compareToFloor(b, floorOf(a)) == Newer.
[[nodiscard]] SequenceVerdict compareToFloor(const VerifiedPolicy& policy, const PolicyFloor& floor) noexcept;

// The cloud's rule for PUT /v1/keys/account/policy: exactly one more than the stored sequence (0 when none).
[[nodiscard]] bool isNextSequence(uint32_t stored, uint32_t candidate) noexcept;

}
