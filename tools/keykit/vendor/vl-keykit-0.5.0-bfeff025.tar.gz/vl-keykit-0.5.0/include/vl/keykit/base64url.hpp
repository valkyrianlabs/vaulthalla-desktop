// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <vector>

// base64url without padding (RFC 4648 §5), as the account key statement and recovery policy write keys and the cloud's
// JSON carries sealed bytes. The decoder is strict, so every byte string has one spelling: only the URL alphabet, no
// '=' or whitespace, no length of 1 mod 4, and zero trailing bits; nullopt otherwise.
namespace vl::keykit {

[[nodiscard]] std::string base64UrlEncode(std::span<const uint8_t> bytes);
[[nodiscard]] std::optional<std::vector<uint8_t>> base64UrlDecode(std::string_view text);

}
