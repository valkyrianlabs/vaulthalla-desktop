// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// Key provenance: the key check of a vault key version and an origin's attestation over it, the one implementation
// every producer (a server, a Mac) and verifier (a server's restore) uses (vaulthalla-server
// design/encryption/03-metadata-recovery.md §6.5; vectors: vectors/vectors.json `key_provenance`).
//
//   key_check   = lower-case hex of BLAKE2b-128 keyed by the 32 key bytes over
//                 "vh-key-check-v1" ‖ ASCII-decimal(vault_id) ‖ UInt32BE(version)
//   attestation = Ed25519 (RFC 8032, a 32-byte seed) over
//                 "vh-key-attest-v1" ‖ node_id (UTF-8) ‖ UInt64BE(vault_id) ‖ UInt32BE(version) ‖ key_check (16 bytes)
//
// vault_id is the origin's id for the vault: a server's local serial, or, for a vault a Mac created (which has none),
// macOriginVaultId(uid). node_id is a server's node id (a UUID string) or the Mac's Vaulthalla Cloud installation id
// (26 base32 symbols), so a Mac's origin is never a server's.

#include "vl/keykit/uid.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace vl::keykit::provenance {

inline constexpr std::string_view kKeyCheckDomain = "vh-key-check-v1";
inline constexpr std::string_view kAttestationDomain = "vh-key-attest-v1";
inline constexpr std::size_t kKeySize = 32;
inline constexpr std::size_t kKeyCheckSize = 16;  // raw bytes; 32 hex digits
inline constexpr std::size_t kSeedSize = 32;
inline constexpr std::size_t kPublicKeySize = 32;
inline constexpr std::size_t kSignatureSize = 64;
// The largest vault id a server issues (a PostgreSQL SERIAL), and the range macOriginVaultId maps into.
inline constexpr std::uint32_t kMaxVaultId = 2147483647;

enum class ErrorCode : uint8_t {
    BadKey,       // not 32 key bytes
    BadVaultId,   // 0
    BadNodeId,    // empty
    BadKeyCheck,  // not 32 lower-case hex digits
    BadSeed,      // not 32 seed bytes
};

[[nodiscard]] std::string_view errorCodeName(ErrorCode code);

class Error : public std::invalid_argument {
public:
    explicit Error(ErrorCode code);
    [[nodiscard]] ErrorCode code() const noexcept { return code_; }

private:
    ErrorCode code_;
};

// The key check of `key` (32 bytes) as version `version` of the vault the origin calls `vaultId` (>= 1).
[[nodiscard]] std::string keyCheck(std::span<const uint8_t> key, uint64_t vaultId, uint32_t version);

// Constant-time comparison of two key checks; false when either is not 32 characters.
[[nodiscard]] bool keyCheckEquals(std::string_view a, std::string_view b) noexcept;

// The bytes an attestation signs.
[[nodiscard]] std::vector<uint8_t> attestationMessage(std::string_view nodeId, uint64_t vaultId, uint32_t version,
                                                      std::string_view keyCheckHex);

// The Ed25519 public key of an attestation seed, and the signature of the attestation over (nodeId, vaultId, version,
// keyCheckHex) by it.
[[nodiscard]] std::array<uint8_t, kPublicKeySize> attestationPublicKey(std::span<const uint8_t> seed);
[[nodiscard]] std::array<uint8_t, kSignatureSize> attest(std::span<const uint8_t> seed, std::string_view nodeId,
                                                         uint64_t vaultId, uint32_t version,
                                                         std::string_view keyCheckHex);

// Whether `signature` is `publicKey`'s attestation over (nodeId, vaultId, version, keyCheckHex). False for anything
// malformed (a key or signature of the wrong size, an empty node id, vault id 0, a malformed key check).
[[nodiscard]] bool verifyAttestation(std::span<const uint8_t> publicKey, std::string_view nodeId, uint64_t vaultId,
                                     uint32_t version, std::string_view keyCheckHex,
                                     std::span<const uint8_t> signature) noexcept;

// The origin vault id of a vault a Mac created: 1 + (UInt32BE(uid[0..3]) mod (2^31 - 1)), in a server's range.
[[nodiscard]] uint32_t macOriginVaultId(const Uid& vaultUid) noexcept;

}
