#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Valkyrian Labs LLC
"""Reference implementation and golden vectors for vl-keykit's Vaulthalla Cloud formats.

Formats (normative text in include/vl/keykit/):
  - The account key statement, its fingerprint and the chain across generations (account_key.hpp).
  - The signed recovery policy, vhc-recovery-policy-v1 (recovery_policy.hpp).
  - KAK1, the account key wrapped to a holder (kak1.hpp).
  - The vault label sealed to the account key, vh.vault-label.v1 (vault_label.hpp).
  - The sealed storage credential, vhc-storage-credential-v1 (storage_credential.hpp).
  - The holder proof, vhc-account-key-holder-v1 (holder_proof.hpp).
  - The request, transfer and restore comparison codes (key_codes.hpp).
  - The account public id's 16 bytes (account_key.hpp, parsePublicId).

Usage:
  python3 vhc_vectors.py            # write vhc.json next to this script
  python3 vhc_vectors.py --check    # regenerate in memory, compare with vhc.json byte for byte, then run the
                                    # independent reference readers over every vector
  python3 vhc_vectors.py --out PATH # write somewhere else

Only fixed seeds, keys and ephemeral keys are used and Ed25519 is deterministic, so the output is deterministic. The
readers below never call the writers: --check proves that the committed file is what this script generates and that a
separate decoding path accepts every positive vector and rejects every negative one with the documented error code.
The recovery seed derivation is checked against vectors.json's `recovery_seed` section.

Dependencies: Python 3.10+, `cryptography` >= 41 (AES-GCM, X25519, Ed25519, P-256). HKDF comes from the standard
library so the construction is visible here.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import re
import struct
import sys
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

SCHEMA = "vhc-keykit-vectors/1"
HERE = Path(__file__).resolve().parent
DEFAULT_OUT = HERE / "vhc.json"

# --------------------------------------------------------------------------------------------------------------------
# Common helpers
# --------------------------------------------------------------------------------------------------------------------

B32_ALPHABET = "0123456789abcdefghjkmnpqrstvwxyz"
RAW = serialization.Encoding.Raw
RAW_PUB = serialization.PublicFormat.Raw


def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def hkdf(ikm: bytes, salt: bytes, info: bytes, length: int = 32) -> bytes:
    prk = hmac.new(salt, ikm, hashlib.sha256).digest()
    out, block, counter = b"", b"", 1
    while len(out) < length:
        block = hmac.new(prk, block + info + bytes([counter]), hashlib.sha256).digest()
        out += block
        counter += 1
    return out[:length]


def label_bytes(label: str, n: int) -> bytes:
    """Fixed test material: the first n bytes of SHA-256(label) (SHA-256 chaining when n > 32)."""
    out, block = b"", label.encode()
    while len(out) < n:
        block = sha256(block)
        out += block
    return out[:n]


def b32_uid(data: bytes) -> str:
    bits = int.from_bytes(data, "big") << 2
    return "".join(B32_ALPHABET[(bits >> (5 * (25 - i))) & 31] for i in range(26))


def b32_uid_decode(text: str) -> bytes | None:
    if len(text) != 26 or any(c not in B32_ALPHABET for c in text):
        return None
    value = 0
    for c in text:
        value = value << 5 | B32_ALPHABET.index(c)
    if value & 3:
        return None
    return (value >> 2).to_bytes(16, "big")


def b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


B64U_RE = re.compile(r"[A-Za-z0-9_-]*")


def b64u_decode(text: str) -> bytes | None:
    """Strict: URL alphabet only, no padding, not 1 mod 4, zero trailing bits (one spelling per byte string)."""
    if B64U_RE.fullmatch(text) is None or len(text) % 4 == 1:
        return None
    data = base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))
    return data if b64u(data) == text else None


def recovery_keys(seed: bytes) -> tuple[bytes, bytes, bytes, bytes]:
    """(x25519 sk, x25519 pk, ed25519 seed, ed25519 pk) of a recovery seed (vl/keykit/seed.hpp)."""
    xsk = hkdf(seed, b"vh.recovery.v1", b"x25519")
    eseed = hkdf(seed, b"vh.recovery.v1", b"ed25519")
    xpk = X25519PrivateKey.from_private_bytes(xsk).public_key().public_bytes(RAW, RAW_PUB)
    epk = Ed25519PrivateKey.from_private_bytes(eseed).public_key().public_bytes(RAW, RAW_PUB)
    return xsk, xpk, eseed, epk


def seed_text(seed: bytes) -> str:
    bits = int.from_bytes(seed, "big") << 2
    body = "".join(B32_ALPHABET[(bits >> (5 * (25 - i))) & 31] for i in range(26))
    return body + B32_ALPHABET[sha256(seed)[0] >> 3]


def x25519_pub(sk: bytes) -> bytes:
    return X25519PrivateKey.from_private_bytes(sk).public_key().public_bytes(RAW, RAW_PUB)


def p256_pub(scalar: bytes) -> bytes:
    key = ec.derive_private_key(int.from_bytes(scalar, "big"), ec.SECP256R1())
    return key.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)


def ecdh(suite: int, sk: bytes, peer: bytes) -> bytes:
    """Z (X25519 output or P-256 x-coordinate); ValueError for a refused peer or an all-zero Z."""
    if suite == 1:
        z = X25519PrivateKey.from_private_bytes(sk).exchange(X25519PublicKey.from_public_bytes(peer))
    else:
        mine = ec.derive_private_key(int.from_bytes(sk, "big"), ec.SECP256R1())
        z = mine.exchange(ec.ECDH(), ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), peer))
    if z == bytes(len(z)):
        raise ValueError("all-zero shared secret")
    return z


def pub_of(suite: int, sk: bytes) -> bytes:
    return x25519_pub(sk) if suite == 1 else p256_pub(sk)


P25519 = 2**255 - 19


def strict_x25519(pk: bytes) -> bool:
    """Canonical (u < p, top bit clear) and not of low order (X25519 with a clamped scalar is not all zero)."""
    if len(pk) != 32 or int.from_bytes(pk, "little") >= P25519:
        return False
    try:
        ecdh(1, bytes([9]) + bytes(31), pk)
    except ValueError:
        return False
    return True


def uuid_bytes(text: str) -> bytes | None:
    if re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", text) is None:
        return None
    return bytes.fromhex(text.replace("-", ""))


def positive32(text: str) -> int | None:
    if re.fullmatch(r"[1-9][0-9]{0,9}", text) is None:
        return None
    value = int(text)
    return value if value <= 0xFFFFFFFF else None


def is_timestamp(text: str) -> bool:
    m = re.fullmatch(r"([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})Z", text)
    if m is None:
        return False
    y, mo, d, h, mi, s = (int(g) for g in m.groups())
    if y < 2000 or not 1 <= mo <= 12 or d < 1 or h > 23 or mi > 59 or s > 59:
        return False
    leap = (y % 4 == 0 and y % 100 != 0) or y % 400 == 0
    days = [31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][mo - 1]
    return d <= days


def is_label(data: bytes, max_bytes: int) -> bool:
    if not 1 <= len(data) <= max_bytes:
        return False
    try:
        text = data.decode("utf-8")  # strict: no overlong forms, surrogates or code points above U+10FFFF
    except UnicodeDecodeError:
        return False
    return all(not (ord(c) < 0x20 or 0x7F <= ord(c) <= 0x9F) for c in text)


def other_version(line: str, stem: str) -> bool:
    return line.startswith(stem) and re.fullmatch(r"[0-9]+", line[len(stem):]) is not None


class Refused(Exception):
    def __init__(self, code: str, index: int | None = None):
        super().__init__(code)
        self.code = code
        self.index = index


# --------------------------------------------------------------------------------------------------------------------
# Writers
# --------------------------------------------------------------------------------------------------------------------

STATEMENT_MAGIC = "vhc-account-key-v1"
POLICY_MAGIC = "vhc-recovery-policy-v1"


def fingerprint_input(public_id: str, generation: int, xpk: bytes, epk: bytes) -> str:
    return "\n".join([STATEMENT_MAGIC, public_id, str(generation), b64u(xpk), b64u(epk)])


def fingerprint(public_id: str, generation: int, xpk: bytes, epk: bytes) -> bytes:
    return sha256(fingerprint_input(public_id, generation, xpk, epk).encode())[:16]


def fp_text(fp: bytes) -> str:
    h = fp.hex()
    return "-".join(h[i:i + 4] for i in range(0, 32, 4))


def make_statement(seed: bytes, public_id: str, generation: int, previous: bytes | None, reason: str) -> str:
    _, xpk, _, epk = recovery_keys(seed)
    return fingerprint_input(public_id, generation, xpk, epk) + "\n" + (fp_text(previous) if previous else "") + \
        "\n" + reason


def ed_sign(seed: bytes, message: bytes) -> bytes:
    return Ed25519PrivateKey.from_private_bytes(recovery_keys(seed)[2]).sign(message)


def make_policy(public_id: str, sequence: int, generation: int, issued_at: str,
                recipients: list[tuple[bytes, str]], *, keep_order: bool = False) -> str:
    rows = [(sha256(pk), pk, label) for pk, label in recipients]
    if not keep_order:
        rows.sort(key=lambda r: r[0])
    lines = [POLICY_MAGIC, public_id, str(sequence), str(generation), issued_at]
    lines += [f"{b64u(rid)} {b64u(pk)} 1 customer {b64u(label.encode())} account" for rid, pk, label in rows]
    return "\n".join(lines)


KAK1_MAGIC = bytes([0x89, 0x56, 0x48, 0x41, 0x0D, 0x0A, 0x1A, 0x0A])
LABEL_MAGIC = bytes([0x89, 0x56, 0x48, 0x4C, 0x0D, 0x0A, 0x1A, 0x0A])
CRED_MAGIC = bytes([0x89, 0x56, 0x48, 0x43, 0x0D, 0x0A, 0x1A, 0x0A])
KAK1_INFO = b"vhc.kak1.wrap"
LABEL_INFO = b"vh.vault-label.v1"
CRED_INFO = b"vhc-storage-credential-v1"
ZERO_NONCE = bytes(12)


def kak1_wrap(seed: bytes, public_id: str, generation: int, fp: bytes, suite: int, hpk: bytes, esk: bytes,
              *, version: int = 1) -> bytes:
    epk = pub_of(suite, esk)
    prefix = KAK1_MAGIC + struct.pack(">HHI", version, suite, generation) + uuid_bytes(public_id) + fp + \
        sha256(hpk) + struct.pack(">H", len(epk)) + epk
    key = hkdf(ecdh(suite, esk, hpk), epk + hpk, KAK1_INFO + prefix)
    return prefix + AESGCM(key).encrypt(ZERO_NONCE, seed, prefix)


def label_seal(name: bytes, public_id: str, generation: int, fp: bytes, vault_uid: bytes, apk: bytes, esk: bytes,
               *, padded: bytes | None = None, suite: int = 1, version: int = 1) -> bytes:
    epk = x25519_pub(esk)
    prefix = LABEL_MAGIC + struct.pack(">HHI", version, suite, generation) + uuid_bytes(public_id) + vault_uid + fp + epk
    key = hkdf(ecdh(1, esk, apk), epk + apk, LABEL_INFO + prefix)
    plaintext = padded if padded is not None else name + bytes(128 - len(name))
    return prefix + AESGCM(key).encrypt(ZERO_NONCE, plaintext, prefix)


def cred_context(installation_id: str, vault_uid: bytes, key_id: str) -> bytes:
    return f"vhc-storage-credential-v1\n{installation_id}\n{b32_uid(vault_uid)}\n{key_id}".encode()


def cred_seal(secret: bytes, installation_id: str, vault_uid: bytes, key_id: str, spk: bytes, esk: bytes,
              *, suite: int = 1, version: int = 1) -> bytes:
    epk = x25519_pub(esk)
    prefix = CRED_MAGIC + struct.pack(">HH", version, suite) + epk
    key = hkdf(ecdh(1, esk, spk), epk + spk, CRED_INFO + prefix)
    return prefix + AESGCM(key).encrypt(ZERO_NONCE, secret, prefix + cred_context(installation_id, vault_uid, key_id))


HOLDER_MAGIC = "vhc-account-key-holder-v1"


def holder_message(public_id: str, generation: int, fp: bytes, installation_id: str, suite: int, hpk: bytes) -> str:
    return "\n".join([HOLDER_MAGIC, public_id, str(generation), fp_text(fp), installation_id, str(suite), b64u(hpk)])


def short_code(text: str) -> str:
    h = sha256(text.encode()).hex()[:16]
    return "-".join(h[i:i + 4] for i in range(0, 16, 4))


def b64(data: bytes) -> str:
    return base64.b64encode(data).decode()


def request_code(request_id: str, payload: str) -> str:
    return short_code("vhc-key-request-v1\n" + request_id + "\n" + sha256(payload.encode()).hex())


def transfer_code(public_id: str, key: bytes) -> str:
    return short_code("vhc-key-transfer-v1\n" + public_id + "\n" + b64(key))


def restore_code(vault_uid: str, key: bytes) -> str:
    return short_code("vhc-restore-v1\n" + vault_uid + "\n" + b64(key))


# --------------------------------------------------------------------------------------------------------------------
# Readers (independent of the writers)
# --------------------------------------------------------------------------------------------------------------------


def parse_statement(text: str) -> dict:
    lines = text.split("\n")
    if lines[0] != STATEMENT_MAGIC:
        raise Refused("unsupported_version" if other_version(lines[0], "vhc-account-key-v") else "bad_statement")
    if len(lines) != 7:
        raise Refused("bad_statement")
    if uuid_bytes(lines[1]) is None:
        raise Refused("bad_public_id")
    generation = positive32(lines[2])
    if generation is None:
        raise Refused("bad_generation")
    keys = []
    for line in lines[3:5]:
        raw = b64u_decode(line)
        if raw is None:
            raise Refused("bad_base64url")
        if len(raw) != 32:
            raise Refused("bad_key")
        if not keys and not strict_x25519(raw):
            raise Refused("bad_key")
        keys.append(raw)
    previous = None
    if generation == 1:
        if lines[5] != "":
            raise Refused("bad_previous")
    else:
        if re.fullmatch(r"[0-9a-f]{4}(-[0-9a-f]{4}){7}", lines[5]) is None:
            raise Refused("bad_previous")
        previous = bytes.fromhex(lines[5].replace("-", ""))
    reason = lines[6]
    if reason not in ("initial", "routine", "compromise") or (generation == 1) != (reason == "initial"):
        raise Refused("bad_reason")
    fp = sha256("\n".join(lines[:5]).encode())[:16]
    return {"public_id": lines[1], "generation": generation, "x25519": keys[0], "ed25519": keys[1],
            "previous": previous, "reason": reason, "fingerprint": fp}


def ed_verify(pk: bytes, message: bytes, sig: bytes) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(pk).verify(sig, message)
        return True
    except (InvalidSignature, ValueError):
        return False


def verify_chain(chain: list[dict], public_id: str) -> list[dict]:
    if not chain:
        raise Refused("bad_statement", 0)
    out: list[dict] = []
    for i, item in enumerate(chain):
        try:
            s = parse_statement(item["statement"])
        except Refused as e:
            raise Refused(e.code, i) from None
        if s["public_id"] != public_id:
            raise Refused("account_mismatch", i)
        if s["generation"] != i + 1:
            raise Refused("generation_gap", i)
        msg = item["statement"].encode()
        if not ed_verify(s["ed25519"], msg, bytes.fromhex(item["signature_hex"])):
            raise Refused("bad_signature", i)
        prev_sig = item.get("previous_signature_hex")
        if i == 0:
            if prev_sig is not None:
                raise Refused("bad_previous_signature", i)
            s["link"] = "initial"
        else:
            if s["previous"] != out[-1]["fingerprint"]:
                raise Refused("previous_mismatch", i)
            if prev_sig is not None:
                if not ed_verify(out[-1]["ed25519"], msg, bytes.fromhex(prev_sig)):
                    raise Refused("bad_previous_signature", i)
                s["link"] = "rotation"
            else:
                s["link"] = "replacement"
        out.append(s)
    return out


def follow(pin_generation: int, pin_fp: bytes, chain: list[dict]) -> dict:
    if pin_generation == 0 or len(chain) < pin_generation:
        raise Refused("rollback")
    if chain[pin_generation - 1]["fingerprint"] != pin_fp:
        raise Refused("pin_mismatch")
    accepted = pin_generation
    while accepted < len(chain) and chain[accepted]["link"] == "rotation":
        accepted += 1
    return {"accepted": accepted, "newest": len(chain)}


def parse_policy(text: str) -> dict:
    lines = text.split("\n")
    if lines[0] != POLICY_MAGIC:
        raise Refused("unsupported_version" if other_version(lines[0], "vhc-recovery-policy-v") else "bad_policy")
    if len(lines) < 5:
        raise Refused("bad_policy")
    if uuid_bytes(lines[1]) is None:
        raise Refused("bad_public_id")
    sequence = positive32(lines[2])
    if sequence is None:
        raise Refused("bad_sequence")
    generation = positive32(lines[3])
    if generation is None:
        raise Refused("bad_generation")
    if not is_timestamp(lines[4]):
        raise Refused("bad_issued_at")
    if len(lines) - 5 > 64:
        raise Refused("too_many_recipients")
    recipients = []
    for line in lines[5:]:
        fields = line.split(" ")
        if len(fields) != 6:
            raise Refused("bad_recipient")
        rid = b64u_decode(fields[0])
        if rid is None:
            raise Refused("bad_base64url")
        if len(rid) != 32:
            raise Refused("bad_recipient")
        pk = b64u_decode(fields[1])
        if pk is None:
            raise Refused("bad_base64url")
        if len(pk) != 32 or not strict_x25519(pk):
            raise Refused("bad_key")
        if sha256(pk) != rid:
            raise Refused("recipient_id_mismatch")
        if fields[2] != "1":
            raise Refused("unsupported_suite")
        if fields[3] != "customer":
            raise Refused("unsupported_class")
        label = b64u_decode(fields[4])
        if label is None:
            raise Refused("bad_base64url")
        if not is_label(label, 128):
            raise Refused("bad_label")
        if fields[5] != "account":
            raise Refused("unsupported_scope")
        if recipients and not recipients[-1]["recipient_id"] < rid:
            raise Refused("unsorted_recipients")
        recipients.append({"recipient_id": rid, "x25519": pk, "label": label.decode()})
    return {"public_id": lines[1], "sequence": sequence, "generation": generation, "issued_at": lines[4],
            "recipients": recipients}


def verify_policy(text: str, sig: bytes, pinned: dict) -> dict:
    p = parse_policy(text)
    if p["public_id"] != pinned["public_id"]:
        raise Refused("account_mismatch")
    if p["generation"] != pinned["generation"]:
        raise Refused("generation_mismatch")
    if not ed_verify(pinned["ed25519"], text.encode(), sig):
        raise Refused("bad_signature")
    if any(r["x25519"] == pinned["x25519"] for r in p["recipients"]):
        raise Refused("account_key_listed")
    p["hash"] = sha256(text.encode())
    return p


def compare_to_floor(sequence: int, digest: bytes, floor_sequence: int, floor_hash: bytes) -> str:
    if sequence > floor_sequence:
        return "newer"
    if sequence < floor_sequence:
        return "older"
    return "unchanged" if hmac.compare_digest(digest, floor_hash) else "conflict"


def kak1_unwrap(env: bytes, hsk: bytes, suite_expected: int, statement: dict) -> bytes:
    if len(env) < 82 or env[:8] != KAK1_MAGIC:
        raise Refused("bad_magic")
    version, suite, generation = struct.unpack(">HHI", env[8:16])
    if version != 1:
        raise Refused("unsupported_version")
    if suite not in (1, 2) or suite != suite_expected:
        raise Refused("unsupported_suite")
    if env[16:32] != uuid_bytes(statement["public_id"]):
        raise Refused("account_mismatch")
    if generation != statement["generation"] or env[32:48] != statement["fingerprint"]:
        raise Refused("key_mismatch")
    try:
        hpk = pub_of(suite, hsk)
    except ValueError:
        hpk = b""
    if env[48:80] != sha256(hpk):
        raise Refused("recipient_mismatch")
    (epk_len,) = struct.unpack(">H", env[80:82])
    if epk_len != (32 if suite == 1 else 65) or len(env) != 82 + epk_len + 32:
        raise Refused("bad_length")
    prefix, epk = env[:82 + epk_len], env[82:82 + epk_len]
    try:
        z = ecdh(suite, hsk, epk)
    except ValueError:
        raise Refused("bad_ephemeral") from None
    try:
        seed = AESGCM(hkdf(z, epk + hpk, KAK1_INFO + prefix)).decrypt(ZERO_NONCE, env[len(prefix):], prefix)
    except Exception:
        raise Refused("wrap_auth_failed") from None
    _, xpk, _, edpk = recovery_keys(seed)
    if fingerprint(statement["public_id"], generation, xpk, edpk) != statement["fingerprint"]:
        raise Refused("seed_mismatch")
    return seed


def label_open(sealed: bytes, ask: bytes, statement: dict, vault_uid: bytes) -> str:
    if len(sealed) < 96 or sealed[:8] != LABEL_MAGIC:
        raise Refused("bad_magic")
    version, suite, generation = struct.unpack(">HHI", sealed[8:16])
    if version != 1:
        raise Refused("unsupported_version")
    if suite != 1:
        raise Refused("unsupported_suite")
    if sealed[16:32] != uuid_bytes(statement["public_id"]):
        raise Refused("account_mismatch")
    if sealed[32:48] != vault_uid:
        raise Refused("vault_mismatch")
    if generation != statement["generation"] or sealed[48:64] != statement["fingerprint"]:
        raise Refused("key_mismatch")
    if len(sealed) != 240:
        raise Refused("bad_length")
    prefix, epk = sealed[:96], sealed[64:96]
    try:
        z = ecdh(1, ask, epk)
    except ValueError:
        raise Refused("bad_ephemeral") from None
    try:
        padded = AESGCM(hkdf(z, epk + statement["x25519"], LABEL_INFO + prefix)).decrypt(ZERO_NONCE, sealed[96:],
                                                                                       prefix)
    except Exception:
        raise Refused("auth_failed") from None
    name = padded.split(b"\0", 1)[0]
    if any(padded[len(name):]) or not is_label(name, 128):
        raise Refused("bad_label")
    return name.decode()


def cred_open(sealed: bytes, ssk: bytes, installation_id: str, vault_uid: bytes, key_id: str) -> bytes:
    if len(sealed) < 44 or sealed[:8] != CRED_MAGIC:
        raise Refused("bad_magic")
    version, suite = struct.unpack(">HH", sealed[8:12])
    if version != 1:
        raise Refused("unsupported_version")
    if suite != 1:
        raise Refused("unsupported_suite")
    if not 44 + 1 + 16 <= len(sealed) <= 44 + 1024 + 16:
        raise Refused("bad_length")
    prefix, epk = sealed[:44], sealed[12:44]
    spk = x25519_pub(ssk)
    try:
        z = ecdh(1, ssk, epk)
    except ValueError:
        raise Refused("bad_ephemeral") from None
    try:
        return AESGCM(hkdf(z, epk + spk, CRED_INFO + prefix)).decrypt(
            ZERO_NONCE, sealed[44:], prefix + cred_context(installation_id, vault_uid, key_id))
    except Exception:
        raise Refused("auth_failed") from None


def p256_on_curve(pk: bytes) -> bool:
    if len(pk) != 65 or pk[0] != 4:
        return False
    try:
        ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), pk)
    except ValueError:
        return False
    return True


def check_holder(statement: dict, installation_id: str, suite: int, hpk: bytes, sig: bytes) -> None:
    """The holder proof's verifier: input checks in the header's order, then the signature over the rebuilt text."""
    if b32_uid_decode(installation_id) is None:
        raise Refused("bad_installation_id")
    if suite not in (1, 2):
        raise Refused("unsupported_suite")
    if not (strict_x25519(hpk) if suite == 1 else p256_on_curve(hpk)):
        raise Refused("bad_key")
    text = f"vhc-account-key-holder-v1\n{statement['public_id']}\n{statement['generation']}\n" \
           f"{fp_text(statement['fingerprint'])}\n{installation_id}\n{suite}\n{b64u(hpk)}"
    if not ed_verify(statement["ed25519"], text.encode(), sig):
        raise Refused("bad_signature")


def code_of(*parts: str) -> str:
    """A comparison code, written out again: SHA-256 of the lines, the first 8 bytes in four hex groups."""
    digest = hashlib.sha256("\n".join(parts).encode("utf-8")).digest()[:8]
    return "-".join(digest[i:i + 2].hex() for i in (0, 2, 4, 6))


def code_inputs_ok(kind: str, case: dict) -> bool:
    """What the code functions accept: a 26-symbol id, a canonical public id and a key of the right shape."""
    def b32_id(text: str) -> bool:  # 26 symbols of the alphabet; the padding bits aren't checked
        return len(text) == 26 and all(c in B32_ALPHABET for c in text)
    if kind == "request":
        return b32_id(case["request_id"])
    key = bytes.fromhex(case["temporary_public_key_hex"])
    if kind == "transfer":
        return uuid_bytes(case["public_id"]) is not None and (len(key) == 32 or (len(key) == 65 and key[0] == 4))
    return b32_id(case["vault_uid"]) and len(key) == 32


# --------------------------------------------------------------------------------------------------------------------
# The vectors
# --------------------------------------------------------------------------------------------------------------------

PUBLIC_ID = "5f0c3a3e-8d1b-4c2a-9e47-6b1d2f3a4c5e"
OTHER_PUBLIC_ID = "0b7e4d21-6a3c-4f8e-b1d2-93c4e5f60718"
SEED = {name: label_bytes(f"vhc-vector/account-key/{name}", 16) for name in ("gen1", "gen2", "gen3", "other")}
ISSUED_AT = "2026-11-14T12:00:00Z"


def flip(data: bytes, at: int, mask: int = 1) -> bytes:
    b = bytearray(data)
    b[at] ^= mask
    return bytes(b)


def replace_line(text: str, index: int, value: str) -> str:
    lines = text.split("\n")
    lines[index] = value
    return "\n".join(lines)


def chain_item(statement: str, signer: bytes, previous: bytes | None) -> dict:
    return {"statement": statement, "signature_hex": ed_sign(signer, statement.encode()).hex(),
            "previous_signature_hex": ed_sign(previous, statement.encode()).hex() if previous else None}


def build() -> dict:
    keys = {name: recovery_keys(seed) for name, seed in SEED.items()}

    def fp_of(name: str, generation: int, public_id: str = PUBLIC_ID) -> bytes:
        return fingerprint(public_id, generation, keys[name][1], keys[name][3])

    # ---- account key: a chain of three generations ----------------------------------------------------------------
    s1 = make_statement(SEED["gen1"], PUBLIC_ID, 1, None, "initial")
    s2 = make_statement(SEED["gen2"], PUBLIC_ID, 2, fp_of("gen1", 1), "routine")
    s3 = make_statement(SEED["gen3"], PUBLIC_ID, 3, fp_of("gen2", 2), "compromise")
    c1, c2, c3 = chain_item(s1, SEED["gen1"], None), chain_item(s2, SEED["gen2"], SEED["gen1"]), \
        chain_item(s3, SEED["gen3"], None)
    generations = []
    for name, item, gen, link in (("gen1", c1, 1, "initial"), ("gen2", c2, 2, "rotation"), ("gen3", c3, 3, "replacement")):
        fp = fp_of(name, gen)
        generations.append({"name": f"generation_{gen}_{link}", "seed_hex": SEED[name].hex(), "seed_text": seed_text(SEED[name]),
                            "x25519_pk_hex": keys[name][1].hex(), "ed25519_pk_hex": keys[name][3].hex(),
                            "fingerprint_hex": fp.hex(), "fingerprint_text": fp_text(fp), "link": link, **item})

    good_x = b64u(keys["gen1"][1])
    statement_negative = []

    def sneg(name: str, text: str, error: str, desc: str) -> None:
        statement_negative.append({"name": name, "description": desc, "statement": text, "error": error})

    sneg("trailing_newline", s1 + "\n", "bad_statement", "a newline after the reason")
    sneg("crlf", s1.replace("\n", "\r\n"), "bad_statement", "CRLF line endings")
    sneg("unsupported_version", replace_line(s1, 0, "vhc-account-key-v2"), "unsupported_version", "a later version")
    sneg("bad_magic", replace_line(s1, 0, "vhc-account-key"), "bad_statement", "not a statement")
    sneg("six_lines", "\n".join(s1.split("\n")[:6]), "bad_statement", "the reason line is missing")
    sneg("upper_case_public_id", replace_line(s1, 1, PUBLIC_ID.upper()), "bad_public_id", "a non-canonical UUID")
    sneg("unhyphenated_public_id", replace_line(s1, 1, PUBLIC_ID.replace("-", "")), "bad_public_id", "no hyphens")
    sneg("generation_zero", replace_line(s1, 2, "0"), "bad_generation", "generations start at 1")
    sneg("generation_leading_zero", replace_line(s1, 2, "01"), "bad_generation", "a leading zero")
    sneg("generation_too_large", replace_line(s1, 2, "4294967296"), "bad_generation", "above 2^32 - 1")
    sneg("generation_signed", replace_line(s1, 2, "+1"), "bad_generation", "a sign")
    sneg("base64url_padded", replace_line(s1, 3, good_x + "="), "bad_base64url", "padding")
    sneg("base64url_standard_alphabet", replace_line(s1, 3, "+" + good_x[1:]), "bad_base64url",
         "a symbol of the standard alphabet")
    last = good_x[-1]
    bumped = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
    sneg("base64url_trailing_bits", replace_line(s1, 3, good_x[:-1] + bumped[bumped.index(last) ^ 1]), "bad_base64url",
         "non-zero trailing bits: another spelling of the same key")
    sneg("key_too_short", replace_line(s1, 3, b64u(keys["gen1"][1][:31])), "bad_key", "a 31-byte key")
    sneg("x25519_low_order_zero", replace_line(s1, 3, b64u(bytes(32))), "bad_key", "u = 0, a low-order point")
    sneg("x25519_low_order_one", replace_line(s1, 3, b64u(bytes([1]) + bytes(31))), "bad_key", "u = 1, low order")
    sneg("x25519_non_canonical", replace_line(s1, 3, b64u((P25519 + 9).to_bytes(32, "little"))), "bad_key",
         "u = p + 9, a second spelling of the base point")
    sneg("ed25519_too_long", replace_line(s1, 4, b64u(keys["gen1"][3] + b"\0")), "bad_key", "a 33-byte key")
    sneg("previous_on_generation_1", replace_line(s1, 5, fp_text(fp_of("gen2", 2))), "bad_previous",
         "generation 1 names a previous fingerprint")
    sneg("previous_missing", replace_line(s2, 5, ""), "bad_previous", "generation 2 names none")
    sneg("previous_upper_case", replace_line(s2, 5, fp_text(fp_of("gen1", 1)).upper()), "bad_previous",
         "a non-canonical fingerprint")
    sneg("previous_no_separators", replace_line(s2, 5, fp_of("gen1", 1).hex()), "bad_previous", "no separators")
    sneg("reason_routine_on_generation_1", replace_line(s1, 6, "routine"), "bad_reason", "generation 1 is initial")
    sneg("reason_initial_on_generation_2", replace_line(s2, 6, "initial"), "bad_reason", "only generation 1 is")
    sneg("reason_unknown", replace_line(s2, 6, "Routine"), "bad_reason", "reasons are lower case")

    other_s1 = make_statement(SEED["gen1"], OTHER_PUBLIC_ID, 1, None, "initial")
    altered = replace_line(s1, 3, b64u(keys["other"][1]))
    s2_bad_prev = make_statement(SEED["gen2"], PUBLIC_ID, 2, fp_of("other", 1), "routine")
    chain_negative = [
        {"name": "empty", "description": "no statement", "chain": [], "error": "bad_statement", "index": 0},
        {"name": "another_account", "description": "a chain for another account", "chain": [chain_item(other_s1, SEED["gen1"], None)],
         "error": "account_mismatch", "index": 0},
        {"name": "altered_line", "description": "the X25519 line replaced after signing",
         "chain": [{**c1, "statement": altered}], "error": "bad_signature", "index": 0},
        {"name": "signed_by_another_key", "description": "a statement signed by a key it doesn't name",
         "chain": [chain_item(s1, SEED["other"], None)], "error": "bad_signature", "index": 0},
        {"name": "previous_signature_on_generation_1", "description": "generation 1 has no previous key",
         "chain": [chain_item(s1, SEED["gen1"], SEED["other"])], "error": "bad_previous_signature", "index": 0},
        {"name": "skipped_generation", "description": "generation 2 is missing", "chain": [c1, c3],
         "error": "generation_gap", "index": 1},
        {"name": "reordered", "description": "generation 2 first", "chain": [c2, c1], "error": "generation_gap",
         "index": 0},
        {"name": "repeated_generation", "description": "generation 1 twice", "chain": [c1, c1],
         "error": "generation_gap", "index": 1},
        {"name": "previous_fingerprint_mismatch", "description": "generation 2 names a fingerprint that isn't generation 1's",
         "chain": [c1, chain_item(s2_bad_prev, SEED["gen2"], SEED["gen1"])], "error": "previous_mismatch", "index": 1},
        {"name": "bad_previous_signature", "description": "generation 2's previous signature by a key that isn't generation 1's",
         "chain": [c1, chain_item(s2, SEED["gen2"], SEED["other"])], "error": "bad_previous_signature", "index": 1},
        {"name": "parse_error_in_chain", "description": "a trailing newline on generation 2",
         "chain": [c1, {**c2, "statement": s2 + "\n"}], "error": "bad_statement", "index": 1},
    ]

    # Another key under generation 2: what a cloud handing out a substitute would serve.
    s2_other = make_statement(SEED["other"], PUBLIC_ID, 2, fp_of("gen1", 1), "routine")
    c2_other = chain_item(s2_other, SEED["other"], None)
    follow_cases = [
        {"name": "rotation_followed", "pin": {"generation": 1, "fingerprint_hex": fp_of("gen1", 1).hex()},
         "chain": [c1, c2], "expect": {"accepted": 2, "newest": 2}},
        {"name": "replacement_waits", "pin": {"generation": 1, "fingerprint_hex": fp_of("gen1", 1).hex()},
         "chain": [c1, c2, c3], "expect": {"accepted": 2, "newest": 3}},
        {"name": "unchanged", "pin": {"generation": 2, "fingerprint_hex": fp_of("gen2", 2).hex()},
         "chain": [c1, c2], "expect": {"accepted": 2, "newest": 2}},
        {"name": "confirmed_replacement", "pin": {"generation": 3, "fingerprint_hex": fp_of("gen3", 3).hex()},
         "chain": [c1, c2, c3], "expect": {"accepted": 3, "newest": 3}},
        {"name": "unsigned_substitute_waits", "pin": {"generation": 1, "fingerprint_hex": fp_of("gen1", 1).hex()},
         "chain": [c1, c2_other], "expect": {"accepted": 1, "newest": 2}},
        {"name": "rollback", "pin": {"generation": 2, "fingerprint_hex": fp_of("gen2", 2).hex()},
         "chain": [c1], "expect": {"error": "rollback"}},
        {"name": "substitute_under_pinned_generation", "pin": {"generation": 2, "fingerprint_hex": fp_of("gen2", 2).hex()},
         "chain": [c1, c2_other], "expect": {"error": "pin_mismatch"}},
    ]

    fingerprint_text = {
        "canonical": generations[0]["fingerprint_text"],
        "lenient_accepted": [generations[0]["fingerprint_text"].upper(), generations[0]["fingerprint_hex"],
                             generations[0]["fingerprint_text"].replace("-", " ")],
        "refused": [generations[0]["fingerprint_text"][:-1], generations[0]["fingerprint_text"] + "0",
                    generations[0]["fingerprint_text"].replace("a", "g", 1) if "a" in generations[0]["fingerprint_text"]
                    else "g" + generations[0]["fingerprint_text"][1:]],
    }

    # ---- recovery policy, signed by generation 2 -------------------------------------------------------------------
    kit_pk = x25519_pub(label_bytes("vhc-vector/policy/kit", 32))
    op_pk = x25519_pub(label_bytes("vhc-vector/policy/1password", 32))
    person_pk = x25519_pub(label_bytes("vhc-vector/policy/person", 32))
    p1 = make_policy(PUBLIC_ID, 1, 2, ISSUED_AT, [(kit_pk, "Recovery kit 2026-11"), (op_pk, "1Password: Familie Müller")])
    p2 = make_policy(PUBLIC_ID, 2, 2, "2026-11-15T08:30:00Z", [(kit_pk, "Recovery kit 2026-11"), (op_pk, "1Password: Familie Müller"),
                                                         (person_pk, "Ingrid ✓")])
    p3 = make_policy(PUBLIC_ID, 3, 2, "2026-12-01T00:00:00Z", [])
    policy_positive = []
    for name, text in (("two_recipients", p1), ("three_recipients", p2), ("no_recipients", p3)):
        policy_positive.append({"name": name, "policy": text, "signature_hex": ed_sign(SEED["gen2"], text.encode()).hex(),
                                "pinned_generation": 2, "hash_hex": sha256(text.encode()).hex()})

    def pneg(name: str, text: str, error: str, desc: str, *, signer: str = "gen2", pinned: int = 2) -> dict:
        return {"name": name, "description": desc, "policy": text,
                "signature_hex": ed_sign(SEED[signer], text.encode()).hex(), "pinned_generation": pinned, "error": error}

    lines1 = p1.split("\n")
    rec = lines1[5].split(" ")
    many = [(x25519_pub(label_bytes(f"vhc-vector/policy/many/{i}", 32)), f"r{i}") for i in range(65)]
    policy_negative = [
        pneg("trailing_newline", p3 + "\n", "bad_recipient", "a newline after the last line"),
        pneg("unsupported_version", replace_line(p1, 0, "vhc-recovery-policy-v2"), "unsupported_version", "a later version"),
        pneg("bad_magic", replace_line(p1, 0, "vhc-recovery-policy"), "bad_policy", "not a policy"),
        pneg("too_short", "\n".join(lines1[:4]), "bad_policy", "issued_at is missing"),
        pneg("bad_public_id", replace_line(p1, 1, PUBLIC_ID.upper()), "bad_public_id", "a non-canonical UUID"),
        pneg("sequence_zero", replace_line(p1, 2, "0"), "bad_sequence", "sequences start at 1"),
        pneg("sequence_leading_zero", replace_line(p1, 2, "01"), "bad_sequence", "a leading zero"),
        pneg("generation_zero", replace_line(p1, 3, "0"), "bad_generation", "generations start at 1"),
        pneg("issued_at_impossible_day", replace_line(p1, 4, "2026-02-29T00:00:00Z"), "bad_issued_at", "2026 isn't a leap year"),
        pneg("issued_at_offset", replace_line(p1, 4, "2026-11-14T12:00:00+00:00"), "bad_issued_at", "UTC is written Z"),
        pneg("issued_at_fraction", replace_line(p1, 4, "2026-11-14T12:00:00.5Z"), "bad_issued_at", "no fractions"),
        pneg("too_many_recipients", make_policy(PUBLIC_ID, 1, 2, ISSUED_AT, many), "too_many_recipients", "65 recipients"),
        pneg("double_space", replace_line(p1, 5, lines1[5].replace(" ", "  ", 1)), "bad_recipient", "two spaces between fields"),
        pneg("five_fields", replace_line(p1, 5, " ".join(rec[:5])), "bad_recipient", "the scope is missing"),
        pneg("recipient_id_short", replace_line(p1, 5, " ".join([b64u(sha256(kit_pk)[:31])] + rec[1:])), "bad_recipient",
             "a 31-byte recipient id"),
        pneg("key_padded", replace_line(p1, 5, " ".join([rec[0], rec[1] + "="] + rec[2:])), "bad_base64url", "padding"),
        pneg("key_low_order", replace_line(p1, 5, " ".join([b64u(sha256(bytes(32))), b64u(bytes(32))] + rec[2:])), "bad_key",
             "u = 0, a low-order point"),
        pneg("recipient_id_mismatch", replace_line(p1, 5, " ".join([b64u(sha256(person_pk))] + rec[1:])),
             "recipient_id_mismatch", "a recipient id that isn't SHA-256 of the key"),
        pneg("suite_2", replace_line(p1, 5, " ".join(rec[:2] + ["2"] + rec[3:])), "unsupported_suite", "P-256 isn't a policy suite"),
        pneg("class_custodian", replace_line(p1, 5, " ".join(rec[:3] + ["custodian"] + rec[4:])), "unsupported_class",
             "only customer recipients"),
        pneg("label_empty", replace_line(p1, 5, " ".join(rec[:4] + [""] + rec[5:])), "bad_label", "an empty label"),
        pneg("label_control", replace_line(p1, 5, " ".join(rec[:4] + [b64u(b"kit\nnext")] + rec[5:])), "bad_label",
             "a newline in the label"),
        pneg("label_invalid_utf8", replace_line(p1, 5, " ".join(rec[:4] + [b64u(b"kit \xc3\x28")] + rec[5:])), "bad_label",
             "not UTF-8"),
        pneg("label_overlong_utf8", replace_line(p1, 5, " ".join(rec[:4] + [b64u(b"kit \xc0\xaf")] + rec[5:])), "bad_label",
             "an overlong form"),
        pneg("label_too_long", replace_line(p1, 5, " ".join(rec[:4] + [b64u(b"k" * 129)] + rec[5:])), "bad_label", "129 bytes"),
        pneg("scope_vaults", replace_line(p1, 5, " ".join(rec[:5] + ["vaults"])), "unsupported_scope",
             "a list of vaults is reserved"),
        pneg("unsorted", make_policy(PUBLIC_ID, 1, 2, ISSUED_AT, sorted([(kit_pk, "a"), (op_pk, "b")], key=lambda r: sha256(r[0]),
                                                                    reverse=True), keep_order=True),
             "unsorted_recipients", "recipients not in recipient_id order"),
        pneg("duplicate", make_policy(PUBLIC_ID, 1, 2, ISSUED_AT, [(kit_pk, "a"), (kit_pk, "b")]), "unsorted_recipients",
             "one key listed twice"),
        pneg("another_account", make_policy(OTHER_PUBLIC_ID, 1, 2, ISSUED_AT, [(kit_pk, "kit")]), "account_mismatch",
             "a policy for another account"),
        pneg("older_generation", make_policy(PUBLIC_ID, 1, 1, ISSUED_AT, [(kit_pk, "kit")]), "generation_mismatch",
             "signed by generation 1 while generation 2 is pinned", signer="gen1"),
        pneg("newer_generation_unpinned", make_policy(PUBLIC_ID, 1, 3, ISSUED_AT, [(kit_pk, "kit")]), "generation_mismatch",
             "generation 3 is not pinned", signer="gen3"),
        pneg("signed_by_previous_generation", p1, "bad_signature", "names generation 2, signed by generation 1",
             signer="gen1"),
        {"name": "altered_after_signing", "description": "issued_at changed after signing",
         "policy": replace_line(p1, 4, "2026-11-14T12:00:01Z"), "signature_hex": policy_positive[0]["signature_hex"],
         "pinned_generation": 2, "error": "bad_signature"},
        pneg("account_key_listed", make_policy(PUBLIC_ID, 1, 2, ISSUED_AT, [(keys["gen2"][1], "account key")]),
             "account_key_listed", "the account key is a recipient through the pin, not the policy"),
    ]

    h = {e["name"]: e["hash_hex"] for e in policy_positive}
    sequence_cases = [
        {"name": "first_policy", "floor": {"sequence": 0, "hash_hex": "00" * 32}, "policy": "two_recipients", "verdict": "newer"},
        {"name": "same_policy", "floor": {"sequence": 1, "hash_hex": h["two_recipients"]}, "policy": "two_recipients",
         "verdict": "unchanged"},
        {"name": "next_policy", "floor": {"sequence": 1, "hash_hex": h["two_recipients"]}, "policy": "three_recipients",
         "verdict": "newer"},
        {"name": "skipped_ahead", "floor": {"sequence": 1, "hash_hex": h["two_recipients"]}, "policy": "no_recipients",
         "verdict": "newer"},
        {"name": "rollback", "floor": {"sequence": 2, "hash_hex": h["three_recipients"]}, "policy": "two_recipients",
         "verdict": "older"},
        {"name": "equivocation", "floor": {"sequence": 1, "hash_hex": h["three_recipients"]}, "policy": "two_recipients",
         "verdict": "conflict"},
    ]
    next_sequence = [{"stored": 0, "candidate": 1, "next": True}, {"stored": 1, "candidate": 2, "next": True},
                     {"stored": 1, "candidate": 3, "next": False}, {"stored": 2, "candidate": 2, "next": False},
                     {"stored": 2, "candidate": 1, "next": False}, {"stored": 4294967295, "candidate": 0, "next": False}]

    # ---- KAK1: generation 2's seed to a holder ---------------------------------------------------------------------
    fp2 = fp_of("gen2", 2)
    holders = {1: label_bytes("vhc-vector/kak1/holder/x25519", 32), 2: label_bytes("vhc-vector/kak1/holder/p256", 32)}
    ephemerals = {1: label_bytes("vhc-vector/kak1/esk/x25519", 32), 2: label_bytes("vhc-vector/kak1/esk/p256", 32)}
    kak1_positive, envs = [], {}
    for suite in (1, 2):
        hpk = pub_of(suite, holders[suite])
        env = kak1_wrap(SEED["gen2"], PUBLIC_ID, 2, fp2, suite, hpk, ephemerals[suite])
        envs[suite] = env
        kak1_positive.append({"name": f"suite_{suite}", "suite": suite, "statement": s2, "seed_hex": SEED["gen2"].hex(),
                              "holder_sk_hex": holders[suite].hex(), "holder_pk_hex": hpk.hex(),
                              "ephemeral_sk_hex": ephemerals[suite].hex(), "envelope_hex": env.hex(),
                              "recipient_id_hex": sha256(hpk).hex()})
    e1, e2 = envs[1], envs[2]
    wrong_seed = kak1_wrap(SEED["gen1"], PUBLIC_ID, 2, fp2, 1, pub_of(1, holders[1]), ephemerals[1])
    off_curve = bytearray(e2)
    off_curve[82 + 64] ^= 1  # last byte of the P-256 epk: off the curve

    def kneg(name: str, env: bytes, error: str, desc: str, *, suite: int = 1, statement: str = s2,
             holder: bytes | None = None) -> dict:
        return {"name": name, "description": desc, "envelope_hex": env.hex(), "suite_expected": suite,
                "statement": statement, "holder_sk_hex": (holder or holders[suite]).hex(), "error": error}

    kak1_negative = [
        kneg("bad_magic", flip(e1, 3), "bad_magic", "not a KAK1 envelope"),
        kneg("kev1_magic", bytes([0x89, 0x56, 0x48, 0x4B]) + e1[4:], "bad_magic", "a KEV1 magic"),
        kneg("too_short", e1[:81], "bad_magic", "shorter than the fixed prefix"),
        kneg("unsupported_version", flip(e1, 9, 3), "unsupported_version", "version 2"),
        kneg("unknown_suite", flip(e1, 11, 2), "unsupported_suite", "suite 3"),
        kneg("suite_not_expected", e2, "unsupported_suite", "a P-256 envelope read as X25519", suite=1,
             holder=holders[1]),
        kneg("another_account", flip(e1, 16), "account_mismatch", "public id changed"),
        kneg("older_generation_expected", e1, "key_mismatch", "the reader expects generation 1", statement=s1),
        kneg("fingerprint_changed", flip(e1, 32), "key_mismatch", "fingerprint changed"),
        kneg("wrong_holder", e1, "recipient_mismatch", "another holder key",
             holder=label_bytes("vhc-vector/kak1/holder/other", 32)),
        kneg("truncated", e1[:-1], "bad_length", "one byte short"),
        kneg("extended", e1 + b"\0", "bad_length", "one byte more"),
        kneg("epk_low_order", e1[:82] + bytes(32) + e1[114:], "bad_ephemeral", "an all-zero X25519 epk"),
        kneg("epk_off_curve", bytes(off_curve), "bad_ephemeral", "a P-256 epk off the curve", suite=2),
        kneg("tag_flipped", flip(e1, len(e1) - 1), "wrap_auth_failed", "the tag"),
        kneg("prefix_tampered", flip(e1, 14), "key_mismatch", "generation changed"),
        kneg("wrong_seed", wrong_seed, "seed_mismatch", "an authentic envelope of a seed that isn't generation 2's"),
    ]

    # ---- vault labels, sealed to generation 2 ----------------------------------------------------------------------
    vault_uid = label_bytes("vhc-vector/vault-label/vault", 16)
    xsk2 = keys["gen2"][0]
    names = [("ascii", "Family photos"), ("utf8", "Fotos – Familie 📷"), ("max_length", "v" * 126 + "é")]
    label_positive, sealed_labels = [], {}
    for name, value in names:
        esk = label_bytes(f"vhc-vector/vault-label/esk/{name}", 32)
        sealed = label_seal(value.encode(), PUBLIC_ID, 2, fp2, vault_uid, keys["gen2"][1], esk)
        sealed_labels[name] = sealed
        label_positive.append({"name": name, "label": value, "label_bytes": len(value.encode()), "statement": s2,
                               "vault_uid_hex": vault_uid.hex(), "account_x25519_sk_hex": xsk2.hex(),
                               "ephemeral_sk_hex": esk.hex(), "sealed_hex": sealed.hex()})
    la = sealed_labels["ascii"]
    lesk = label_bytes("vhc-vector/vault-label/esk/negative", 32)

    def lneg(name: str, sealed: bytes, error: str, desc: str, *, statement: str = s2, vault: bytes = vault_uid,
             sk: bytes = xsk2) -> dict:
        return {"name": name, "description": desc, "sealed_hex": sealed.hex(), "statement": statement,
                "vault_uid_hex": vault.hex(), "account_x25519_sk_hex": sk.hex(), "error": error}

    label_negative = [
        lneg("bad_magic", flip(la, 3), "bad_magic", "not a sealed label"),
        lneg("too_short", la[:95], "bad_magic", "shorter than the prefix"),
        lneg("unsupported_version", flip(la, 9, 3), "unsupported_version", "version 2"),
        lneg("suite_2", flip(la, 11, 3), "unsupported_suite", "P-256 isn't a label suite"),
        lneg("another_account", flip(la, 16), "account_mismatch", "public id changed"),
        lneg("another_vault", la, "vault_mismatch", "opened for another vault", vault=flip(vault_uid, 0)),
        lneg("older_generation_expected", la, "key_mismatch", "the reader expects generation 1", statement=s1,
             sk=keys["gen1"][0]),
        lneg("truncated", la[:-1], "bad_length", "one byte short"),
        lneg("extended", la + b"\0", "bad_length", "one byte more"),
        lneg("epk_low_order", la[:64] + bytes(32) + la[96:], "bad_ephemeral", "an all-zero epk"),
        lneg("tag_flipped", flip(la, len(la) - 1), "auth_failed", "the tag"),
        lneg("wrong_key", la, "auth_failed", "opened with another X25519 key", sk=keys["gen1"][0]),
        lneg("empty", label_seal(b"", PUBLIC_ID, 2, fp2, vault_uid, keys["gen2"][1], lesk, padded=bytes(128)),
             "bad_label", "an empty name"),
        lneg("bytes_after_padding", label_seal(b"", PUBLIC_ID, 2, fp2, vault_uid, keys["gen2"][1], lesk,
                                               padded=b"name" + bytes(123) + b"x"), "bad_label",
             "a non-zero byte after the padding starts"),
        lneg("invalid_utf8", label_seal(b"", PUBLIC_ID, 2, fp2, vault_uid, keys["gen2"][1], lesk,
                                        padded=b"bad \xff" + bytes(123)), "bad_label", "not UTF-8"),
        lneg("control_character", label_seal(b"", PUBLIC_ID, 2, fp2, vault_uid, keys["gen2"][1], lesk,
                                             padded=b"tab\there" + bytes(120)), "bad_label", "a tab"),
    ]

    # ---- the sealed storage credential -----------------------------------------------------------------------------
    installation_id = b32_uid(label_bytes("vhc-vector/credential/installation", 16))
    cred_vault = label_bytes("vhc-vector/credential/vault", 16)
    key_id = "005f3c2a9b1d4e60000000007"
    secret = b"K005" + label_bytes("vhc-vector/credential/secret", 20).hex()[:27].encode()
    ssk = label_bytes("vhc-vector/credential/server", 32)
    cesk = label_bytes("vhc-vector/credential/esk", 32)
    sealed = cred_seal(secret, installation_id, cred_vault, key_id, x25519_pub(ssk), cesk)
    context = {"installation_id": installation_id, "vault_uid_hex": cred_vault.hex(), "key_id": key_id}
    cred_positive = [{"name": "b2_application_key", "secret": secret.decode(), "context": context,
                      "server_sk_hex": ssk.hex(), "server_pk_hex": x25519_pub(ssk).hex(),
                      "ephemeral_sk_hex": cesk.hex(), "sealed_hex": sealed.hex(), "sealed_base64url": b64u(sealed)}]

    def cpos(name: str, secret_text: bytes, key: str, label: str) -> dict:
        esk = label_bytes(f"vhc-vector/credential/esk/{label}", 32)
        data = cred_seal(secret_text, installation_id, cred_vault, key, x25519_pub(ssk), esk)
        return {"name": name, "secret": secret_text.decode(), "context": {**context, "key_id": key},
                "server_sk_hex": ssk.hex(), "server_pk_hex": x25519_pub(ssk).hex(), "ephemeral_sk_hex": esk.hex(),
                "sealed_hex": data.hex(), "sealed_base64url": b64u(data)}

    # An S3-style access key (s3dev: an IAM access key id and its 40-character secret), and both bounds at once: a
    # 1024-byte secret under a 128-character key id that uses every printable character class.
    s3_secret = b64u(label_bytes("vhc-vector/credential/s3-secret", 30)).encode()
    s3_key_id = "AKIA" + label_bytes("vhc-vector/credential/s3-key-id", 8).hex().upper()
    printable = "".join(chr(c) for c in range(0x21, 0x7F))
    max_key_id = (printable * 2)[:128]
    max_secret = label_bytes("vhc-vector/credential/max-secret", 512).hex().encode()
    cred_positive += [cpos("s3_access_key", s3_secret, s3_key_id, "s3"),
                      cpos("largest", max_secret, max_key_id, "largest")]

    def cneg(name: str, data: bytes, error: str, desc: str, *, sk: bytes = ssk, **ctx) -> dict:
        return {"name": name, "description": desc, "sealed_hex": data.hex(), "server_sk_hex": sk.hex(),
                "context": {**context, **ctx}, "error": error}

    cred_negative = [
        cneg("bad_magic", flip(sealed, 3), "bad_magic", "not a sealed credential"),
        cneg("too_short", sealed[:43], "bad_magic", "shorter than the prefix"),
        cneg("unsupported_version", flip(sealed, 9, 3), "unsupported_version", "version 2"),
        cneg("suite_2", flip(sealed, 11, 3), "unsupported_suite", "suite 2"),
        cneg("empty_secret", sealed[:44] + sealed[-16:], "bad_length", "no secret byte"),
        cneg("too_long", sealed[:44] + bytes(1025 + 16), "bad_length", "a secret above 1024 bytes"),
        cneg("epk_low_order", sealed[:12] + bytes(32) + sealed[44:], "bad_ephemeral", "an all-zero epk"),
        cneg("tag_flipped", flip(sealed, len(sealed) - 1), "auth_failed", "the tag"),
        cneg("another_installation", sealed, "auth_failed", "opened by another installation",
             installation_id=b32_uid(label_bytes("vhc-vector/credential/other-installation", 16))),
        cneg("another_vault", sealed, "auth_failed", "opened for another vault", vault_uid_hex=flip(cred_vault, 0).hex()),
        cneg("another_key_id", sealed, "auth_failed", "opened under another key id", key_id=key_id[:-1] + "8"),
        cneg("another_one_time_key", sealed, "auth_failed", "opened with a one-time key it wasn't sealed to",
             sk=label_bytes("vhc-vector/credential/other-server", 32)),
        cneg("truncated_tag", sealed[:-1], "auth_failed", "the tag's last byte missing"),
    ]

    # ---- the account public id's 16 bytes ----------------------------------------------------------------------------
    cloud_public_id = "0f8fad5b-d9cb-469f-a165-70867728950e"
    public_id_section = {
        "accepted": [{"text": t, "bytes_hex": uuid_bytes(t).hex()} for t in (PUBLIC_ID, OTHER_PUBLIC_ID, cloud_public_id)],
        "refused": [PUBLIC_ID.upper(), PUBLIC_ID.replace("-", ""), "{" + PUBLIC_ID + "}", "urn:uuid:" + PUBLIC_ID,
                    PUBLIC_ID[:-1], PUBLIC_ID + "0", PUBLIC_ID + "\n", PUBLIC_ID[:8] + PUBLIC_ID[9] + "-" + PUBLIC_ID[10:],
                    "g" + PUBLIC_ID[1:], ""],
    }

    # ---- the holder proof, by generation 2 -------------------------------------------------------------------------
    st2 = {"public_id": PUBLIC_ID, "generation": 2, "fingerprint": fp2}
    installation = b32_uid(label_bytes("vhc-vector/holder/installation", 16))
    holder_x = x25519_pub(label_bytes("vhc-vector/holder/x25519", 32))
    holder_p = p256_pub(label_bytes("vhc-vector/holder/p256", 32))

    def proof(seed_name: str, public_id: str, generation: int, fp: bytes, inst: str, suite: int, hpk: bytes) -> bytes:
        return ed_sign(SEED[seed_name] if seed_name in SEED else bytes.fromhex(seed_name),
                       holder_message(public_id, generation, fp, inst, suite, hpk).encode())

    cloud_seed = bytes(range(1, 17))
    cloud_statement = make_statement(cloud_seed, cloud_public_id, 1, None, "initial")
    _, cxpk, _, cepk = recovery_keys(cloud_seed)
    cloud_fp = fingerprint(cloud_public_id, 1, cxpk, cepk)
    cloud_holder = bytes(range(0x20, 0x40))
    holder_positive = []
    for name, desc, statement, seed, pid, gen, fp, inst, suite, hpk in (
            ("x25519_holder", "a holder key in software (X25519)", s2, SEED["gen2"], PUBLIC_ID, 2, fp2, installation, 1,
             holder_x),
            ("p256_holder", "a Secure Enclave holder key (P-256)", s2, SEED["gen2"], PUBLIC_ID, 2, fp2, installation, 2,
             holder_p),
            ("cloud_unit_test", "vaulthalla-cloud tests/unit/keys/test_holder_proof.cpp: seed 0x01..0x10, holder key "
             "0x20..0x3f", cloud_statement, cloud_seed, cloud_public_id, 1, cloud_fp, "0123456789abcdefghjkmnpqr0", 1,
             cloud_holder)):
        message = holder_message(pid, gen, fp, inst, suite, hpk)
        holder_positive.append({"name": name, "description": desc, "statement": statement, "seed_hex": seed.hex(),
                                "installation_id": inst, "suite": suite, "holder_pk_hex": hpk.hex(), "message": message,
                                "signature_hex": ed_sign(seed, message.encode()).hex()})
    good_proof = proof("gen2", PUBLIC_ID, 2, fp2, installation, 1, holder_x)
    last_symbol = B32_ALPHABET[B32_ALPHABET.index(installation[-1]) | 1]

    def hneg(name: str, error: str, desc: str, *, inst: str = installation, suite: int = 1, hpk: bytes = holder_x,
             sig: bytes = good_proof, statement: str = s2) -> dict:
        return {"name": name, "description": desc, "statement": statement, "installation_id": inst, "suite": suite,
                "holder_pk_hex": hpk.hex(), "signature_hex": sig.hex(), "error": error}

    off_curve_holder = flip(holder_p, 64)
    holder_negative = [
        hneg("installation_upper_case", "bad_installation_id", "an upper-case installation id", inst=installation.upper()),
        hneg("installation_short", "bad_installation_id", "25 symbols", inst=installation[:-1]),
        hneg("installation_padding_bits", "bad_installation_id", "non-zero padding bits: another spelling",
             inst=installation[:-1] + last_symbol),
        hneg("installation_symbol_i", "bad_installation_id", "'i' isn't a base32 symbol", inst="i" + installation[1:]),
        hneg("suite_0", "unsupported_suite", "suite 0", suite=0),
        hneg("suite_3", "unsupported_suite", "suite 3", suite=3),
        hneg("x25519_short", "bad_key", "a 31-byte X25519 key", hpk=holder_x[:31]),
        hneg("x25519_zero", "bad_key", "u = 0, a low-order point", hpk=bytes(32)),
        hneg("x25519_low_order_one", "bad_key", "u = 1, low order (the cloud's registration accepts it today)",
             hpk=bytes([1]) + bytes(31)),
        hneg("x25519_non_canonical", "bad_key", "u = p + 9, a second spelling of the base point",
             hpk=(P25519 + 9).to_bytes(32, "little")),
        hneg("x25519_key_as_p256", "bad_key", "a 32-byte key under suite 2", suite=2),
        hneg("p256_compressed", "bad_key", "a compressed point", suite=2, hpk=bytes([2 + (holder_p[64] & 1)]) + holder_p[1:33]),
        hneg("p256_without_prefix", "bad_key", "65 bytes without the 0x04 prefix", suite=2, hpk=bytes([5]) + holder_p[1:]),
        hneg("p256_off_curve", "bad_key", "a point off the curve (the cloud's registration accepts it today)", suite=2,
             hpk=off_curve_holder),
        hneg("another_installation", "bad_signature", "the proof of another installation",
             inst=b32_uid(label_bytes("vhc-vector/holder/other-installation", 16))),
        hneg("another_holder_key", "bad_signature", "the proof of another key",
             hpk=x25519_pub(label_bytes("vhc-vector/holder/other-x25519", 32))),
        hneg("another_suite", "bad_signature", "an X25519 key's proof presented for a P-256 key", suite=2, hpk=holder_p),
        hneg("signed_by_another_key", "bad_signature", "signed by a key that isn't the account's",
             sig=proof("other", PUBLIC_ID, 2, fp2, installation, 1, holder_x)),
        hneg("signed_by_previous_generation", "bad_signature", "generation 2's text signed by generation 1",
             sig=proof("gen1", PUBLIC_ID, 2, fp2, installation, 1, holder_x)),
        hneg("proof_of_previous_generation", "bad_signature", "generation 1's proof checked against generation 2",
             sig=proof("gen1", PUBLIC_ID, 1, fp_of("gen1", 1), installation, 1, holder_x)),
        hneg("statement_signature", "bad_signature", "the statement's own signature isn't a holder proof",
             sig=ed_sign(SEED["gen2"], s2.encode())),
        hneg("tampered", "bad_signature", "one bit of the signature", sig=flip(good_proof, 10)),
    ]

    # ---- comparison codes -------------------------------------------------------------------------------------------
    request_id = "0123456789abcdefghjkmnpqrs"
    key_01 = bytes(range(1, 33))
    requests = [("cloud_design_vector", request_id, '{"generation":1}'),
                ("empty_payload", b32_uid(label_bytes("vhc-vector/codes/request", 16)), ""),
                ("utf8_payload", b32_uid(label_bytes("vhc-vector/codes/request", 16)),
                 '{"label":"1Password: Familie Müller ✓","sequence":2}')]
    transfers = [("cloud_design_vector", cloud_public_id, key_01),
                 ("x25519", PUBLIC_ID, x25519_pub(label_bytes("vhc-vector/codes/transfer/x25519", 32))),
                 ("p256", PUBLIC_ID, p256_pub(label_bytes("vhc-vector/codes/transfer/p256", 32)))]
    # The cloud's design vectors use the id 0123456789abcdefghjkmnpqrs, whose last symbol leaves the padding bits
    # non-zero (not a canonical uid); the codes don't check padding, so they reproduce.
    restores = [("cloud_design_vector", request_id, key_01),
                ("x25519", b32_uid(label_bytes("vhc-vector/codes/restore/vault", 16)),
                 x25519_pub(label_bytes("vhc-vector/codes/restore/x25519", 32)))]
    codes = {
        "request": [{"name": n, "request_id": i, "payload": p, "code": request_code(i, p)} for n, i, p in requests],
        "transfer": [{"name": n, "public_id": i, "temporary_public_key_hex": k.hex(), "code": transfer_code(i, k)}
                     for n, i, k in transfers],
        "restore": [{"name": n, "vault_uid": u, "temporary_public_key_hex": k.hex(), "code": restore_code(u, k)}
                    for n, u, k in restores],
        "refused": [
            {"name": "request_id_upper_case", "kind": "request", "request_id": request_id.upper(), "payload": "{}"},
            {"name": "request_id_short", "kind": "request", "request_id": request_id[:-1], "payload": "{}"},
            {"name": "request_id_symbol_u", "kind": "request", "request_id": request_id[:-1] + "u", "payload": "{}"},
            {"name": "request_id_uuid", "kind": "request", "request_id": cloud_public_id, "payload": "{}"},
            {"name": "transfer_public_id_upper_case", "kind": "transfer", "public_id": cloud_public_id.upper(),
             "temporary_public_key_hex": key_01.hex()},
            {"name": "transfer_key_short", "kind": "transfer", "public_id": cloud_public_id,
             "temporary_public_key_hex": key_01[:31].hex()},
            {"name": "transfer_key_compressed", "kind": "transfer", "public_id": cloud_public_id,
             "temporary_public_key_hex": (bytes([2]) + key_01).hex()},
            {"name": "transfer_key_without_prefix", "kind": "transfer", "public_id": cloud_public_id,
             "temporary_public_key_hex": (bytes([5]) + key_01 + key_01).hex()},
            {"name": "restore_vault_uid_upper_case", "kind": "restore", "vault_uid": request_id.upper(),
             "temporary_public_key_hex": key_01.hex()},
            {"name": "restore_key_p256", "kind": "restore", "vault_uid": request_id,
             "temporary_public_key_hex": transfers[2][2].hex()},
        ],
    }
    # The cloud's own vectors (vaulthalla-cloud docs/design/key-manager.md and recovery-restore.md).
    assert codes["request"][0]["code"] == "4c0c-4ab7-e42c-29ef"
    assert codes["transfer"][0]["code"] == "a50d-b256-d985-6e9e"
    assert codes["restore"][0]["code"] == "6adc-ef02-f4a4-4fd0"

    return {
        "schema": SCHEMA,
        "generated_by": "vectors/vhc_vectors.py",
        "conventions": {
            "hex": "lower case",
            "integers": "big-endian",
            "material": "seeds, keys and ephemeral keys are the first n bytes of SHA-256 chained over a label "
                        "('vhc-vector/...'); production draws them from the CSPRNG",
            "public_id": PUBLIC_ID,
            "errors": "a negative vector names the first check that fails, in the order of the format's header",
        },
        "account_key": {"public_id": PUBLIC_ID, "generations": generations, "statement_negative": statement_negative,
                        "chain_negative": chain_negative, "follow": follow_cases, "fingerprint_text": fingerprint_text},
        "recovery_policy": {"positive": policy_positive, "negative": policy_negative, "sequence": sequence_cases,
                            "next_sequence": next_sequence},
        "kak1": {"positive": kak1_positive, "negative": kak1_negative},
        "vault_label": {"positive": label_positive, "negative": label_negative},
        "storage_credential": {"positive": cred_positive, "negative": cred_negative},
        "public_id": public_id_section,
        "holder_proof": {"positive": holder_positive, "negative": holder_negative},
        "codes": codes,
    }


# --------------------------------------------------------------------------------------------------------------------
# --check: verify every vector with the reader paths only
# --------------------------------------------------------------------------------------------------------------------


def verify(doc: dict) -> list[str]:
    failures: list[str] = []

    def check(cond: bool, what: str) -> None:
        if not cond:
            failures.append(what)

    def refused(fn, code: str, what: str, index: int | None = None) -> None:
        try:
            fn()
            failures.append(f"{what}: accepted")
        except Refused as e:
            check(e.code == code, f"{what}: {e.code} instead of {code}")
            if index is not None:
                check(e.index == index, f"{what}: index {e.index} instead of {index}")

    # The seed derivation agrees with vectors.json (KEV1 and the recovery seed, vaulthalla-server's vectors).
    try:
        upstream = json.loads((HERE / "vectors.json").read_text())
        for s in upstream["recovery_seed"]["positive"]:
            xsk, xpk, eseed, epk = recovery_keys(bytes.fromhex(s["seed_hex"]))
            check(xpk.hex() == s["x25519_pk_hex"] and epk.hex() == s["ed25519_pk_hex"],
                  f"recovery seed derivation differs from vectors.json for {s['seed_text']}")
            check(seed_text(bytes.fromhex(s["seed_hex"])) == s["seed_text"], "seed text differs from vectors.json")
    except FileNotFoundError:
        failures.append("vectors.json is missing")

    ak = doc["account_key"]
    public_id = ak["public_id"]
    items = [{k: g[k] for k in ("statement", "signature_hex", "previous_signature_hex")} for g in ak["generations"]]
    chain = verify_chain(items, public_id)
    statements = {}
    for g, v in zip(ak["generations"], chain):
        statements[v["generation"]] = v
        check(v["fingerprint"].hex() == g["fingerprint_hex"], f"{g['name']}: fingerprint")
        check(fp_text(v["fingerprint"]) == g["fingerprint_text"], f"{g['name']}: fingerprint text")
        check(v["link"] == g["link"], f"{g['name']}: link")
        _, xpk, _, edpk = recovery_keys(bytes.fromhex(g["seed_hex"]))
        check(xpk == v["x25519"] and edpk == v["ed25519"], f"{g['name']}: seed doesn't derive the statement's keys")
    for n in ak["statement_negative"]:
        refused(lambda n=n: parse_statement(n["statement"]), n["error"], f"statement {n['name']}")
    for n in ak["chain_negative"]:
        refused(lambda n=n: verify_chain(n["chain"], public_id), n["error"], f"chain {n['name']}", n["index"])
    for f in ak["follow"]:
        def run(f=f):
            return follow(f["pin"]["generation"], bytes.fromhex(f["pin"]["fingerprint_hex"]),
                          verify_chain(f["chain"], public_id))
        if "error" in f["expect"]:
            refused(run, f["expect"]["error"], f"follow {f['name']}")
        else:
            check(run() == f["expect"], f"follow {f['name']}")

    rp = doc["recovery_policy"]
    verified = {}
    for p in rp["positive"]:
        v = verify_policy(p["policy"], bytes.fromhex(p["signature_hex"]), statements[p["pinned_generation"]])
        verified[p["name"]] = v
        check(v["hash"].hex() == p["hash_hex"], f"policy {p['name']}: hash")
        check(make_policy(v["public_id"], v["sequence"], v["generation"], v["issued_at"],
                          [(r["x25519"], r["label"]) for r in v["recipients"]]) == p["policy"],
              f"policy {p['name']}: not canonical")
    for n in rp["negative"]:
        refused(lambda n=n: verify_policy(n["policy"], bytes.fromhex(n["signature_hex"]),
                                          statements[n["pinned_generation"]]), n["error"], f"policy {n['name']}")
    for c in rp["sequence"]:
        v = verified[c["policy"]]
        check(compare_to_floor(v["sequence"], v["hash"], c["floor"]["sequence"], bytes.fromhex(c["floor"]["hash_hex"]))
              == c["verdict"], f"sequence {c['name']}")
    for c in rp["next_sequence"]:
        check((c["candidate"] == c["stored"] + 1 and c["stored"] < 0xFFFFFFFF) == c["next"], f"next {c}")

    for p in doc["kak1"]["positive"]:
        st = parse_statement(p["statement"])
        seed = kak1_unwrap(bytes.fromhex(p["envelope_hex"]), bytes.fromhex(p["holder_sk_hex"]), p["suite"], st)
        check(seed.hex() == p["seed_hex"], f"kak1 {p['name']}: seed")
        check(len(bytes.fromhex(p["envelope_hex"])) == (146 if p["suite"] == 1 else 179), f"kak1 {p['name']}: size")
    for n in doc["kak1"]["negative"]:
        st = parse_statement(n["statement"])
        refused(lambda n=n, st=st: kak1_unwrap(bytes.fromhex(n["envelope_hex"]), bytes.fromhex(n["holder_sk_hex"]),
                                               n["suite_expected"], st), n["error"], f"kak1 {n['name']}")

    for p in doc["vault_label"]["positive"]:
        st = parse_statement(p["statement"])
        name = label_open(bytes.fromhex(p["sealed_hex"]), bytes.fromhex(p["account_x25519_sk_hex"]), st,
                          bytes.fromhex(p["vault_uid_hex"]))
        check(name == p["label"], f"label {p['name']}")
        check(len(bytes.fromhex(p["sealed_hex"])) == 240, f"label {p['name']}: size")
    for n in doc["vault_label"]["negative"]:
        st = parse_statement(n["statement"])
        refused(lambda n=n, st=st: label_open(bytes.fromhex(n["sealed_hex"]), bytes.fromhex(n["account_x25519_sk_hex"]),
                                              st, bytes.fromhex(n["vault_uid_hex"])), n["error"], f"label {n['name']}")

    for p in doc["storage_credential"]["positive"]:
        c = p["context"]
        check(b32_uid_decode(c["installation_id"]) is not None, "credential: installation id")
        secret = cred_open(bytes.fromhex(p["sealed_hex"]), bytes.fromhex(p["server_sk_hex"]), c["installation_id"],
                           bytes.fromhex(c["vault_uid_hex"]), c["key_id"])
        check(secret.decode() == p["secret"], f"credential {p['name']}")
        check(b64u_decode(p["sealed_base64url"]) == bytes.fromhex(p["sealed_hex"]), f"credential {p['name']}: base64url")
    for n in doc["storage_credential"]["negative"]:
        c = n["context"]
        refused(lambda n=n, c=c: cred_open(bytes.fromhex(n["sealed_hex"]), bytes.fromhex(n["server_sk_hex"]),
                                           c["installation_id"], bytes.fromhex(c["vault_uid_hex"]), c["key_id"]),
                n["error"], f"credential {n['name']}")

    for a in doc["public_id"]["accepted"]:
        check(uuid_bytes(a["text"]) is not None and uuid_bytes(a["text"]).hex() == a["bytes_hex"], f"public id {a['text']}")
    for r in doc["public_id"]["refused"]:
        check(uuid_bytes(r) is None, f"public id {r!r}: accepted")

    for p in doc["holder_proof"]["positive"]:
        st = parse_statement(p["statement"])
        hpk, sig = bytes.fromhex(p["holder_pk_hex"]), bytes.fromhex(p["signature_hex"])
        check_holder(st, p["installation_id"], p["suite"], hpk, sig)
        _, xpk, _, edpk = recovery_keys(bytes.fromhex(p["seed_hex"]))
        check(xpk == st["x25519"] and edpk == st["ed25519"], f"holder {p['name']}: seed doesn't derive the statement")
        check(ed_verify(st["ed25519"], p["message"].encode(), sig), f"holder {p['name']}: message")
        check(p["message"].count("\n") == 6 and p["message"].split("\n")[0] == "vhc-account-key-holder-v1",
              f"holder {p['name']}: shape")
        refused(lambda p=p: parse_statement(p["message"]), "bad_statement", f"holder {p['name']} as a statement")
        refused(lambda p=p: parse_policy(p["message"]), "bad_policy", f"holder {p['name']} as a policy")
    for n in doc["holder_proof"]["negative"]:
        st = parse_statement(n["statement"])
        refused(lambda n=n, st=st: check_holder(st, n["installation_id"], n["suite"], bytes.fromhex(n["holder_pk_hex"]),
                                                bytes.fromhex(n["signature_hex"])), n["error"], f"holder {n['name']}")

    codes = doc["codes"]
    for c in codes["request"]:
        check(code_inputs_ok("request", c), f"request {c['name']}: inputs")
        check(code_of("vhc-key-request-v1", c["request_id"], hashlib.sha256(c["payload"].encode()).hexdigest())
              == c["code"], f"request {c['name']}")
    for c in codes["transfer"]:
        check(code_inputs_ok("transfer", c), f"transfer {c['name']}: inputs")
        key = base64.standard_b64encode(bytes.fromhex(c["temporary_public_key_hex"])).decode()
        check(code_of("vhc-key-transfer-v1", c["public_id"], key) == c["code"], f"transfer {c['name']}")
    for c in codes["restore"]:
        check(code_inputs_ok("restore", c), f"restore {c['name']}: inputs")
        key = base64.standard_b64encode(bytes.fromhex(c["temporary_public_key_hex"])).decode()
        check(code_of("vhc-restore-v1", c["vault_uid"], key) == c["code"], f"restore {c['name']}")
    for c in codes["refused"]:
        check(not code_inputs_ok(c["kind"], c), f"code {c['name']}: accepted")
    return failures


def render(doc: dict) -> str:
    return json.dumps(doc, indent=2, sort_keys=True, ensure_ascii=False) + "\n"


def count(doc: dict) -> int:
    ak, rp = doc["account_key"], doc["recovery_policy"]
    return (len(ak["generations"]) + len(ak["statement_negative"]) + len(ak["chain_negative"]) + len(ak["follow"]) +
            len(rp["positive"]) + len(rp["negative"]) + len(rp["sequence"]) + len(rp["next_sequence"]) +
            sum(len(doc[k]["positive"]) + len(doc[k]["negative"])
                for k in ("kak1", "vault_label", "storage_credential", "holder_proof")) +
            len(doc["public_id"]["accepted"]) + len(doc["public_id"]["refused"]) +
            sum(len(doc["codes"][k]) for k in ("request", "transfer", "restore", "refused")))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--check", action="store_true", help="verify vhc.json instead of writing it")
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = ap.parse_args()
    doc = build()
    text = render(doc)
    if args.check:
        if not args.out.exists():
            print(f"FAIL: {args.out} is missing; run without --check to generate it")
            return 1
        if args.out.read_text(encoding="utf-8") != text:
            print(f"FAIL: {args.out} differs from what this script generates")
            return 1
        failures = verify(json.loads(text))
        for f in failures:
            print(f"FAIL: {f}")
        if failures:
            return 1
        print(f"OK: {count(doc)} vectors match and verify")
        return 0
    args.out.write_text(text, encoding="utf-8")
    failures = verify(json.loads(text))
    for f in failures:
        print(f"FAIL: {f}")
    print(f"wrote {args.out} ({count(doc)} vectors)")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
