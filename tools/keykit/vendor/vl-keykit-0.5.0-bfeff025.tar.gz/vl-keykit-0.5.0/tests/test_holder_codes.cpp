// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The holder proof, the comparison codes and the account public id's bytes against vectors/vhc.json `holder_proof`,
// `codes` and `public_id`.
#include "support.hpp"
#include "vl/keykit/holder_proof.hpp"
#include "vl/keykit/kak1.hpp"
#include "vl/keykit/key_codes.hpp"
#include "vl/keykit/recovery_policy.hpp"

#include <gtest/gtest.h>

#include <algorithm>

namespace vl::keykit::test {

namespace {

const Json& vhc(const char* section) { return vhcVectors().at(section); }

account::Signature signatureOf(const Json& j) {
    const auto b = hex(j);
    account::Signature s{};
    if (b.size() != s.size()) throw std::invalid_argument("a signature is 64 bytes");
    std::copy(b.begin(), b.end(), s.begin());
    return s;
}

kev1::Suite suiteOf(const Json& j) { return static_cast<kev1::Suite>(j.get<uint16_t>()); }

std::string holderError(const Json& n) {
    try {
        account::checkHolderProof(account::parseStatement(str(n.at("statement"))), str(n.at("installation_id")),
                                  suiteOf(n.at("suite")), hex(n.at("holder_pk_hex")), signatureOf(n.at("signature_hex")));
    } catch (const account::Error& e) {
        return std::string(account::errorCodeName(e.code()));
    }
    return "accepted";
}

}

TEST(PublicIdVectors, CanonicalTextOnly) {
    for (const auto& a : vhc("public_id").at("accepted")) {
        const auto bytes = account::parsePublicId(str(a.at("text")));
        ASSERT_TRUE(bytes.has_value()) << str(a.at("text"));
        EXPECT_EQ(toHex(*bytes), str(a.at("bytes_hex")));
    }
    for (const auto& r : vhc("public_id").at("refused")) {
        EXPECT_FALSE(account::parsePublicId(str(r))) << str(r);
    }
}

TEST(PublicIdVectors, IsWhatKak1Binds) {
    const auto& p = vhc("kak1").at("positive")[0];
    const auto header = kak1::inspect(hex(p.at("envelope_hex")));
    const auto statement = account::parseStatement(str(p.at("statement")));
    EXPECT_EQ(account::parsePublicId(statement.public_id), header.public_id);
}

TEST(HolderProofVectors, PositivesAreSignedAndVerified) {
    const auto& positive = vhc("holder_proof").at("positive");
    ASSERT_EQ(positive.size(), 3u);
    for (const auto& p : positive) {
        SCOPED_TRACE(str(p.at("name")));
        const auto statement = account::parseStatement(str(p.at("statement")));
        const auto seed = RecoverySeed::fromBytes(hex(p.at("seed_hex")));
        const auto installation = str(p.at("installation_id"));
        const auto suite = suiteOf(p.at("suite"));
        const auto key = hex(p.at("holder_pk_hex"));
        const auto message = account::holderMessage(statement, installation, suite, key);
        EXPECT_EQ(message, str(p.at("message")));
        EXPECT_EQ(std::ranges::count(message, '\n'), 6);
        // Neither a statement nor a policy parses it, so its signatures can't stand in for theirs.
        EXPECT_THROW((void)account::parseStatement(message), account::Error);
        EXPECT_THROW((void)account::parsePolicy(message), account::Error);
        const auto proof = account::signHolderProof(statement, seed, installation, suite, key);
        EXPECT_EQ(toHex(proof), str(p.at("signature_hex")));  // Ed25519 is deterministic
        EXPECT_NO_THROW(account::checkHolderProof(statement, installation, suite, key, proof));
        EXPECT_TRUE(account::verifyHolderProof(statement, installation, suite, key, proof));
    }
}

TEST(HolderProofVectors, NegativesFailAtTheirFirstCheck) {
    const auto& negative = vhc("holder_proof").at("negative");
    EXPECT_GE(negative.size(), 20u);
    for (const auto& n : negative) {
        SCOPED_TRACE(str(n.at("name")));
        EXPECT_EQ(holderError(n), str(n.at("error")));
        EXPECT_FALSE(account::verifyHolderProof(account::parseStatement(str(n.at("statement"))),
                                                str(n.at("installation_id")), suiteOf(n.at("suite")),
                                                hex(n.at("holder_pk_hex")), signatureOf(n.at("signature_hex"))));
    }
}

TEST(HolderProof, TheWriterRefusesWhatTheReaderWould) {
    const auto& p = vhc("holder_proof").at("positive")[0];
    const auto statement = account::parseStatement(str(p.at("statement")));
    const auto seed = RecoverySeed::fromBytes(hex(p.at("seed_hex")));
    const auto key = hex(p.at("holder_pk_hex"));
    EXPECT_THROW((void)account::signHolderProof(statement, seed, "not-an-installation", kev1::Suite::X25519, key),
                 account::Error);
    EXPECT_THROW((void)account::signHolderProof(statement, seed, str(p.at("installation_id")), kev1::Suite::P256, key),
                 account::Error);
    // Another generation's seed can't sign for this one.
    const auto& gens = vhcVectors().at("account_key").at("generations");
    const auto other = RecoverySeed::fromBytes(hex(gens[0].at("seed_hex")));
    EXPECT_THROW((void)account::signHolderProof(statement, other, str(p.at("installation_id")), kev1::Suite::X25519, key),
                 std::invalid_argument);
    // A statement encode refuses.
    auto broken = statement;
    broken.public_id = "not a uuid";
    EXPECT_THROW((void)account::holderMessage(broken, str(p.at("installation_id")), kev1::Suite::X25519, key),
                 std::invalid_argument);
    EXPECT_FALSE(account::verifyHolderProof(broken, str(p.at("installation_id")), kev1::Suite::X25519, key,
                                            signatureOf(p.at("signature_hex"))));
}

TEST(CodeVectors, RequestTransferAndRestore) {
    const auto& codes = vhc("codes");
    for (const auto& c : codes.at("request")) {
        SCOPED_TRACE(str(c.at("name")));
        EXPECT_EQ(codes::requestCode(str(c.at("request_id")), str(c.at("payload"))), str(c.at("code")));
    }
    for (const auto& c : codes.at("transfer")) {
        SCOPED_TRACE(str(c.at("name")));
        EXPECT_EQ(codes::transferCode(str(c.at("public_id")), hex(c.at("temporary_public_key_hex"))), str(c.at("code")));
    }
    for (const auto& c : codes.at("restore")) {
        SCOPED_TRACE(str(c.at("name")));
        EXPECT_EQ(codes::restoreCode(str(c.at("vault_uid")), hex(c.at("temporary_public_key_hex"))), str(c.at("code")));
    }
    // vaulthalla-cloud's own vectors (docs/design/key-manager.md, recovery-restore.md).
    EXPECT_EQ(str(codes.at("request")[0].at("code")), "4c0c-4ab7-e42c-29ef");
    EXPECT_EQ(str(codes.at("transfer")[0].at("code")), "a50d-b256-d985-6e9e");
    EXPECT_EQ(str(codes.at("restore")[0].at("code")), "6adc-ef02-f4a4-4fd0");
}

TEST(CodeVectors, RefusedInputs) {
    for (const auto& c : vhc("codes").at("refused")) {
        SCOPED_TRACE(str(c.at("name")));
        const auto kind = str(c.at("kind"));
        if (kind == "request") {
            EXPECT_THROW((void)codes::requestCode(str(c.at("request_id")), str(c.at("payload"))), std::invalid_argument);
        } else if (kind == "transfer") {
            EXPECT_THROW((void)codes::transferCode(str(c.at("public_id")), hex(c.at("temporary_public_key_hex"))),
                         std::invalid_argument);
        } else {
            EXPECT_THROW((void)codes::restoreCode(str(c.at("vault_uid")), hex(c.at("temporary_public_key_hex"))),
                         std::invalid_argument);
        }
    }
}

TEST(Codes, AnyChangedInputChangesTheCode) {
    const std::string id = "0123456789abcdefghjkmnpqr0";
    EXPECT_NE(codes::requestCode(id, "{}"), codes::requestCode(id, "{} "));
    EXPECT_NE(codes::requestCode(id, "{}"), codes::requestCode("1123456789abcdefghjkmnpqr0", "{}"));
    Bytes key(32, 7);
    const auto a = codes::transferCode("0f8fad5b-d9cb-469f-a165-70867728950e", key);
    EXPECT_EQ(a.size(), codes::kCodeTextSize);
    key[31] ^= 1;
    EXPECT_NE(a, codes::transferCode("0f8fad5b-d9cb-469f-a165-70867728950e", key));
    EXPECT_NE(codes::restoreCode(id, key), codes::restoreCode("1123456789abcdefghjkmnpqr0", key));
}

}
