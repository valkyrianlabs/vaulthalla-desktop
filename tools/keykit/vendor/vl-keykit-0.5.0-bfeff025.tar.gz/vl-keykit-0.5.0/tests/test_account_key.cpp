// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The account key statement, fingerprint, chain and pin following against vectors/vhc.json `account_key`, plus strict
// base64url and the signing side.
#include "support.hpp"
#include "vl/keykit/account_key.hpp"
#include "vl/keykit/base64url.hpp"

#include <gtest/gtest.h>

namespace vl::keykit::test {

namespace {

using account::ErrorCode;

const Json& ak() { return vhcVectors().at("account_key"); }

std::string publicId() { return str(ak().at("public_id")); }

account::Signature sigOf(const Json& j) {
    const auto b = hex(j);
    account::Signature s{};
    if (b.size() != s.size()) throw std::invalid_argument("a signature is 64 bytes");
    std::copy(b.begin(), b.end(), s.begin());
    return s;
}

account::Fingerprint fpOf(const Json& j) {
    const auto b = hex(j);
    account::Fingerprint f{};
    if (b.size() != f.size()) throw std::invalid_argument("a fingerprint is 16 bytes");
    std::copy(b.begin(), b.end(), f.begin());
    return f;
}

std::vector<account::SignedStatement> chainOf(const Json& j) {
    std::vector<account::SignedStatement> out;
    for (const auto& item : j) {
        account::SignedStatement s{.statement = str(item.at("statement")), .signature = sigOf(item.at("signature_hex"))};
        if (!item.at("previous_signature_hex").is_null()) s.previous_signature = sigOf(item.at("previous_signature_hex"));
        out.push_back(std::move(s));
    }
    return out;
}

std::string errorOf(const auto& fn, std::optional<std::size_t>* index = nullptr) {
    try {
        fn();
    } catch (const account::Error& e) {
        if (index) *index = e.index();
        return std::string(account::errorCodeName(e.code()));
    }
    return "accepted";
}

}

TEST(AccountKeyVectors, GenerationsAreReproducedAndVerify) {
    const auto& gens = ak().at("generations");
    ASSERT_EQ(gens.size(), 3u);
    std::vector<RecoverySeed> seeds;
    for (const auto& g : gens) seeds.push_back(RecoverySeed::fromBytes(hex(g.at("seed_hex"))));
    for (std::size_t i = 0; i < gens.size(); ++i) {
        const auto& g = gens[i];
        SCOPED_TRACE(str(g.at("name")));
        EXPECT_EQ(seeds[i].text(), str(g.at("seed_text")));
        const auto parsed = account::parseStatement(str(g.at("statement")));
        EXPECT_EQ(parsed.generation, i + 1);
        EXPECT_EQ(toHex(parsed.x25519_public), str(g.at("x25519_pk_hex")));
        EXPECT_EQ(toHex(parsed.ed25519_public), str(g.at("ed25519_pk_hex")));
        EXPECT_EQ(account::encode(parsed), str(g.at("statement")));
        const auto fp = account::fingerprint(parsed);
        EXPECT_EQ(toHex(fp), str(g.at("fingerprint_hex")));
        EXPECT_EQ(account::fingerprintText(fp), str(g.at("fingerprint_text")));
        EXPECT_EQ(account::parseFingerprint(str(g.at("fingerprint_text"))), fp);

        // A device builds and signs the same bytes from the seed (Ed25519 is deterministic).
        const auto built = account::statementFor(seeds[i], publicId(), parsed.generation, parsed.previous, parsed.reason);
        EXPECT_EQ(built, parsed);
        const bool rotation = str(g.at("link")) == "rotation";
        const auto signedStatement = account::sign(built, seeds[i], rotation ? &seeds[i - 1] : nullptr);
        EXPECT_EQ(signedStatement.statement, str(g.at("statement")));
        EXPECT_EQ(toHex(signedStatement.signature), str(g.at("signature_hex")));
        if (rotation) {
            ASSERT_TRUE(signedStatement.previous_signature);
            EXPECT_EQ(toHex(*signedStatement.previous_signature), str(g.at("previous_signature_hex")));
        } else {
            EXPECT_FALSE(signedStatement.previous_signature);
        }
    }
    const auto chain = account::verifyChain(chainOf(gens), publicId());
    ASSERT_EQ(chain.size(), 3u);
    for (std::size_t i = 0; i < chain.size(); ++i)
        EXPECT_EQ(account::linkName(chain[i].link), str(gens[i].at("link")));
}

TEST(AccountKeyVectors, NegativeStatementsFailAtTheirFirstCheck) {
    const auto& negatives = ak().at("statement_negative");
    ASSERT_GE(negatives.size(), 20u);
    for (const auto& n : negatives) {
        SCOPED_TRACE(str(n.at("name")));
        EXPECT_EQ(errorOf([&] { (void)account::parseStatement(str(n.at("statement"))); }), str(n.at("error")));
    }
}

TEST(AccountKeyVectors, NegativeChainsFailAtTheirFirstCheck) {
    for (const auto& n : ak().at("chain_negative")) {
        SCOPED_TRACE(str(n.at("name")));
        std::optional<std::size_t> index;
        EXPECT_EQ(errorOf([&] { (void)account::verifyChain(chainOf(n.at("chain")), publicId()); }, &index),
                  str(n.at("error")));
        EXPECT_EQ(index, n.at("index").get<std::size_t>());
    }
}

TEST(AccountKeyVectors, PinsFollowRotationsAndWaitForReplacements) {
    for (const auto& f : ak().at("follow")) {
        SCOPED_TRACE(str(f.at("name")));
        const account::Pin pin{.generation = f.at("pin").at("generation").get<uint32_t>(),
                               .fingerprint = fpOf(f.at("pin").at("fingerprint_hex"))};
        const auto chain = account::verifyChain(chainOf(f.at("chain")), publicId());
        const auto& expect = f.at("expect");
        if (expect.contains("error")) {
            EXPECT_EQ(errorOf([&] { (void)account::follow(pin, chain); }), str(expect.at("error")));
        } else {
            const auto r = account::follow(pin, chain);
            EXPECT_EQ(r.accepted, expect.at("accepted").get<uint32_t>());
            EXPECT_EQ(r.newest, expect.at("newest").get<uint32_t>());
            EXPECT_EQ(r.needsConfirmation(), r.newest > r.accepted);
        }
    }
}

TEST(AccountKeyVectors, FingerprintTextIsStrictUnlessLenient) {
    const auto& t = ak().at("fingerprint_text");
    const auto canonical = account::parseFingerprint(str(t.at("canonical")));
    ASSERT_TRUE(canonical);
    for (const auto& s : t.at("lenient_accepted")) {
        EXPECT_FALSE(account::parseFingerprint(str(s))) << s;
        EXPECT_EQ(account::parseFingerprint(str(s), true), canonical) << s;
    }
    for (const auto& s : t.at("refused")) {
        EXPECT_FALSE(account::parseFingerprint(str(s))) << s;
        EXPECT_FALSE(account::parseFingerprint(str(s), true)) << s;
    }
}

TEST(AccountKey, FreshKeysSignChainAndFollow) {
    const auto id = std::string("01234567-89ab-4cde-8f01-23456789abcd");
    const auto a = RecoverySeed::generate();
    const auto b = RecoverySeed::generate();
    const auto c = RecoverySeed::generate();
    const auto s1 = account::statementFor(a, id, 1, std::nullopt, account::Reason::Initial);
    const auto s2 = account::statementFor(b, id, 2, account::fingerprint(s1), account::Reason::Routine);
    const auto s3 = account::statementFor(c, id, 3, account::fingerprint(s2), account::Reason::Compromise);
    const std::vector chain{account::sign(s1, a), account::sign(s2, b, &a), account::sign(s3, c)};
    const auto verified = account::verifyChain(chain, id);
    ASSERT_EQ(verified.size(), 3u);
    EXPECT_EQ(verified[1].link, account::Link::Rotation);
    EXPECT_EQ(verified[2].link, account::Link::Replacement);
    const auto r = account::follow({1, account::fingerprint(s1)}, verified);
    EXPECT_EQ(r.accepted, 2u);
    EXPECT_TRUE(r.needsConfirmation());

    // Another account, a mismatched seed, a wrong previous key.
    EXPECT_EQ(errorOf([&] { (void)account::verifyChain(chain, "01234567-89ab-4cde-8f01-23456789abce"); }),
              "account_mismatch");
    EXPECT_THROW((void)account::sign(s1, b), std::invalid_argument);
    EXPECT_THROW((void)account::sign(s2, b, &c), std::invalid_argument);
    EXPECT_THROW((void)account::sign(s1, a, &a), std::invalid_argument);

    // Statements encode refuses.
    EXPECT_THROW((void)account::statementFor(a, "not-a-uuid", 1, std::nullopt, account::Reason::Initial),
                 std::invalid_argument);
    EXPECT_THROW((void)account::statementFor(a, id, 0, std::nullopt, account::Reason::Initial), std::invalid_argument);
    EXPECT_THROW((void)account::statementFor(a, id, 1, account::fingerprint(s1), account::Reason::Initial),
                 std::invalid_argument);
    EXPECT_THROW((void)account::statementFor(a, id, 2, std::nullopt, account::Reason::Routine), std::invalid_argument);
    EXPECT_THROW((void)account::statementFor(a, id, 2, account::fingerprint(s1), account::Reason::Initial),
                 std::invalid_argument);
    auto lowOrder = s1;
    lowOrder.x25519_public = {};
    EXPECT_THROW((void)account::encode(lowOrder), std::invalid_argument);

    // Every byte of a statement is signed.
    const auto& text = chain[0].statement;
    for (std::size_t i = 0; i < text.size(); ++i) {
        auto bad = chain[0];
        bad.statement[i] = static_cast<char>(bad.statement[i] ^ 0x01);
        EXPECT_NE(errorOf([&] { (void)account::verifyChain(std::span(&bad, 1), id); }), "accepted") << i;
    }
    EXPECT_EQ(errorOf([&] { (void)account::follow({0, {}}, verified); }), "rollback");
    EXPECT_EQ(account::errorCodeName(static_cast<ErrorCode>(200)), "unknown");
}

TEST(Base64Url, EncodesUnpaddedAndDecodesStrictly) {
    const auto b = [](const std::string& s) { return Bytes(s.begin(), s.end()); };
    // RFC 4648 §10, without padding.
    EXPECT_EQ(base64UrlEncode(b("")), "");
    EXPECT_EQ(base64UrlEncode(b("f")), "Zg");
    EXPECT_EQ(base64UrlEncode(b("fo")), "Zm8");
    EXPECT_EQ(base64UrlEncode(b("foo")), "Zm9v");
    EXPECT_EQ(base64UrlEncode(b("foobar")), "Zm9vYmFy");
    EXPECT_EQ(base64UrlEncode(Bytes{0xfb, 0xff}), "-_8");
    for (const auto* s : {"", "f", "fo", "foo", "foob", "fooba", "foobar"})
        EXPECT_EQ(base64UrlDecode(base64UrlEncode(b(s))), b(s)) << s;
    EXPECT_EQ(base64UrlDecode("-_8"), (Bytes{0xfb, 0xff}));
    EXPECT_FALSE(base64UrlDecode("Zg=="));  // padding
    EXPECT_FALSE(base64UrlDecode("Z"));     // 1 mod 4
    EXPECT_FALSE(base64UrlDecode("Zh"));    // non-zero trailing bits
    EXPECT_FALSE(base64UrlDecode("Zm9"));   // non-zero trailing bits
    EXPECT_FALSE(base64UrlDecode("+/8"));   // the standard alphabet
    EXPECT_FALSE(base64UrlDecode("Zm 9v"));
    EXPECT_FALSE(base64UrlDecode("Zm9v\n"));
}

}
