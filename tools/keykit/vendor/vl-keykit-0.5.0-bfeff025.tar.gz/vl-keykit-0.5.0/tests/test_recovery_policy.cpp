// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The signed recovery policy against vectors/vhc.json `recovery_policy`: canonical encoding, signatures by the pinned
// generation, every refusal, and the sequence rules.
#include "support.hpp"
#include "vl/keykit/kev1.hpp"
#include "vl/keykit/recovery_policy.hpp"

#include <gtest/gtest.h>

#include <map>

namespace vl::keykit::test {

namespace {

const Json& rp() { return vhcVectors().at("recovery_policy"); }

// The verified statement of each vector generation, by generation.
const account::KeyStatement& pinned(const uint32_t generation) {
    static const auto statements = [] {
        std::map<uint32_t, account::KeyStatement> out;
        for (const auto& g : vhcVectors().at("account_key").at("generations")) {
            const auto s = account::parseStatement(str(g.at("statement")));
            out.emplace(s.generation, s);
        }
        return out;
    }();
    return statements.at(generation);
}

const RecoverySeed& seedOf(const uint32_t generation) {
    static const auto seeds = [] {
        std::vector<RecoverySeed> out;
        for (const auto& g : vhcVectors().at("account_key").at("generations"))
            out.push_back(RecoverySeed::fromBytes(hex(g.at("seed_hex"))));
        return out;
    }();
    return seeds.at(generation - 1);
}

account::SignedPolicy signedOf(const Json& v) {
    account::SignedPolicy p{.policy = str(v.at("policy"))};
    const auto sig = hex(v.at("signature_hex"));
    std::copy(sig.begin(), sig.end(), p.signature.begin());
    return p;
}

account::Digest digestOf(const Json& j) {
    const auto b = hex(j);
    account::Digest d{};
    std::copy(b.begin(), b.end(), d.begin());
    return d;
}

// Recipient keys for fresh policies: the X25519 public key of the secret n, n, ..., n.
account::PublicKey keyOf(const uint8_t n) {
    const auto pk = kev1::publicKeyOf(kev1::Suite::X25519, Bytes(32, n));
    account::PublicKey out{};
    std::copy(pk.begin(), pk.end(), out.begin());
    return out;
}

}

TEST(RecoveryPolicyVectors, PositivePoliciesVerifyAndAreCanonical) {
    const auto& positives = rp().at("positive");
    ASSERT_GE(positives.size(), 3u);
    for (const auto& v : positives) {
        SCOPED_TRACE(str(v.at("name")));
        const auto generation = v.at("pinned_generation").get<uint32_t>();
        const auto verified = account::verifyPolicy(signedOf(v), pinned(generation));
        EXPECT_EQ(toHex(verified.hash), str(v.at("hash_hex")));
        EXPECT_EQ(toHex(account::policyHash(str(v.at("policy")))), str(v.at("hash_hex")));
        EXPECT_EQ(account::encode(verified.policy), str(v.at("policy")));
        // Encoding sorts: the reversed list gives the same bytes.
        auto reversed = verified.policy;
        std::ranges::reverse(reversed.recipients);
        EXPECT_EQ(account::encode(reversed), str(v.at("policy")));
        // Signing reproduces the signature (Ed25519 is deterministic).
        const auto again = account::signPolicy(verified.policy, seedOf(generation), pinned(generation));
        EXPECT_EQ(again.policy, str(v.at("policy")));
        EXPECT_EQ(toHex(again.signature), str(v.at("signature_hex")));
        for (std::size_t i = 1; i < verified.policy.recipients.size(); ++i)
            EXPECT_LT(verified.policy.recipients[i - 1].recipientId(), verified.policy.recipients[i].recipientId());
    }
}

TEST(RecoveryPolicyVectors, NegativePoliciesFailAtTheirFirstCheck) {
    const auto& negatives = rp().at("negative");
    ASSERT_GE(negatives.size(), 30u);
    for (const auto& n : negatives) {
        SCOPED_TRACE(str(n.at("name")));
        try {
            (void)account::verifyPolicy(signedOf(n), pinned(n.at("pinned_generation").get<uint32_t>()));
            ADD_FAILURE() << "accepted";
        } catch (const account::Error& e) {
            EXPECT_EQ(account::errorCodeName(e.code()), str(n.at("error")));
        }
    }
}

TEST(RecoveryPolicyVectors, SequenceRules) {
    std::map<std::string, account::VerifiedPolicy> byName;
    for (const auto& v : rp().at("positive"))
        byName.emplace(str(v.at("name")),
                       account::verifyPolicy(signedOf(v), pinned(v.at("pinned_generation").get<uint32_t>())));
    for (const auto& c : rp().at("sequence")) {
        SCOPED_TRACE(str(c.at("name")));
        const account::PolicyFloor floor{.sequence = c.at("floor").at("sequence").get<uint32_t>(),
                                         .hash = digestOf(c.at("floor").at("hash_hex"))};
        EXPECT_EQ(account::sequenceVerdictName(account::compareToFloor(byName.at(str(c.at("policy"))), floor)),
                  str(c.at("verdict")));
    }
    for (const auto& c : rp().at("next_sequence"))
        EXPECT_EQ(account::isNextSequence(c.at("stored").get<uint32_t>(), c.at("candidate").get<uint32_t>()),
                  c.at("next").get<bool>())
            << c.dump();
    const auto& first = byName.begin()->second;
    EXPECT_EQ(account::compareToFloor(first, account::floorOf(first)), account::SequenceVerdict::Unchanged);
}

TEST(RecoveryPolicy, SigningRefusesWhatVerificationWould) {
    const auto& current = pinned(2);
    account::RecoveryPolicy p{.public_id = current.public_id,
                              .sequence = 1,
                              .generation = 2,
                              .issued_at = "2026-11-14T00:00:00Z",
                              .recipients = {{keyOf(1), "Kit"}, {keyOf(2), "Person"}}};
    const auto s = account::signPolicy(p, seedOf(2), current);
    const auto v = account::verifyPolicy(s, current);
    EXPECT_EQ(v.policy.recipients.size(), 2u);

    EXPECT_THROW((void)account::signPolicy(p, seedOf(1), current), std::invalid_argument);  // another key
    EXPECT_THROW((void)account::signPolicy(p, seedOf(1), pinned(1)), std::invalid_argument);  // another generation
    auto q = p;
    q.recipients.push_back(q.recipients[0]);
    EXPECT_THROW((void)account::encode(q), std::invalid_argument);  // listed twice
    q = p;
    q.recipients[0].label = "";
    EXPECT_THROW((void)account::encode(q), std::invalid_argument);
    q.recipients[0].label = std::string(129, 'k');
    EXPECT_THROW((void)account::encode(q), std::invalid_argument);
    q.recipients[0].label = "tab\t";
    EXPECT_THROW((void)account::encode(q), std::invalid_argument);
    q = p;
    q.issued_at = "2026-11-14 00:00:00";
    EXPECT_THROW((void)account::encode(q), std::invalid_argument);
    q = p;
    q.sequence = 0;
    EXPECT_THROW((void)account::encode(q), std::invalid_argument);
    q = p;
    q.recipients[0].x25519_public = {};
    EXPECT_THROW((void)account::encode(q), std::invalid_argument);
    q = p;
    q.recipients.clear();
    for (std::size_t i = 0; i < account::kMaxPolicyRecipients + 1; ++i)
        q.recipients.push_back({keyOf(static_cast<uint8_t>(10 + i)), "r"});
    EXPECT_THROW((void)account::encode(q), std::invalid_argument);

    // Every byte of the signed policy matters.
    for (std::size_t i = 0; i < s.policy.size(); ++i) {
        auto bad = s;
        bad.policy[i] = static_cast<char>(bad.policy[i] ^ 0x01);
        EXPECT_THROW((void)account::verifyPolicy(bad, current), account::Error) << i;
    }
    auto badSig = s;
    badSig.signature[0] ^= 1;
    EXPECT_THROW((void)account::verifyPolicy(badSig, current), account::Error);
}

}
