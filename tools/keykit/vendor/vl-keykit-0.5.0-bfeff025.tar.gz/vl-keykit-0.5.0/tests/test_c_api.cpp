// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The C API (vl/keykit/vl_keykit.h) against the same golden vectors as the C++ tests: every status name, the seed and
// recovery code, statements, chains and pins, holder proofs, KAK1 (with a hardware-key callback), vault labels, the
// recovery policy, a restore's KEV1 unwrap and re-wrap, the comparison codes, sealed storage credentials, the buffer
// convention, argument checks and wiping. c_header_check.c proves the header is valid C.
#include "sealing.hpp"  // white box: the hardware-key callback is played by the library's own ECDH
#include "support.hpp"
#include "vl/keykit/account_key.hpp"
#include "vl/keykit/attestation.hpp"
#include "vl/keykit/kak1.hpp"
#include "vl/keykit/kev1.hpp"
#include "vl/keykit/recovery_policy.hpp"
#include "vl/keykit/storage_credential.hpp"
#include "vl/keykit/vault_label.hpp"
#include "vl/keykit/vl_keykit.h"

#include <gtest/gtest.h>

#include <atomic>
#include <cctype>
#include <cstring>
#include <functional>
#include <limits>
#include <map>
#include <memory>
#include <optional>

extern "C" int vl_keykit_c_header_check(void);

namespace vl::keykit::test {

namespace {

const Json& vhc(const char* section) { return vhcVectors().at(section); }

struct SeedFree {
    void operator()(vl_keykit_seed* s) const noexcept { vl_keykit_seed_free(s); }
};
using Seed = std::unique_ptr<vl_keykit_seed, SeedFree>;

struct VaultKeyFree {
    void operator()(vl_keykit_vault_key* k) const noexcept { vl_keykit_vault_key_free(k); }
};
using VaultKey = std::unique_ptr<vl_keykit_vault_key, VaultKeyFree>;

struct CredentialKeyFree {
    void operator()(vl_keykit_credential_key* k) const noexcept { vl_keykit_credential_key_free(k); }
};
using CredentialKey = std::unique_ptr<vl_keykit_credential_key, CredentialKeyFree>;

struct CredentialFree {
    void operator()(vl_keykit_credential* c) const noexcept { vl_keykit_credential_free(c); }
};
using Credential = std::unique_ptr<vl_keykit_credential, CredentialFree>;

std::string name(const vl_keykit_status status) { return vl_keykit_status_name(status); }

Seed seedFromText(const std::string& text) {
    vl_keykit_seed* raw = nullptr;
    const auto status = vl_keykit_seed_parse(text.data(), text.size(), &raw);
    if (status != VL_KEYKIT_OK) throw std::runtime_error("seed: " + name(status));
    return Seed(raw);
}

// The C API takes no seed bytes, so the vectors' seeds go in as their recovery code.
Seed seedFromHex(const Json& j) { return seedFromText(RecoverySeed::fromBytes(hex(j)).text()); }

// The generation whose X25519 secret key is `sk` (the label vectors name the account key by its secret).
Seed seedOfX25519Secret(const Bytes& sk) {
    for (const auto& g : vhcVectors().at("account_key").at("generations")) {
        const auto seed = RecoverySeed::fromBytes(hex(g.at("seed_hex")));
        const auto mine = seed.x25519SecretKey();
        if (std::ranges::equal(mine.bytes(), sk)) return seedFromText(seed.text());
    }
    throw std::runtime_error("no generation has that X25519 key");
}

std::string exportText(const vl_keykit_seed* seed) {
    std::string out(VL_KEYKIT_SEED_TEXT_SIZE, '\0');
    std::size_t len = out.size();
    if (vl_keykit_seed_export_text(seed, out.data(), &len) != VL_KEYKIT_OK) throw std::runtime_error("export");
    out.resize(len);
    return out;
}

std::string codeText(const std::function<vl_keykit_status(char*, std::size_t*)>& fn) {
    std::string out(VL_KEYKIT_CODE_TEXT_SIZE, '\0');
    std::size_t len = out.size();
    const auto status = fn(out.data(), &len);
    if (status != VL_KEYKIT_OK) return "status:" + name(status);
    out.resize(len);
    return out;
}

std::array<uint8_t, 16> uid16(const Bytes& b) {
    std::array<uint8_t, 16> out{};
    if (b.size() != out.size()) throw std::invalid_argument("16 bytes");
    std::copy(b.begin(), b.end(), out.begin());
    return out;
}

// A chain in the C API's shape, borrowing from `owned`.
struct Chain {
    std::vector<std::string> statements;
    std::vector<Bytes> signatures, previous;
    std::vector<vl_keykit_signed_statement> items;

    explicit Chain(const Json& j) {
        for (const auto& item : j) {
            statements.push_back(str(item.at("statement")));
            signatures.push_back(hex(item.at("signature_hex")));
            previous.push_back(item.at("previous_signature_hex").is_null() ? Bytes{} : hex(item.at("previous_signature_hex")));
        }
        for (std::size_t i = 0; i < statements.size(); ++i)
            items.push_back({statements[i].data(), statements[i].size(), signatures[i].data(),
                             previous[i].empty() ? nullptr : previous[i].data()});
    }
};

std::string publicId() { return str(vhc("account_key").at("public_id")); }

}

TEST(CApi, StatusNamesAreStableAndMatchTheFormats) {
    EXPECT_EQ(name(VL_KEYKIT_OK), "ok");
    EXPECT_EQ(name(VL_KEYKIT_ERR_BUFFER_TOO_SMALL), "buffer_too_small");
    EXPECT_EQ(name(VL_KEYKIT_ERR_SEED_BAD_CHECK), "seed_bad_check");
    EXPECT_EQ(name(9999), "unknown");
    EXPECT_EQ(name(-1), "unknown");
    for (int i = 0; i <= static_cast<int>(account::ErrorCode::BadInstallationId); ++i)
        EXPECT_EQ(name(200 + i), "account_" + std::string(account::errorCodeName(static_cast<account::ErrorCode>(i))));
    for (int i = 0; i <= static_cast<int>(kev1::ErrorCode::BadKeyVersion); ++i)
        EXPECT_EQ(name(300 + i), "kev1_" + std::string(kev1::errorCodeName(static_cast<kev1::ErrorCode>(i))));
    for (int i = 0; i <= static_cast<int>(kak1::ErrorCode::SeedMismatch); ++i)
        EXPECT_EQ(name(400 + i), "kak1_" + std::string(kak1::errorCodeName(static_cast<kak1::ErrorCode>(i))));
    for (int i = 0; i <= static_cast<int>(label::ErrorCode::BadLabel); ++i)
        EXPECT_EQ(name(500 + i), "label_" + std::string(label::errorCodeName(static_cast<label::ErrorCode>(i))));
    for (int i = 0; i <= static_cast<int>(credential::ErrorCode::AuthFailed); ++i)
        EXPECT_EQ(name(600 + i),
                  "credential_" + std::string(credential::errorCodeName(static_cast<credential::ErrorCode>(i))));
    for (int i = 0; i <= static_cast<int>(provenance::ErrorCode::BadSeed); ++i)
        EXPECT_EQ(name(700 + i),
                  "provenance_" + std::string(provenance::errorCodeName(static_cast<provenance::ErrorCode>(i))));
    // Each format's next value is unassigned.
    for (const int next : {8, 103, 229, 312, 410, 510, 606, 705}) {
        EXPECT_EQ(name(next), "unknown") << next;
    }
    EXPECT_STREQ(vl_keykit_version(), "0.5.0");
}

TEST(CApi, TheHeaderIsValidC) { EXPECT_EQ(vl_keykit_c_header_check(), 0); }

TEST(CApi, RecoveryCodes) {
    for (const auto& p : vectors().at("recovery_seed").at("positive")) {
        const auto seed = seedFromText(str(p.at("seed_text")));
        EXPECT_EQ(exportText(seed.get()), str(p.at("seed_text")));
        std::array<uint8_t, 32> x{}, e{};
        ASSERT_EQ(vl_keykit_seed_public_keys(seed.get(), x.data(), e.data()), VL_KEYKIT_OK);
        EXPECT_EQ(toHex(x), str(p.at("x25519_pk_hex")));
        EXPECT_EQ(toHex(e), str(p.at("ed25519_pk_hex")));
        EXPECT_EQ(vl_keykit_seed_public_keys(seed.get(), nullptr, e.data()), VL_KEYKIT_OK);
        // As a person types it: grouped, upper case.
        std::string typed = str(p.at("seed_text"));
        for (auto& c : typed) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
        typed.insert(9, " - ");
        EXPECT_EQ(exportText(seedFromText(typed).get()), str(p.at("seed_text")));
    }
    for (const auto& n : vectors().at("recovery_seed").at("negative")) {
        vl_keykit_seed* raw = reinterpret_cast<vl_keykit_seed*>(&raw);  // not NULL, so the reset is visible
        const auto text = str(n.at("seed_text"));
        EXPECT_EQ(name(vl_keykit_seed_parse(text.data(), text.size(), &raw)), "seed_" + str(n.at("error")));
        EXPECT_EQ(raw, nullptr);
    }
    vl_keykit_seed* raw = nullptr;
    EXPECT_EQ(vl_keykit_seed_parse("abc", 3, &raw), VL_KEYKIT_ERR_SEED_BAD_LENGTH);
    EXPECT_EQ(vl_keykit_seed_parse("1!8hr6b6azfczjm7b2hs4x7hn0j", 27, &raw), VL_KEYKIT_ERR_SEED_BAD_SYMBOL);

    // A fresh key: its code parses back to the same key.
    ASSERT_EQ(vl_keykit_seed_generate(&raw), VL_KEYKIT_OK);
    const Seed fresh(raw);
    const auto text = exportText(fresh.get());
    EXPECT_EQ(text.size(), static_cast<std::size_t>(VL_KEYKIT_SEED_TEXT_SIZE));
    std::array<uint8_t, 32> a{}, b{};
    ASSERT_EQ(vl_keykit_seed_public_keys(fresh.get(), a.data(), nullptr), VL_KEYKIT_OK);
    ASSERT_EQ(vl_keykit_seed_public_keys(seedFromText(text).get(), b.data(), nullptr), VL_KEYKIT_OK);
    EXPECT_EQ(a, b);
}

TEST(CApi, StatementsAreBuiltSignedAndParsed) {
    const auto& gens = vhc("account_key").at("generations");
    std::vector<Seed> seeds;
    for (const auto& g : gens) seeds.push_back(seedFromText(str(g.at("seed_text"))));
    const auto id = publicId();
    for (std::size_t i = 0; i < gens.size(); ++i) {
        const auto& g = gens[i];
        SCOPED_TRACE(str(g.at("name")));
        const auto statement = str(g.at("statement"));
        vl_keykit_statement_info info{};
        ASSERT_EQ(vl_keykit_statement_parse(statement.data(), statement.size(), &info), VL_KEYKIT_OK);
        EXPECT_EQ(info.generation, i + 1);
        EXPECT_EQ(toHex(info.fingerprint), str(g.at("fingerprint_hex")));
        EXPECT_EQ(toHex(info.x25519_public), str(g.at("x25519_pk_hex")));
        EXPECT_EQ(toHex(info.ed25519_public), str(g.at("ed25519_pk_hex")));
        EXPECT_EQ(toHex(info.public_id), toHex(*account::parsePublicId(id)));
        EXPECT_EQ(info.has_previous, i > 0 ? 1 : 0);
        if (i > 0) {
            EXPECT_EQ(toHex(info.previous_fingerprint), str(gens[i - 1].at("fingerprint_hex")));
        }

        std::string built(VL_KEYKIT_STATEMENT_MAX_SIZE, '\0');
        std::size_t len = built.size();
        ASSERT_EQ(vl_keykit_statement_build(seeds[i].get(), id.data(), id.size(), info.generation,
                                            info.has_previous ? info.previous_fingerprint : nullptr, info.reason,
                                            built.data(), &len),
                  VL_KEYKIT_OK);
        built.resize(len);
        EXPECT_EQ(built, statement);

        const bool rotation = !g.at("previous_signature_hex").is_null();
        std::array<uint8_t, 64> sig{}, prev{};
        ASSERT_EQ(vl_keykit_statement_sign(statement.data(), statement.size(), seeds[i].get(),
                                           rotation ? seeds[i - 1].get() : nullptr, sig.data(), prev.data()),
                  VL_KEYKIT_OK);
        EXPECT_EQ(toHex(sig), str(g.at("signature_hex")));
        if (rotation) {
            EXPECT_EQ(toHex(prev), str(g.at("previous_signature_hex")));
        }

        EXPECT_EQ(vl_keykit_seed_matches(seeds[i].get(), statement.data(), statement.size()), VL_KEYKIT_OK);
        EXPECT_EQ(vl_keykit_seed_matches(seeds[(i + 1) % 3].get(), statement.data(), statement.size()),
                  VL_KEYKIT_ERR_SEED_MISMATCH);
        EXPECT_EQ(vl_keykit_statement_sign(statement.data(), statement.size(), seeds[(i + 1) % 3].get(), nullptr,
                                           sig.data(), nullptr),
                  VL_KEYKIT_ERR_SEED_MISMATCH);

        std::string fpText(VL_KEYKIT_FINGERPRINT_TEXT_SIZE, '\0');
        len = fpText.size();
        ASSERT_EQ(vl_keykit_fingerprint_text(info.fingerprint, fpText.data(), &len), VL_KEYKIT_OK);
        EXPECT_EQ(fpText, str(g.at("fingerprint_text")));
    }
    // A previous key that isn't generation 1's can't co-sign generation 2.
    const auto s2 = str(gens[1].at("statement"));
    std::array<uint8_t, 64> sig{}, prev{};
    EXPECT_EQ(vl_keykit_statement_sign(s2.data(), s2.size(), seeds[1].get(), seeds[2].get(), sig.data(), prev.data()),
              VL_KEYKIT_ERR_SEED_MISMATCH);
    // A bad reason, and a generation 1 with a previous fingerprint.
    std::string out(VL_KEYKIT_STATEMENT_MAX_SIZE, '\0');
    std::size_t len = out.size();
    EXPECT_EQ(vl_keykit_statement_build(seeds[0].get(), id.data(), id.size(), 1, nullptr, 7, out.data(), &len),
              VL_KEYKIT_ERR_INVALID_ARGUMENT);
    const std::array<uint8_t, 16> fp{};
    EXPECT_EQ(vl_keykit_statement_build(seeds[0].get(), id.data(), id.size(), 1, fp.data(), VL_KEYKIT_REASON_INITIAL,
                                        out.data(), &len),
              VL_KEYKIT_ERR_INVALID_ARGUMENT);

    for (const auto& n : vhc("account_key").at("statement_negative")) {
        SCOPED_TRACE(str(n.at("name")));
        const auto text = str(n.at("statement"));
        vl_keykit_statement_info info{};
        EXPECT_EQ(name(vl_keykit_statement_parse(text.data(), text.size(), &info)), "account_" + str(n.at("error")));
    }
}

TEST(CApi, FingerprintTextAndPublicIds) {
    const auto& ft = vhc("account_key").at("fingerprint_text");
    const auto canonical = str(ft.at("canonical"));
    std::array<uint8_t, 16> fp{}, other{};
    ASSERT_EQ(vl_keykit_fingerprint_parse(canonical.data(), canonical.size(), 0, fp.data()), VL_KEYKIT_OK);
    for (const auto& t : ft.at("lenient_accepted")) {
        const auto text = str(t);
        EXPECT_EQ(vl_keykit_fingerprint_parse(text.data(), text.size(), 0, other.data()), VL_KEYKIT_ERR_BAD_FORMAT);
        ASSERT_EQ(vl_keykit_fingerprint_parse(text.data(), text.size(), 1, other.data()), VL_KEYKIT_OK);
        EXPECT_EQ(other, fp);
    }
    for (const auto& t : ft.at("refused")) {
        const auto text = str(t);
        EXPECT_EQ(vl_keykit_fingerprint_parse(text.data(), text.size(), 1, other.data()), VL_KEYKIT_ERR_BAD_FORMAT);
    }
    for (const auto& a : vhc("public_id").at("accepted")) {
        const auto text = str(a.at("text"));
        std::array<uint8_t, 16> bytes{};
        ASSERT_EQ(vl_keykit_public_id_bytes(text.data(), text.size(), bytes.data()), VL_KEYKIT_OK);
        EXPECT_EQ(toHex(bytes), str(a.at("bytes_hex")));
    }
    for (const auto& r : vhc("public_id").at("refused")) {
        const auto text = str(r);
        std::array<uint8_t, 16> bytes{};
        EXPECT_EQ(vl_keykit_public_id_bytes(text.data(), text.size(), bytes.data()), VL_KEYKIT_ERR_BAD_FORMAT) << text;
    }
}

TEST(CApi, ChainsAndPins) {
    const auto& ak = vhc("account_key");
    const auto id = publicId();
    const Chain chain(ak.at("generations"));
    std::vector<vl_keykit_generation> out(chain.items.size());
    std::size_t failed = 0;
    ASSERT_EQ(vl_keykit_chain_verify(chain.items.data(), chain.items.size(), id.data(), id.size(), out.data(), &failed),
              VL_KEYKIT_OK);
    EXPECT_EQ(failed, std::numeric_limits<std::size_t>::max());
    const int links[] = {VL_KEYKIT_LINK_INITIAL, VL_KEYKIT_LINK_ROTATION, VL_KEYKIT_LINK_REPLACEMENT};
    const int reasons[] = {VL_KEYKIT_REASON_INITIAL, VL_KEYKIT_REASON_ROUTINE, VL_KEYKIT_REASON_COMPROMISE};
    for (std::size_t i = 0; i < out.size(); ++i) {
        EXPECT_EQ(out[i].generation, i + 1);
        EXPECT_EQ(out[i].link, links[i]);
        EXPECT_EQ(out[i].reason, reasons[i]);
        EXPECT_EQ(toHex(out[i].fingerprint), str(ak.at("generations")[i].at("fingerprint_hex")));
    }
    EXPECT_EQ(vl_keykit_chain_verify(chain.items.data(), chain.items.size(), id.data(), id.size(), nullptr, nullptr),
              VL_KEYKIT_OK);

    for (const auto& n : ak.at("chain_negative")) {
        SCOPED_TRACE(str(n.at("name")));
        const Chain bad(n.at("chain"));
        failed = 99;
        const auto status = vl_keykit_chain_verify(bad.items.data(), bad.items.size(), id.data(), id.size(), nullptr,
                                                   &failed);
        EXPECT_EQ(name(status), "account_" + str(n.at("error")));
        EXPECT_EQ(failed, n.at("index").get<std::size_t>());
    }

    for (const auto& f : ak.at("follow")) {
        SCOPED_TRACE(str(f.at("name")));
        const Chain c(f.at("chain"));
        const auto pinFp = hex(f.at("pin").at("fingerprint_hex"));
        uint32_t accepted = 0, newest = 0;
        const auto status = vl_keykit_chain_follow(c.items.data(), c.items.size(), id.data(), id.size(),
                                                   f.at("pin").at("generation").get<uint32_t>(), pinFp.data(),
                                                   &accepted, &newest);
        const auto& expect = f.at("expect");
        if (expect.contains("error")) {
            EXPECT_EQ(name(status), "account_" + str(expect.at("error")));
        } else {
            ASSERT_EQ(status, VL_KEYKIT_OK);
            EXPECT_EQ(accepted, expect.at("accepted").get<uint32_t>());
            EXPECT_EQ(newest, expect.at("newest").get<uint32_t>());
        }
    }
}

TEST(CApi, HolderProofs) {
    for (const auto& p : vhc("holder_proof").at("positive")) {
        SCOPED_TRACE(str(p.at("name")));
        const auto seed = seedFromHex(p.at("seed_hex"));
        const auto statement = str(p.at("statement"));
        const auto installation = str(p.at("installation_id"));
        const auto key = hex(p.at("holder_pk_hex"));
        const auto suite = p.at("suite").get<uint16_t>();
        std::array<uint8_t, 64> proof{};
        ASSERT_EQ(vl_keykit_holder_proof_sign(statement.data(), statement.size(), seed.get(), installation.data(),
                                              installation.size(), suite, key.data(), key.size(), proof.data()),
                  VL_KEYKIT_OK);
        EXPECT_EQ(toHex(proof), str(p.at("signature_hex")));
        EXPECT_EQ(vl_keykit_holder_proof_verify(statement.data(), statement.size(), installation.data(),
                                                installation.size(), suite, key.data(), key.size(), proof.data()),
                  VL_KEYKIT_OK);
    }
    for (const auto& n : vhc("holder_proof").at("negative")) {
        SCOPED_TRACE(str(n.at("name")));
        const auto statement = str(n.at("statement"));
        const auto installation = str(n.at("installation_id"));
        const auto key = hex(n.at("holder_pk_hex"));
        const auto sig = hex(n.at("signature_hex"));
        EXPECT_EQ(name(vl_keykit_holder_proof_verify(statement.data(), statement.size(), installation.data(),
                                                     installation.size(), n.at("suite").get<uint16_t>(), key.data(),
                                                     key.size(), sig.data())),
                  "account_" + str(n.at("error")));
    }
    // The signer checks the inputs first, then the seed.
    const auto& p = vhc("holder_proof").at("positive")[0];
    const auto statement = str(p.at("statement"));
    const auto installation = str(p.at("installation_id"));
    const auto key = hex(p.at("holder_pk_hex"));
    const auto wrongSeed = seedFromHex(vhc("account_key").at("generations")[0].at("seed_hex"));
    std::array<uint8_t, 64> proof{};
    EXPECT_EQ(vl_keykit_holder_proof_sign(statement.data(), statement.size(), wrongSeed.get(), "x", 1, 1, key.data(),
                                          key.size(), proof.data()),
              VL_KEYKIT_ERR_ACCOUNT_BAD_INSTALLATION_ID);
    EXPECT_EQ(vl_keykit_holder_proof_sign(statement.data(), statement.size(), wrongSeed.get(), installation.data(),
                                          installation.size(), 1, key.data(), key.size(), proof.data()),
              VL_KEYKIT_ERR_SEED_MISMATCH);
}

namespace {

// A Secure Enclave stand-in for vl_keykit_kak1_unwrap_with: Z by the library's own ECDH with a secret it holds.
struct Enclave {
    kev1::Suite suite;
    Bytes secret;
    int calls = 0;
    int refuse = 0;      // non-zero: the callback returns it
    bool zero = false;   // hand back an all-zero Z
};

int enclaveAgree(void* context, const uint8_t* epk, const size_t epkLen, uint8_t z[32]) {
    auto& e = *static_cast<Enclave*>(context);
    ++e.calls;
    if (e.refuse) return e.refuse;
    if (e.zero) {
        std::memset(z, 0, 32);
        return 0;
    }
    const auto mine = detail::secretKey(e.suite, e.secret);
    const auto peer = detail::publicKey(e.suite, {epk, epkLen});
    const auto shared = detail::agree(mine.get(), peer.get());
    if (!shared || shared->size() != 32) return 1;
    std::memcpy(z, shared->bytes().data(), 32);
    return 0;
}

}

TEST(CApi, Kak1) {
    const auto gen2Text = str(vhc("account_key").at("generations")[1].at("seed_text"));
    for (const auto& p : vhc("kak1").at("positive")) {
        SCOPED_TRACE(str(p.at("name")));
        const auto env = hex(p.at("envelope_hex"));
        const auto sk = hex(p.at("holder_sk_hex"));
        const auto pk = hex(p.at("holder_pk_hex"));
        const auto statement = str(p.at("statement"));
        const auto suite = p.at("suite").get<uint16_t>();

        vl_keykit_seed* raw = nullptr;
        ASSERT_EQ(vl_keykit_kak1_unwrap(env.data(), env.size(), sk.data(), sk.size(), suite, statement.data(),
                                        statement.size(), &raw),
                  VL_KEYKIT_OK);
        const Seed opened(raw);
        EXPECT_EQ(exportText(opened.get()), gen2Text);

        Enclave enclave{.suite = static_cast<kev1::Suite>(suite), .secret = sk};
        ASSERT_EQ(vl_keykit_kak1_unwrap_with(env.data(), env.size(), pk.data(), pk.size(), suite, statement.data(),
                                             statement.size(), enclaveAgree, &enclave, &raw),
                  VL_KEYKIT_OK);
        const Seed viaHardware(raw);
        EXPECT_EQ(enclave.calls, 1);
        EXPECT_EQ(exportText(viaHardware.get()), gen2Text);

        // The user cancels: no seed, and a status of its own.
        enclave.refuse = -1;
        EXPECT_EQ(vl_keykit_kak1_unwrap_with(env.data(), env.size(), pk.data(), pk.size(), suite, statement.data(),
                                             statement.size(), enclaveAgree, &enclave, &raw),
                  VL_KEYKIT_ERR_AGREEMENT_FAILED);
        EXPECT_EQ(raw, nullptr);
        enclave.refuse = 0;
        enclave.zero = true;
        EXPECT_EQ(vl_keykit_kak1_unwrap_with(env.data(), env.size(), pk.data(), pk.size(), suite, statement.data(),
                                             statement.size(), enclaveAgree, &enclave, &raw),
                  VL_KEYKIT_ERR_KAK1_BAD_EPHEMERAL);
        // Another holder's envelope: refused before the hardware is asked.
        enclave.zero = false;
        enclave.calls = 0;
        auto otherPk = pk;
        otherPk.back() ^= 1;
        EXPECT_EQ(vl_keykit_kak1_unwrap_with(env.data(), env.size(), otherPk.data(), otherPk.size(), suite,
                                             statement.data(), statement.size(), enclaveAgree, &enclave, &raw),
                  VL_KEYKIT_ERR_KAK1_RECIPIENT_MISMATCH);
        EXPECT_EQ(enclave.calls, 0);

        vl_keykit_kak1_header h{};
        ASSERT_EQ(vl_keykit_kak1_inspect(env.data(), env.size(), &h), VL_KEYKIT_OK);
        EXPECT_EQ(h.suite, suite);
        EXPECT_EQ(h.generation, 2u);
        EXPECT_EQ(toHex(h.recipient_id), str(p.at("recipient_id_hex")));

        // A fresh wrap to the same holder opens to the same key.
        Bytes fresh(VL_KEYKIT_KAK1_MAX_SIZE);
        std::size_t len = fresh.size();
        ASSERT_EQ(vl_keykit_kak1_wrap(opened.get(), statement.data(), statement.size(), suite, pk.data(), pk.size(),
                                      fresh.data(), &len),
                  VL_KEYKIT_OK);
        EXPECT_EQ(len, suite == 1 ? 146u : 179u);
        ASSERT_EQ(vl_keykit_kak1_unwrap(fresh.data(), len, sk.data(), sk.size(), suite, statement.data(),
                                        statement.size(), &raw),
                  VL_KEYKIT_OK);
        EXPECT_EQ(exportText(Seed(raw).get()), gen2Text);
        // Only the statement's own key wraps.
        const auto gen1 = seedFromText(str(vhc("account_key").at("generations")[0].at("seed_text")));
        len = fresh.size();
        EXPECT_EQ(vl_keykit_kak1_wrap(gen1.get(), statement.data(), statement.size(), suite, pk.data(), pk.size(),
                                      fresh.data(), &len),
                  VL_KEYKIT_ERR_SEED_MISMATCH);
    }
    for (const auto& n : vhc("kak1").at("negative")) {
        SCOPED_TRACE(str(n.at("name")));
        const auto env = hex(n.at("envelope_hex"));
        const auto sk = hex(n.at("holder_sk_hex"));
        const auto statement = str(n.at("statement"));
        vl_keykit_seed* raw = nullptr;
        EXPECT_EQ(name(vl_keykit_kak1_unwrap(env.data(), env.size(), sk.data(), sk.size(),
                                             n.at("suite_expected").get<uint16_t>(), statement.data(), statement.size(),
                                             &raw)),
                  "kak1_" + str(n.at("error")));
        EXPECT_EQ(raw, nullptr);
    }
}

TEST(CApi, VaultLabels) {
    for (const auto& p : vhc("vault_label").at("positive")) {
        SCOPED_TRACE(str(p.at("name")));
        const auto sealed = hex(p.at("sealed_hex"));
        const auto seed = seedOfX25519Secret(hex(p.at("account_x25519_sk_hex")));
        const auto statement = str(p.at("statement"));
        const auto uid = uid16(hex(p.at("vault_uid_hex")));
        std::string out(VL_KEYKIT_LABEL_MAX_SIZE, '\0');
        std::size_t len = out.size();
        ASSERT_EQ(vl_keykit_label_open(sealed.data(), sealed.size(), seed.get(), statement.data(), statement.size(),
                                       uid.data(), out.data(), &len),
                  VL_KEYKIT_OK);
        out.resize(len);
        EXPECT_EQ(out, str(p.at("label")));

        Bytes resealed(VL_KEYKIT_LABEL_SEALED_SIZE);
        len = resealed.size();
        ASSERT_EQ(vl_keykit_label_seal(out.data(), out.size(), statement.data(), statement.size(), uid.data(),
                                       resealed.data(), &len),
                  VL_KEYKIT_OK);
        EXPECT_EQ(len, static_cast<std::size_t>(VL_KEYKIT_LABEL_SEALED_SIZE));
        std::string again(VL_KEYKIT_LABEL_MAX_SIZE, '\0');
        len = again.size();
        ASSERT_EQ(vl_keykit_label_open(resealed.data(), resealed.size(), seed.get(), statement.data(), statement.size(),
                                       uid.data(), again.data(), &len),
                  VL_KEYKIT_OK);
        again.resize(len);
        EXPECT_EQ(again, out);
    }
    for (const auto& n : vhc("vault_label").at("negative")) {
        SCOPED_TRACE(str(n.at("name")));
        const auto sealed = hex(n.at("sealed_hex"));
        const auto seed = seedOfX25519Secret(hex(n.at("account_x25519_sk_hex")));
        const auto statement = str(n.at("statement"));
        const auto uid = uid16(hex(n.at("vault_uid_hex")));
        std::string out(VL_KEYKIT_LABEL_MAX_SIZE, '\0');
        std::size_t len = out.size();
        EXPECT_EQ(name(vl_keykit_label_open(sealed.data(), sealed.size(), seed.get(), statement.data(),
                                            statement.size(), uid.data(), out.data(), &len)),
                  "label_" + str(n.at("error")));
    }
    const auto& p = vhc("vault_label").at("positive")[0];
    const auto statement = str(p.at("statement"));
    const auto uid = uid16(hex(p.at("vault_uid_hex")));
    Bytes out(VL_KEYKIT_LABEL_SEALED_SIZE);
    std::size_t len = out.size();
    EXPECT_EQ(vl_keykit_label_seal("tab\there", 8, statement.data(), statement.size(), uid.data(), out.data(), &len),
              VL_KEYKIT_ERR_INVALID_ARGUMENT);
}

TEST(CApi, RecoveryPolicy) {
    const auto& gens = vhc("account_key").at("generations");
    std::map<uint32_t, std::string> statements;
    for (const auto& g : gens) statements[account::parseStatement(str(g.at("statement"))).generation] = str(g.at("statement"));
    const auto gen2 = seedFromText(str(gens[1].at("seed_text")));

    for (const auto& p : vhc("recovery_policy").at("positive")) {
        SCOPED_TRACE(str(p.at("name")));
        const auto policy = str(p.at("policy"));
        const auto sig = hex(p.at("signature_hex"));
        const auto& pinned = statements.at(p.at("pinned_generation").get<uint32_t>());
        vl_keykit_policy_info info{};
        ASSERT_EQ(vl_keykit_policy_verify(policy.data(), policy.size(), sig.data(), pinned.data(), pinned.size(), &info),
                  VL_KEYKIT_OK);
        EXPECT_EQ(toHex(info.hash), str(p.at("hash_hex")));
        const auto parsed = account::parsePolicy(policy);
        EXPECT_EQ(info.sequence, parsed.sequence);
        EXPECT_EQ(info.generation, parsed.generation);
        ASSERT_EQ(info.recipient_count, parsed.recipients.size());

        // Read each recipient back, then sign the same policy again from those fields (in reverse order: the writer
        // sorts them): the same bytes and, Ed25519 being deterministic, the same signature.
        std::vector<std::array<uint8_t, 32>> keys(info.recipient_count);
        std::vector<std::string> labels(info.recipient_count);
        std::vector<vl_keykit_policy_recipient> recipients;
        for (std::size_t i = 0; i < info.recipient_count; ++i) {
            labels[i].resize(VL_KEYKIT_LABEL_MAX_SIZE);
            std::size_t len = labels[i].size();
            ASSERT_EQ(vl_keykit_policy_recipient_at(policy.data(), policy.size(), i, keys[i].data(), labels[i].data(),
                                                    &len),
                      VL_KEYKIT_OK);
            labels[i].resize(len);
            EXPECT_EQ(labels[i], parsed.recipients[i].label);
        }
        for (std::size_t i = info.recipient_count; i-- > 0;)
            recipients.push_back({keys[i].data(), labels[i].data(), labels[i].size()});
        std::array<uint8_t, 32> key{};
        std::size_t len = 0;
        EXPECT_EQ(vl_keykit_policy_recipient_at(policy.data(), policy.size(), info.recipient_count, key.data(), nullptr,
                                                &len),
                  VL_KEYKIT_ERR_INVALID_ARGUMENT);

        std::string resigned(VL_KEYKIT_POLICY_MAX_SIZE, '\0');
        len = resigned.size();
        std::array<uint8_t, 64> signature{};
        ASSERT_EQ(vl_keykit_policy_sign(gen2.get(), pinned.data(), pinned.size(), parsed.sequence,
                                        parsed.issued_at.data(), parsed.issued_at.size(), recipients.data(),
                                        recipients.size(), resigned.data(), &len, signature.data()),
                  VL_KEYKIT_OK);
        resigned.resize(len);
        EXPECT_EQ(resigned, policy);
        EXPECT_EQ(toHex(signature), str(p.at("signature_hex")));
    }
    for (const auto& n : vhc("recovery_policy").at("negative")) {
        SCOPED_TRACE(str(n.at("name")));
        const auto policy = str(n.at("policy"));
        const auto sig = hex(n.at("signature_hex"));
        const auto& pinned = statements.at(n.at("pinned_generation").get<uint32_t>());
        vl_keykit_policy_info info{};
        EXPECT_EQ(name(vl_keykit_policy_verify(policy.data(), policy.size(), sig.data(), pinned.data(), pinned.size(),
                                               &info)),
                  "account_" + str(n.at("error")));
    }
    // The seed must be the current generation's.
    const auto gen1 = seedFromText(str(gens[0].at("seed_text")));
    std::string out(VL_KEYKIT_POLICY_MAX_SIZE, '\0');
    std::size_t len = out.size();
    std::array<uint8_t, 64> signature{};
    EXPECT_EQ(vl_keykit_policy_sign(gen1.get(), statements[2].data(), statements[2].size(), 1, "2026-11-14T12:00:00Z",
                                    20, nullptr, 0, out.data(), &len, signature.data()),
              VL_KEYKIT_ERR_SEED_MISMATCH);
    EXPECT_EQ(vl_keykit_policy_sign(gen2.get(), statements[2].data(), statements[2].size(), 1, "yesterday", 9, nullptr,
                                    0, out.data(), &len, signature.data()),
              VL_KEYKIT_ERR_INVALID_ARGUMENT);
}

TEST(CApi, ARestoreUnwrapsWithTheAccountKeyAndWrapsToTheTemporaryKey) {
    const auto seedText = str(vhc("account_key").at("generations")[1].at("seed_text"));
    const auto account = RecoverySeed::parse(seedText);
    const auto seed = seedFromText(seedText);
    for (const auto& v : vectors().at("kev1").at("positive")) {
        SCOPED_TRACE(str(v.at("name")));
        const auto vaultKey = hex(v.at("vault_key_hex"));
        const auto version = v.at("key_version").get<uint32_t>();
        const auto uid = uid16(hex(v.at("vault_uid_hex")));
        // What the bucket holds: the vault key wrapped to the account key's X25519 recipient (suite 1).
        const auto toAccount = kev1::wrap(vaultKey, kev1::Suite::X25519, version, uid, account.x25519PublicKey());

        vl_keykit_kev1_header h{};
        ASSERT_EQ(vl_keykit_kev1_inspect(toAccount.data(), toAccount.size(), &h), VL_KEYKIT_OK);
        EXPECT_EQ(h.key_version, version);
        std::array<uint8_t, 32> rid{};
        const auto accountPk = account.x25519PublicKey();
        ASSERT_EQ(vl_keykit_recipient_id(accountPk.data(), accountPk.size(), rid.data()), VL_KEYKIT_OK);
        EXPECT_EQ(toHex(h.recipient_id), toHex(rid));

        vl_keykit_vault_key* raw = nullptr;
        ASSERT_EQ(vl_keykit_kev1_unwrap(toAccount.data(), toAccount.size(), seed.get(), uid.data(), &raw), VL_KEYKIT_OK);
        const VaultKey key(raw);
        EXPECT_EQ(vl_keykit_vault_key_version(key.get()), version);

        // Delivered to the vector's recipient (the restore's temporary key, of either suite).
        const auto suite = v.at("suite").get<uint16_t>();
        const auto rpk = hex(v.at("recipient_pk_hex"));
        Bytes env(VL_KEYKIT_KEV1_MAX_SIZE);
        std::size_t len = env.size();
        ASSERT_EQ(vl_keykit_kev1_wrap(key.get(), suite, rpk.data(), rpk.size(), env.data(), &len), VL_KEYKIT_OK);
        env.resize(len);
        EXPECT_EQ(len, suite == 1 ? 150u : 183u);
        const auto opened = kev1::unwrap(env, hex(v.at("recipient_sk_hex")), static_cast<kev1::Suite>(suite), uid);
        EXPECT_EQ(opened.key_version, version);
        EXPECT_EQ(toHex(opened.key.bytes()), str(v.at("vault_key_hex")));

        // Another vault, a tampered tag, another recipient's envelope.
        auto otherUid = uid;
        otherUid[0] ^= 1;
        EXPECT_EQ(vl_keykit_kev1_unwrap(toAccount.data(), toAccount.size(), seed.get(), otherUid.data(), &raw),
                  VL_KEYKIT_ERR_KEV1_VAULT_MISMATCH);
        EXPECT_EQ(raw, nullptr);
        auto tampered = toAccount;
        tampered.back() ^= 1;
        EXPECT_EQ(vl_keykit_kev1_unwrap(tampered.data(), tampered.size(), seed.get(), uid.data(), &raw),
                  VL_KEYKIT_ERR_KEV1_WRAP_AUTH_FAILED);
        const auto theirs = hex(v.at("envelope_hex"));
        const auto status = vl_keykit_kev1_unwrap(theirs.data(), theirs.size(), seed.get(), uid.data(), &raw);
        EXPECT_TRUE(status == VL_KEYKIT_ERR_KEV1_RECIPIENT_MISMATCH || status == VL_KEYKIT_ERR_KEV1_UNSUPPORTED_SUITE)
            << name(status);
        EXPECT_EQ(vl_keykit_kev1_skipped_by_restore(VL_KEYKIT_ERR_KEV1_RECIPIENT_MISMATCH), 1);
    }
    EXPECT_EQ(vl_keykit_kev1_skipped_by_restore(VL_KEYKIT_ERR_KEV1_BAD_PURPOSE), 1);
    EXPECT_EQ(vl_keykit_kev1_skipped_by_restore(VL_KEYKIT_ERR_KEV1_UNSUPPORTED_RECIPIENT_CLASS), 1);
    EXPECT_EQ(vl_keykit_kev1_skipped_by_restore(VL_KEYKIT_ERR_KEV1_WRAP_AUTH_FAILED), 0);
    EXPECT_EQ(vl_keykit_kev1_skipped_by_restore(VL_KEYKIT_ERR_KAK1_RECIPIENT_MISMATCH), 0);
    EXPECT_EQ(vl_keykit_kev1_skipped_by_restore(VL_KEYKIT_OK), 0);
    EXPECT_EQ(vl_keykit_vault_key_version(nullptr), 0u);
}

TEST(CApi, ComparisonCodes) {
    const auto& codes = vhc("codes");
    for (const auto& c : codes.at("request")) {
        const auto id = str(c.at("request_id")), payload = str(c.at("payload"));
        EXPECT_EQ(codeText([&](char* o, std::size_t* l) {
                      return vl_keykit_request_code(id.data(), id.size(), payload.data(), payload.size(), o, l);
                  }),
                  str(c.at("code")));
    }
    for (const auto& c : codes.at("transfer")) {
        const auto id = str(c.at("public_id"));
        const auto key = hex(c.at("temporary_public_key_hex"));
        EXPECT_EQ(codeText([&](char* o, std::size_t* l) {
                      return vl_keykit_transfer_code(id.data(), id.size(), key.data(), key.size(), o, l);
                  }),
                  str(c.at("code")));
    }
    for (const auto& c : codes.at("restore")) {
        const auto uid = str(c.at("vault_uid"));
        const auto key = hex(c.at("temporary_public_key_hex"));
        EXPECT_EQ(codeText([&](char* o, std::size_t* l) {
                      return vl_keykit_restore_code(uid.data(), uid.size(), key.data(), key.size(), o, l);
                  }),
                  str(c.at("code")));
    }
    for (const auto& c : codes.at("refused")) {
        SCOPED_TRACE(str(c.at("name")));
        const auto kind = str(c.at("kind"));
        std::string result;
        if (kind == "request") {
            const auto id = str(c.at("request_id")), payload = str(c.at("payload"));
            result = codeText([&](char* o, std::size_t* l) {
                return vl_keykit_request_code(id.data(), id.size(), payload.data(), payload.size(), o, l);
            });
        } else {
            const auto text = str(c.at(kind == "transfer" ? "public_id" : "vault_uid"));
            const auto key = hex(c.at("temporary_public_key_hex"));
            result = codeText([&](char* o, std::size_t* l) {
                return kind == "transfer" ? vl_keykit_transfer_code(text.data(), text.size(), key.data(), key.size(), o, l)
                                          : vl_keykit_restore_code(text.data(), text.size(), key.data(), key.size(), o, l);
            });
        }
        EXPECT_EQ(result, "status:invalid_argument");
    }
}

namespace {

CredentialKey credentialKeyOf(const Bytes& sk) {
    vl_keykit_credential_key* raw = nullptr;
    if (vl_keykit_credential_key_from_secret(sk.data(), &raw) != VL_KEYKIT_OK) throw std::runtime_error("key");
    return CredentialKey(raw);
}

std::array<uint8_t, 32> publicOf(const vl_keykit_credential_key* key) {
    std::array<uint8_t, 32> out{};
    if (vl_keykit_credential_key_public(key, out.data()) != VL_KEYKIT_OK) throw std::runtime_error("public");
    return out;
}

// Opens `sealed` under the vector's binding: the status, and the secret on success.
std::pair<vl_keykit_status, Bytes> openCredential(const Bytes& sealed, const vl_keykit_credential_key* key,
                                                  const Json& context) {
    const auto installation = str(context.at("installation_id"));
    const auto keyId = str(context.at("key_id"));
    const auto uid = uid16(hex(context.at("vault_uid_hex")));
    vl_keykit_credential* raw = reinterpret_cast<vl_keykit_credential*>(&raw);  // must be reset to NULL on failure
    const auto status = vl_keykit_credential_open(sealed.data(), sealed.size(), key, installation.data(),
                                                  installation.size(), uid.data(), keyId.data(), keyId.size(), &raw);
    if (status != VL_KEYKIT_OK) {
        if (raw != nullptr) throw std::runtime_error("a failed open left a handle");
        return {status, {}};
    }
    const Credential credential(raw);
    std::size_t len = 0;
    if (vl_keykit_credential_secret(credential.get(), nullptr, &len) != VL_KEYKIT_ERR_BUFFER_TOO_SMALL)
        throw std::runtime_error("asking the length");
    Bytes secret(len);
    if (vl_keykit_credential_secret(credential.get(), secret.data(), &len) != VL_KEYKIT_OK) throw std::runtime_error("read");
    return {status, secret};
}

}

TEST(CApi, StorageCredentials) {
    for (const auto& p : vhc("storage_credential").at("positive")) {
        SCOPED_TRACE(str(p.at("name")));
        const auto key = credentialKeyOf(hex(p.at("server_sk_hex")));
        EXPECT_EQ(toHex(publicOf(key.get())), str(p.at("server_pk_hex")));
        const auto [status, secret] = openCredential(hex(p.at("sealed_hex")), key.get(), p.at("context"));
        ASSERT_EQ(name(status), "ok");
        EXPECT_EQ(std::string(secret.begin(), secret.end()), str(p.at("secret")));

        // Sealed again through the C API (a fresh ephemeral key), it opens to the same secret.
        const auto& c = p.at("context");
        const auto installation = str(c.at("installation_id"));
        const auto keyId = str(c.at("key_id"));
        const auto uid = uid16(hex(c.at("vault_uid_hex")));
        const auto pk = publicOf(key.get());
        Bytes sealed(VL_KEYKIT_CREDENTIAL_SEALED_MAX_SIZE);
        std::size_t len = sealed.size();
        ASSERT_EQ(vl_keykit_credential_seal(secret.data(), secret.size(), installation.data(), installation.size(),
                                            uid.data(), keyId.data(), keyId.size(), pk.data(), sealed.data(), &len),
                  VL_KEYKIT_OK);
        EXPECT_EQ(len, credential::kPrefixSize + secret.size() + 16);
        sealed.resize(len);
        EXPECT_NE(toHex(sealed), str(p.at("sealed_hex")));
        EXPECT_EQ(openCredential(sealed, key.get(), c).second, secret);
    }
    for (const auto& n : vhc("storage_credential").at("negative")) {
        SCOPED_TRACE(str(n.at("name")));
        const auto key = credentialKeyOf(hex(n.at("server_sk_hex")));
        EXPECT_EQ(name(openCredential(hex(n.at("sealed_hex")), key.get(), n.at("context")).first),
                  "credential_" + str(n.at("error")));
    }

    // A one-time key: fresh each time; a credential sealed to one opens with it only.
    vl_keykit_credential_key* rawA = nullptr;
    vl_keykit_credential_key* rawB = nullptr;
    ASSERT_EQ(vl_keykit_credential_key_generate(&rawA), VL_KEYKIT_OK);
    ASSERT_EQ(vl_keykit_credential_key_generate(&rawB), VL_KEYKIT_OK);
    const CredentialKey a(rawA), b(rawB);
    EXPECT_NE(publicOf(a.get()), publicOf(b.get()));
    const std::string installation = toBase32(newUid());
    const auto uid = newUid();
    const std::string keyId = "005abc";
    const std::string secretText = "an application key secret";
    const auto pk = publicOf(a.get());
    Bytes sealed(VL_KEYKIT_CREDENTIAL_SEALED_MAX_SIZE);
    std::size_t len = sealed.size();
    ASSERT_EQ(vl_keykit_credential_seal(reinterpret_cast<const uint8_t*>(secretText.data()), secretText.size(),
                                        installation.data(), installation.size(), uid.data(), keyId.data(),
                                        keyId.size(), pk.data(), sealed.data(), &len),
              VL_KEYKIT_OK);
    sealed.resize(len);
    const Json context{{"installation_id", installation}, {"vault_uid_hex", toHex(uid)}, {"key_id", keyId}};
    const auto opened = openCredential(sealed, a.get(), context);
    EXPECT_EQ(std::string(opened.second.begin(), opened.second.end()), secretText);
    EXPECT_EQ(name(openCredential(sealed, b.get(), context).first), "credential_auth_failed");

    // The read follows the buffer convention: too small writes nothing.
    vl_keykit_credential* raw = nullptr;
    ASSERT_EQ(vl_keykit_credential_open(sealed.data(), sealed.size(), a.get(), installation.data(), installation.size(),
                                        uid.data(), keyId.data(), keyId.size(), &raw),
              VL_KEYKIT_OK);
    const Credential credential(raw);
    Bytes small(secretText.size() - 1, 0x23);
    len = small.size();
    EXPECT_EQ(vl_keykit_credential_secret(credential.get(), small.data(), &len), VL_KEYKIT_ERR_BUFFER_TOO_SMALL);
    EXPECT_EQ(len, secretText.size());
    EXPECT_EQ(small, Bytes(secretText.size() - 1, 0x23));
    EXPECT_EQ(vl_keykit_credential_secret(credential.get(), small.data(), nullptr), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_keykit_credential_secret(nullptr, small.data(), &len), VL_KEYKIT_ERR_INVALID_ARGUMENT);

    // Bindings outside their ranges are refused before anything is read.
    const auto refused = [&](const std::string& inst, const std::string& kid) {
        vl_keykit_credential* out = nullptr;
        return vl_keykit_credential_open(sealed.data(), sealed.size(), a.get(), inst.data(), inst.size(), uid.data(),
                                         kid.data(), kid.size(), &out);
    };
    EXPECT_EQ(refused(installation.substr(1), keyId), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(refused(installation, ""), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(refused(installation, "key id"), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(refused(installation, std::string(129, 'k')), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_keykit_credential_open(sealed.data(), sealed.size(), nullptr, installation.data(), installation.size(),
                                        uid.data(), keyId.data(), keyId.size(), &raw),
              VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(raw, nullptr);
    EXPECT_EQ(vl_keykit_credential_open(sealed.data(), sealed.size(), a.get(), installation.data(), installation.size(),
                                        nullptr, keyId.data(), keyId.size(), &raw),
              VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_keykit_credential_open(sealed.data(), sealed.size(), a.get(), installation.data(), installation.size(),
                                        uid.data(), keyId.data(), keyId.size(), nullptr),
              VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_keykit_credential_key_generate(nullptr), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_keykit_credential_key_from_secret(nullptr, &rawA), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(rawA, nullptr);
    EXPECT_EQ(vl_keykit_credential_key_public(nullptr, small.data()), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_keykit_credential_key_public(a.get(), nullptr), VL_KEYKIT_ERR_INVALID_ARGUMENT);

    // The sealing side refuses what the format refuses.
    const auto seal = [&](const Bytes& secret, const uint8_t* key) {
        Bytes out(VL_KEYKIT_CREDENTIAL_SEALED_MAX_SIZE + 1);
        std::size_t n = out.size();
        return vl_keykit_credential_seal(secret.data(), secret.size(), installation.data(), installation.size(),
                                         uid.data(), keyId.data(), keyId.size(), key, out.data(), &n);
    };
    EXPECT_EQ(seal({}, pk.data()), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(seal(Bytes(1025, 1), pk.data()), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(seal(Bytes(1024, 1), pk.data()), VL_KEYKIT_OK);
    EXPECT_EQ(seal(Bytes(4, 1), nullptr), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    const std::array<uint8_t, 32> lowOrder{};
    EXPECT_EQ(name(seal(Bytes(4, 1), lowOrder.data())), "credential_bad_ephemeral");
    len = 0;
    EXPECT_EQ(vl_keykit_credential_seal(reinterpret_cast<const uint8_t*>(secretText.data()), secretText.size(),
                                        installation.data(), installation.size(), uid.data(), keyId.data(),
                                        keyId.size(), pk.data(), nullptr, &len),
              VL_KEYKIT_ERR_BUFFER_TOO_SMALL);
    EXPECT_EQ(len, credential::kPrefixSize + secretText.size() + 16);
    vl_keykit_credential_key_free(nullptr);
    vl_keykit_credential_free(nullptr);
}

TEST(CApi, BuffersArgumentsAndHandles) {
    const char* id = "0123456789abcdefghjkmnpqrs";
    const char* payload = R"({"generation":1})";
    // Ask for the size, then too small (nothing written), then exact.
    std::size_t len = 0;
    EXPECT_EQ(vl_keykit_request_code(id, 26, payload, std::strlen(payload), nullptr, &len),
              VL_KEYKIT_ERR_BUFFER_TOO_SMALL);
    EXPECT_EQ(len, static_cast<std::size_t>(VL_KEYKIT_CODE_TEXT_SIZE));
    std::string out(32, '#');
    len = 18;
    EXPECT_EQ(vl_keykit_request_code(id, 26, payload, std::strlen(payload), out.data(), &len),
              VL_KEYKIT_ERR_BUFFER_TOO_SMALL);
    EXPECT_EQ(len, 19u);
    EXPECT_EQ(out, std::string(32, '#'));
    len = out.size();
    EXPECT_EQ(vl_keykit_request_code(id, 26, payload, std::strlen(payload), out.data(), &len), VL_KEYKIT_OK);
    EXPECT_EQ(len, 19u);
    EXPECT_EQ(out.substr(0, 19), "4c0c-4ab7-e42c-29ef");
    EXPECT_EQ(out.substr(19), std::string(13, '#'));  // no terminating NUL

    // NULL where something is required; NULL with length 0 is the empty input.
    EXPECT_EQ(vl_keykit_request_code(id, 26, payload, std::strlen(payload), out.data(), nullptr),
              VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_keykit_request_code(nullptr, 26, payload, 1, out.data(), &len), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    len = out.size();
    EXPECT_EQ(vl_keykit_request_code(id, 26, nullptr, 0, out.data(), &len), VL_KEYKIT_OK);
    EXPECT_EQ(vl_keykit_seed_generate(nullptr), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_keykit_seed_export_text(nullptr, out.data(), &len), VL_KEYKIT_ERR_INVALID_ARGUMENT);
    EXPECT_EQ(vl_keykit_kak1_unwrap_with(nullptr, 0, nullptr, 0, 1, nullptr, 0, nullptr, nullptr, nullptr),
              VL_KEYKIT_ERR_INVALID_ARGUMENT);
    vl_keykit_statement_info info{};
    EXPECT_EQ(vl_keykit_statement_parse(nullptr, 0, &info), VL_KEYKIT_ERR_ACCOUNT_BAD_STATEMENT);
    vl_keykit_seed_free(nullptr);
    vl_keykit_vault_key_free(nullptr);

    // The recovery code export follows the same convention.
    vl_keykit_seed* raw = nullptr;
    ASSERT_EQ(vl_keykit_seed_generate(&raw), VL_KEYKIT_OK);
    const Seed seed(raw);
    len = 26;
    EXPECT_EQ(vl_keykit_seed_export_text(seed.get(), out.data(), &len), VL_KEYKIT_ERR_BUFFER_TOO_SMALL);
    EXPECT_EQ(len, 27u);
}

namespace {

std::atomic<int> capiWiped{0};
std::atomic<bool> capiAllZero{true};
void observeCapi(const void*, const std::span<const uint8_t> after) {
    ++capiWiped;
    if (!std::ranges::all_of(after, [](const uint8_t b) { return b == 0; })) capiAllZero = false;
}

}

TEST(CApi, HandlesAreWipedOnFree) {
    vl_keykit_seed* raw = nullptr;
    ASSERT_EQ(vl_keykit_seed_generate(&raw), VL_KEYKIT_OK);
    capiWiped = 0;
    capiAllZero = true;
    setWipeObserverForTesting(&observeCapi);
    vl_keykit_seed_free(raw);
    setWipeObserverForTesting(nullptr);
    EXPECT_EQ(capiWiped.load(), 1);  // the seed's one buffer
    EXPECT_TRUE(capiAllZero.load());

    const auto account = RecoverySeed::generate();
    const auto seed = seedFromText(account.text());
    const Uid uid{1, 2, 3};
    const Bytes vaultKey(32, 0x5a);
    const auto env = kev1::wrap(vaultKey, kev1::Suite::X25519, 3, uid, account.x25519PublicKey());
    vl_keykit_vault_key* key = nullptr;
    ASSERT_EQ(vl_keykit_kev1_unwrap(env.data(), env.size(), seed.get(), uid.data(), &key), VL_KEYKIT_OK);
    capiWiped = 0;
    setWipeObserverForTesting(&observeCapi);
    vl_keykit_vault_key_free(key);
    setWipeObserverForTesting(nullptr);
    EXPECT_EQ(capiWiped.load(), 1);
    EXPECT_TRUE(capiAllZero.load());

    // The one-time key and the opened credential: one buffer each.
    vl_keykit_credential_key* oneTime = nullptr;
    ASSERT_EQ(vl_keykit_credential_key_generate(&oneTime), VL_KEYKIT_OK);
    std::array<uint8_t, 32> pk{};
    ASSERT_EQ(vl_keykit_credential_key_public(oneTime, pk.data()), VL_KEYKIT_OK);
    const std::string installation = toBase32(newUid());
    const std::string keyId = "005abc";
    const Bytes secret(40, 0x41);
    Bytes sealed(VL_KEYKIT_CREDENTIAL_SEALED_MAX_SIZE);
    std::size_t len = sealed.size();
    ASSERT_EQ(vl_keykit_credential_seal(secret.data(), secret.size(), installation.data(), installation.size(), uid.data(),
                                        keyId.data(), keyId.size(), pk.data(), sealed.data(), &len),
              VL_KEYKIT_OK);
    vl_keykit_credential* opened = nullptr;
    ASSERT_EQ(vl_keykit_credential_open(sealed.data(), len, oneTime, installation.data(), installation.size(), uid.data(),
                                        keyId.data(), keyId.size(), &opened),
              VL_KEYKIT_OK);
    capiWiped = 0;
    setWipeObserverForTesting(&observeCapi);
    vl_keykit_credential_key_free(oneTime);
    EXPECT_EQ(capiWiped.load(), 1);
    vl_keykit_credential_free(opened);
    setWipeObserverForTesting(nullptr);
    EXPECT_EQ(capiWiped.load(), 2);
    EXPECT_TRUE(capiAllZero.load());
}

}
