// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/kak1.hpp"

#include "sealing.hpp"

#include <algorithm>
#include <utility>

namespace vl::keykit::kak1 {

namespace {

constexpr std::array<std::pair<ErrorCode, std::string_view>, 10> kErrorNames{{
    {ErrorCode::BadMagic, "bad_magic"},
    {ErrorCode::UnsupportedVersion, "unsupported_version"},
    {ErrorCode::UnsupportedSuite, "unsupported_suite"},
    {ErrorCode::AccountMismatch, "account_mismatch"},
    {ErrorCode::KeyMismatch, "key_mismatch"},
    {ErrorCode::RecipientMismatch, "recipient_mismatch"},
    {ErrorCode::BadLength, "bad_length"},
    {ErrorCode::BadEphemeral, "bad_ephemeral"},
    {ErrorCode::WrapAuthFailed, "wrap_auth_failed"},
    {ErrorCode::SeedMismatch, "seed_mismatch"},
}};

constexpr std::string_view kInfo = "vhc.kak1.wrap";
constexpr std::size_t kOffVersion = 8, kOffSuite = 10, kOffGeneration = 12, kOffPublicId = 16, kOffFingerprint = 32,
                      kOffRecipient = 48, kOffEpkLen = 80;

std::array<uint8_t, 16> publicIdBytes(const account::KeyStatement& statement) {
    const auto id = account::parsePublicId(statement.public_id);
    if (!id) throw std::invalid_argument("the statement's public id is not a canonical UUID");
    return *id;
}

// Whether the seed's keys are the statement's (so it derives the statement's fingerprint).
bool derivesStatement(const RecoverySeed& seed, const account::KeyStatement& statement) {
    const auto x = seed.x25519PublicKey();
    const auto e = seed.ed25519PublicKey();
    return std::ranges::equal(x, statement.x25519_public) && std::ranges::equal(e, statement.ed25519_public);
}

uint16_t checkSuite(const std::span<const uint8_t> env) {
    if (env.size() < kFixedPrefixSize || !std::equal(kMagic.begin(), kMagic.end(), env.begin()))
        throw Error(ErrorCode::BadMagic);
    if (detail::be16(env.data() + kOffVersion) != kVersion) throw Error(ErrorCode::UnsupportedVersion);
    const auto suite = detail::be16(env.data() + kOffSuite);
    if (!detail::knownSuite(suite)) throw Error(ErrorCode::UnsupportedSuite);
    return suite;
}

void checkLength(const std::span<const uint8_t> env, const kev1::Suite suite) {
    const auto epkLen = detail::be16(env.data() + kOffEpkLen);
    if (epkLen != detail::epkSize(suite) || env.size() != kFixedPrefixSize + epkLen + kWrappedSize)
        throw Error(ErrorCode::BadLength);
}

RecoverySeed open(const std::span<const uint8_t> env, const std::span<const uint8_t> holderPublicKey,
                  const kev1::Suite expectedSuite, const account::KeyStatement& statement, const Agreement& agree) {
    if (checkSuite(env) != static_cast<uint16_t>(expectedSuite)) throw Error(ErrorCode::UnsupportedSuite);
    const auto id = publicIdBytes(statement);
    if (!std::equal(id.begin(), id.end(), env.begin() + kOffPublicId)) throw Error(ErrorCode::AccountMismatch);
    const auto fp = account::fingerprint(statement);
    if (detail::be32(env.data() + kOffGeneration) != statement.generation ||
        !std::equal(fp.begin(), fp.end(), env.begin() + kOffFingerprint))
        throw Error(ErrorCode::KeyMismatch);
    const auto rid = kev1::recipientId(holderPublicKey);
    if (!equalConstantTime(env.subspan(kOffRecipient, rid.size()), rid)) throw Error(ErrorCode::RecipientMismatch);
    checkLength(env, expectedSuite);
    const auto epkLen = detail::epkSize(expectedSuite);
    const auto prefix = env.first(kFixedPrefixSize + epkLen);
    const auto epk = env.subspan(kFixedPrefixSize, epkLen);

    const auto z = agree(epk);
    if (!z) throw Error(ErrorCode::BadEphemeral);
    const auto key = detail::deriveKey(z->bytes(), epk, holderPublicKey, kInfo, prefix);
    const auto seed = detail::aeadOpen(key.bytes(), env.subspan(prefix.size()), prefix);
    if (!seed) throw Error(ErrorCode::WrapAuthFailed);
    auto out = RecoverySeed::fromBytes(seed->bytes());
    if (!derivesStatement(out, statement)) throw Error(ErrorCode::SeedMismatch);
    return out;
}

}

std::string_view errorCodeName(const ErrorCode code) {
    for (const auto& [c, name] : kErrorNames)
        if (c == code) return name;
    return "unknown";
}

Error::Error(const ErrorCode code)
    : std::runtime_error("KAK1 envelope rejected: " + std::string(errorCodeName(code))), code_(code) {}

std::vector<uint8_t> wrap(const RecoverySeed& seed, const account::KeyStatement& statement, const kev1::Suite suite,
                          const std::span<const uint8_t> holderPublicKey,
                          const std::span<const uint8_t> ephemeralSecretForTesting) {
    if (!detail::knownSuite(static_cast<uint16_t>(suite))) throw std::invalid_argument("unknown KAK1 suite");
    (void)account::encode(statement);  // a statement parse would accept
    if (!derivesStatement(seed, statement)) throw std::invalid_argument("the seed is not this statement's key");
    const auto peer = detail::publicKey(suite, holderPublicKey);
    if (!peer) throw std::invalid_argument("the holder public key is not a valid key for its suite");
    const auto esk = detail::ephemeralSecret(suite, ephemeralSecretForTesting);
    const auto mine = detail::secretKey(suite, esk.bytes());
    if (!mine) throw std::invalid_argument("the ephemeral secret key is not valid for its suite");
    const auto epk = kev1::publicKeyOf(suite, esk.bytes());
    const auto z = detail::agree(mine.get(), peer.get());
    if (!z) throw Error(ErrorCode::BadEphemeral);

    std::vector<uint8_t> env(kMagic.begin(), kMagic.end());
    detail::putBe16(env, kVersion);
    detail::putBe16(env, static_cast<uint16_t>(suite));
    detail::putBe32(env, statement.generation);
    detail::append(env, publicIdBytes(statement));
    detail::append(env, account::fingerprint(statement));
    detail::append(env, kev1::recipientId(holderPublicKey));
    detail::putBe16(env, static_cast<uint16_t>(epk.size()));
    detail::append(env, epk);
    const auto key = detail::deriveKey(z->bytes(), epk, holderPublicKey, kInfo, env);
    const auto wrapped = detail::aeadSeal(key.bytes(), seed.bytes(), env);
    detail::append(env, wrapped);
    return env;
}

RecoverySeed unwrap(const std::span<const uint8_t> envelope, const std::span<const uint8_t> holderSecretKey,
                    const kev1::Suite expectedSuite, const account::KeyStatement& statement) {
    std::vector<uint8_t> hpk;
    try {
        hpk = kev1::publicKeyOf(expectedSuite, holderSecretKey);
    } catch (const std::invalid_argument&) {
        hpk.clear();  // not a key of this suite: it can't be the recipient (an empty key never matches a recipient id)
    }
    const auto mine = hpk.empty() ? detail::Pkey{} : detail::secretKey(expectedSuite, holderSecretKey);
    return open(envelope, hpk, expectedSuite, statement, [&](const std::span<const uint8_t> epk) {
        const auto peer = detail::publicKey(expectedSuite, epk);
        return detail::agree(mine.get(), peer.get());
    });
}

RecoverySeed unwrapWith(const std::span<const uint8_t> envelope, const std::span<const uint8_t> holderPublicKey,
                        const kev1::Suite expectedSuite, const account::KeyStatement& statement,
                        const Agreement& agree) {
    return open(envelope, holderPublicKey, expectedSuite, statement, [&](const std::span<const uint8_t> epk) {
        if (!detail::publicKey(expectedSuite, epk)) return std::optional<SecretBytes>{};  // not a point of the suite
        auto z = agree(epk);
        // An all-zero Z (a low-order X25519 point) is refused as the in-memory reader refuses it.
        if (z && std::ranges::all_of(z->bytes(), [](const uint8_t b) { return b == 0; }))
            return std::optional<SecretBytes>{};
        return z;
    });
}

Header inspect(const std::span<const uint8_t> env) {
    const auto suite = checkSuite(env);
    checkLength(env, static_cast<kev1::Suite>(suite));
    Header h{.suite = suite, .generation = detail::be32(env.data() + kOffGeneration)};
    std::copy_n(env.begin() + kOffPublicId, h.public_id.size(), h.public_id.begin());
    std::copy_n(env.begin() + kOffFingerprint, h.fingerprint.size(), h.fingerprint.begin());
    std::copy_n(env.begin() + kOffRecipient, h.recipient_id.size(), h.recipient_id.begin());
    return h;
}

}
