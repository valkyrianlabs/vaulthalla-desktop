// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
//
// The C API (include/vl/keykit/vl_keykit.h) over the C++ library: argument checks, the buffer convention, handles for
// secrets and the mapping of every exception to a status. No exception leaves an extern "C" function.
#include "vl/keykit/vl_keykit.h"

#include "sealing.hpp"
#include "vl/keykit/account_key.hpp"
#include "vl/keykit/attestation.hpp"
#include "vl/keykit/holder_proof.hpp"
#include "vl/keykit/kak1.hpp"
#include "vl/keykit/kev1.hpp"
#include "vl/keykit/key_codes.hpp"
#include "vl/keykit/recovery_policy.hpp"
#include "vl/keykit/secret.hpp"
#include "vl/keykit/seed.hpp"
#include "vl/keykit/storage_credential.hpp"
#include "vl/keykit/vault_label.hpp"

#include <openssl/crypto.h>

#include <algorithm>
#include <array>
#include <cstring>
#include <limits>
#include <new>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#ifndef VL_KEYKIT_VERSION
#error "VL_KEYKIT_VERSION is set by meson.build"
#endif

struct vl_keykit_seed {
    vl::keykit::RecoverySeed seed;
};

struct vl_keykit_vault_key {
    vl::keykit::SecretBytes key;
    uint32_t version{};
    vl::keykit::Uid vault{};
};

struct vl_keykit_credential_key {
    vl::keykit::SecretBytes secret;
    std::array<uint8_t, 32> public_key{};
};

struct vl_keykit_credential {
    vl::keykit::SecretBytes secret;
};

namespace vl::keykit::capi {

namespace {

static_assert(static_cast<int>(account::Reason::Initial) == VL_KEYKIT_REASON_INITIAL &&
              static_cast<int>(account::Reason::Routine) == VL_KEYKIT_REASON_ROUTINE &&
              static_cast<int>(account::Reason::Compromise) == VL_KEYKIT_REASON_COMPROMISE);
static_assert(static_cast<int>(account::Link::Initial) == VL_KEYKIT_LINK_INITIAL &&
              static_cast<int>(account::Link::Rotation) == VL_KEYKIT_LINK_ROTATION &&
              static_cast<int>(account::Link::Replacement) == VL_KEYKIT_LINK_REPLACEMENT);
static_assert(static_cast<int>(kev1::Suite::X25519) == VL_KEYKIT_SUITE_X25519 &&
              static_cast<int>(kev1::Suite::P256) == VL_KEYKIT_SUITE_P256);
// The last code of each format: a code added to a C++ enum must be added to the header too (the tests check names).
static_assert(VL_KEYKIT_ERR_ACCOUNT_BAD_INSTALLATION_ID == 200 + static_cast<int>(account::ErrorCode::BadInstallationId));
static_assert(VL_KEYKIT_ERR_KEV1_BAD_KEY_VERSION == 300 + static_cast<int>(kev1::ErrorCode::BadKeyVersion));
static_assert(VL_KEYKIT_ERR_KAK1_SEED_MISMATCH == 400 + static_cast<int>(kak1::ErrorCode::SeedMismatch));
static_assert(VL_KEYKIT_ERR_LABEL_BAD_LABEL == 500 + static_cast<int>(label::ErrorCode::BadLabel));
static_assert(VL_KEYKIT_ERR_CREDENTIAL_AUTH_FAILED == 600 + static_cast<int>(credential::ErrorCode::AuthFailed));
static_assert(VL_KEYKIT_CREDENTIAL_SECRET_MAX_SIZE == credential::kMaxSecretSize &&
              VL_KEYKIT_CREDENTIAL_KEY_ID_MAX_SIZE == credential::kMaxKeyIdSize &&
              VL_KEYKIT_CREDENTIAL_SEALED_MAX_SIZE == credential::kPrefixSize + credential::kMaxSecretSize + 16);

constexpr std::pair<vl_keykit_status, const char*> kStatusNames[] = {
    {VL_KEYKIT_OK, "ok"},
    {VL_KEYKIT_ERR_INVALID_ARGUMENT, "invalid_argument"},
    {VL_KEYKIT_ERR_BUFFER_TOO_SMALL, "buffer_too_small"},
    {VL_KEYKIT_ERR_OUT_OF_MEMORY, "out_of_memory"},
    {VL_KEYKIT_ERR_INTERNAL, "internal"},
    {VL_KEYKIT_ERR_AGREEMENT_FAILED, "agreement_failed"},
    {VL_KEYKIT_ERR_BAD_FORMAT, "bad_format"},
    {VL_KEYKIT_ERR_SEED_MISMATCH, "seed_mismatch"},
    {VL_KEYKIT_ERR_SEED_BAD_LENGTH, "seed_bad_length"},
    {VL_KEYKIT_ERR_SEED_BAD_SYMBOL, "seed_bad_symbol"},
    {VL_KEYKIT_ERR_SEED_BAD_CHECK, "seed_bad_check"},
    {VL_KEYKIT_ERR_ACCOUNT_UNSUPPORTED_VERSION, "account_unsupported_version"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_STATEMENT, "account_bad_statement"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_PUBLIC_ID, "account_bad_public_id"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_GENERATION, "account_bad_generation"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_BASE64URL, "account_bad_base64url"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_KEY, "account_bad_key"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_PREVIOUS, "account_bad_previous"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_REASON, "account_bad_reason"},
    {VL_KEYKIT_ERR_ACCOUNT_ACCOUNT_MISMATCH, "account_account_mismatch"},
    {VL_KEYKIT_ERR_ACCOUNT_GENERATION_GAP, "account_generation_gap"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_SIGNATURE, "account_bad_signature"},
    {VL_KEYKIT_ERR_ACCOUNT_PREVIOUS_MISMATCH, "account_previous_mismatch"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_PREVIOUS_SIGNATURE, "account_bad_previous_signature"},
    {VL_KEYKIT_ERR_ACCOUNT_ROLLBACK, "account_rollback"},
    {VL_KEYKIT_ERR_ACCOUNT_PIN_MISMATCH, "account_pin_mismatch"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_POLICY, "account_bad_policy"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_SEQUENCE, "account_bad_sequence"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_ISSUED_AT, "account_bad_issued_at"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_RECIPIENT, "account_bad_recipient"},
    {VL_KEYKIT_ERR_ACCOUNT_RECIPIENT_ID_MISMATCH, "account_recipient_id_mismatch"},
    {VL_KEYKIT_ERR_ACCOUNT_UNSUPPORTED_SUITE, "account_unsupported_suite"},
    {VL_KEYKIT_ERR_ACCOUNT_UNSUPPORTED_CLASS, "account_unsupported_class"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_LABEL, "account_bad_label"},
    {VL_KEYKIT_ERR_ACCOUNT_UNSUPPORTED_SCOPE, "account_unsupported_scope"},
    {VL_KEYKIT_ERR_ACCOUNT_UNSORTED_RECIPIENTS, "account_unsorted_recipients"},
    {VL_KEYKIT_ERR_ACCOUNT_TOO_MANY_RECIPIENTS, "account_too_many_recipients"},
    {VL_KEYKIT_ERR_ACCOUNT_GENERATION_MISMATCH, "account_generation_mismatch"},
    {VL_KEYKIT_ERR_ACCOUNT_ACCOUNT_KEY_LISTED, "account_account_key_listed"},
    {VL_KEYKIT_ERR_ACCOUNT_BAD_INSTALLATION_ID, "account_bad_installation_id"},
    {VL_KEYKIT_ERR_KEV1_BAD_MAGIC, "kev1_bad_magic"},
    {VL_KEYKIT_ERR_KEV1_UNSUPPORTED_VERSION, "kev1_unsupported_version"},
    {VL_KEYKIT_ERR_KEV1_UNSUPPORTED_SUITE, "kev1_unsupported_suite"},
    {VL_KEYKIT_ERR_KEV1_BAD_PURPOSE, "kev1_bad_purpose"},
    {VL_KEYKIT_ERR_KEV1_UNSUPPORTED_RECIPIENT_CLASS, "kev1_unsupported_recipient_class"},
    {VL_KEYKIT_ERR_KEV1_RESERVED_NONZERO, "kev1_reserved_nonzero"},
    {VL_KEYKIT_ERR_KEV1_VAULT_MISMATCH, "kev1_vault_mismatch"},
    {VL_KEYKIT_ERR_KEV1_RECIPIENT_MISMATCH, "kev1_recipient_mismatch"},
    {VL_KEYKIT_ERR_KEV1_BAD_LENGTH, "kev1_bad_length"},
    {VL_KEYKIT_ERR_KEV1_BAD_EPHEMERAL, "kev1_bad_ephemeral"},
    {VL_KEYKIT_ERR_KEV1_WRAP_AUTH_FAILED, "kev1_wrap_auth_failed"},
    {VL_KEYKIT_ERR_KEV1_BAD_KEY_VERSION, "kev1_bad_key_version"},
    {VL_KEYKIT_ERR_KAK1_BAD_MAGIC, "kak1_bad_magic"},
    {VL_KEYKIT_ERR_KAK1_UNSUPPORTED_VERSION, "kak1_unsupported_version"},
    {VL_KEYKIT_ERR_KAK1_UNSUPPORTED_SUITE, "kak1_unsupported_suite"},
    {VL_KEYKIT_ERR_KAK1_ACCOUNT_MISMATCH, "kak1_account_mismatch"},
    {VL_KEYKIT_ERR_KAK1_KEY_MISMATCH, "kak1_key_mismatch"},
    {VL_KEYKIT_ERR_KAK1_RECIPIENT_MISMATCH, "kak1_recipient_mismatch"},
    {VL_KEYKIT_ERR_KAK1_BAD_LENGTH, "kak1_bad_length"},
    {VL_KEYKIT_ERR_KAK1_BAD_EPHEMERAL, "kak1_bad_ephemeral"},
    {VL_KEYKIT_ERR_KAK1_WRAP_AUTH_FAILED, "kak1_wrap_auth_failed"},
    {VL_KEYKIT_ERR_KAK1_SEED_MISMATCH, "kak1_seed_mismatch"},
    {VL_KEYKIT_ERR_LABEL_BAD_MAGIC, "label_bad_magic"},
    {VL_KEYKIT_ERR_LABEL_UNSUPPORTED_VERSION, "label_unsupported_version"},
    {VL_KEYKIT_ERR_LABEL_UNSUPPORTED_SUITE, "label_unsupported_suite"},
    {VL_KEYKIT_ERR_LABEL_ACCOUNT_MISMATCH, "label_account_mismatch"},
    {VL_KEYKIT_ERR_LABEL_VAULT_MISMATCH, "label_vault_mismatch"},
    {VL_KEYKIT_ERR_LABEL_KEY_MISMATCH, "label_key_mismatch"},
    {VL_KEYKIT_ERR_LABEL_BAD_LENGTH, "label_bad_length"},
    {VL_KEYKIT_ERR_LABEL_BAD_EPHEMERAL, "label_bad_ephemeral"},
    {VL_KEYKIT_ERR_LABEL_AUTH_FAILED, "label_auth_failed"},
    {VL_KEYKIT_ERR_LABEL_BAD_LABEL, "label_bad_label"},
    {VL_KEYKIT_ERR_PROVENANCE_BAD_KEY, "provenance_bad_key"},
    {VL_KEYKIT_ERR_PROVENANCE_BAD_VAULT_ID, "provenance_bad_vault_id"},
    {VL_KEYKIT_ERR_PROVENANCE_BAD_NODE_ID, "provenance_bad_node_id"},
    {VL_KEYKIT_ERR_PROVENANCE_BAD_KEY_CHECK, "provenance_bad_key_check"},
    {VL_KEYKIT_ERR_PROVENANCE_BAD_SEED, "provenance_bad_seed"},
    {VL_KEYKIT_ERR_CREDENTIAL_BAD_MAGIC, "credential_bad_magic"},
    {VL_KEYKIT_ERR_CREDENTIAL_UNSUPPORTED_VERSION, "credential_unsupported_version"},
    {VL_KEYKIT_ERR_CREDENTIAL_UNSUPPORTED_SUITE, "credential_unsupported_suite"},
    {VL_KEYKIT_ERR_CREDENTIAL_BAD_LENGTH, "credential_bad_length"},
    {VL_KEYKIT_ERR_CREDENTIAL_BAD_EPHEMERAL, "credential_bad_ephemeral"},
    {VL_KEYKIT_ERR_CREDENTIAL_AUTH_FAILED, "credential_auth_failed"},
};

// Zeroes a string that held a secret (the exported recovery code) when it leaves scope.
struct WipeText {
    std::string& text;
    ~WipeText() { wipe(text); }
};

// A status the C API returns from inside a call (the C++ library has no exception for it).
struct Status {
    vl_keykit_status code;
};

[[noreturn]] void fail(const vl_keykit_status code) { throw Status{code}; }

void need(const void* p) {
    if (!p) fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
}

std::string_view textIn(const char* p, const std::size_t n) {
    if (!p) {
        if (n) fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
        return {};
    }
    return {p, n};
}

std::span<const uint8_t> bytesIn(const uint8_t* p, const std::size_t n) {
    if (!p) {
        if (n) fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
        return {};
    }
    return {p, n};
}

template <std::size_t N>
std::array<uint8_t, N> fixedIn(const uint8_t* p) {
    need(p);
    std::array<uint8_t, N> out{};
    std::memcpy(out.data(), p, N);
    return out;
}

// The length in/out convention: nothing is written unless all of `data` fits.
vl_keykit_status put(const std::span<const uint8_t> data, uint8_t* out, std::size_t* outLen) {
    need(outLen);
    if (*outLen < data.size() || (!out && !data.empty())) {
        *outLen = data.size();
        return VL_KEYKIT_ERR_BUFFER_TOO_SMALL;
    }
    if (!data.empty()) std::memcpy(out, data.data(), data.size());
    *outLen = data.size();
    return VL_KEYKIT_OK;
}

vl_keykit_status putText(const std::string_view text, char* out, std::size_t* outLen) {
    return put(detail::viewBytes(text), reinterpret_cast<uint8_t*>(out), outLen);
}

template <std::size_t N>
void fixedOut(const std::span<const uint8_t> data, uint8_t* out) {
    if (data.size() != N) fail(VL_KEYKIT_ERR_INTERNAL);
    std::memcpy(out, data.data(), N);
}

account::KeyStatement statementIn(const char* p, const std::size_t n) { return account::parseStatement(textIn(p, n)); }

const RecoverySeed& seedIn(const vl_keykit_seed* seed) {
    need(seed);
    return seed->seed;
}

// The seed is the key of the statement: its derived public keys are the statement's.
bool seedIs(const RecoverySeed& seed, const account::KeyStatement& statement) {
    return std::ranges::equal(seed.x25519PublicKey(), statement.x25519_public) &&
           std::ranges::equal(seed.ed25519PublicKey(), statement.ed25519_public);
}

void requireSeed(const RecoverySeed& seed, const account::KeyStatement& statement) {
    if (!seedIs(seed, statement)) fail(VL_KEYKIT_ERR_SEED_MISMATCH);
}

vl_keykit_status seedStatus(const std::string& code) {
    if (code == "bad_length") return VL_KEYKIT_ERR_SEED_BAD_LENGTH;
    if (code == "bad_symbol") return VL_KEYKIT_ERR_SEED_BAD_SYMBOL;
    if (code == "bad_check") return VL_KEYKIT_ERR_SEED_BAD_CHECK;
    return VL_KEYKIT_ERR_INTERNAL;
}

// OpenSSL is initialized once without its configuration file (openssl.cnf in OPENSSLDIR, or OPENSSL_CONF): an app
// embedding this library statically must not take providers or settings from a file on the machine (for Homebrew's
// build, one the user's other programs can write). Has no effect when the host initialized OpenSSL already.
bool initOpenSsl() noexcept { return OPENSSL_init_crypto(OPENSSL_INIT_NO_LOAD_CONFIG, nullptr) == 1; }

// Runs `body` and maps whatever it throws to a status; nothing escapes.
template <typename Body>
vl_keykit_status guarded(Body&& body) noexcept {
    static const bool initialized = initOpenSsl();  // thread-safe, once
    if (!initialized) return VL_KEYKIT_ERR_INTERNAL;
    try {
        return body();
    } catch (const Status& s) {
        return s.code;
    } catch (const account::Error& e) {
        return 200 + static_cast<vl_keykit_status>(e.code());
    } catch (const kev1::Error& e) {
        return 300 + static_cast<vl_keykit_status>(e.code());
    } catch (const kak1::Error& e) {
        return 400 + static_cast<vl_keykit_status>(e.code());
    } catch (const label::Error& e) {
        return 500 + static_cast<vl_keykit_status>(e.code());
    } catch (const credential::Error& e) {
        return 600 + static_cast<vl_keykit_status>(e.code());
    } catch (const provenance::Error& e) {
        return 700 + static_cast<vl_keykit_status>(e.code());
    } catch (const SeedError& e) {
        return seedStatus(e.code());
    } catch (const std::invalid_argument&) {
        return VL_KEYKIT_ERR_INVALID_ARGUMENT;
    } catch (const std::bad_alloc&) {
        return VL_KEYKIT_ERR_OUT_OF_MEMORY;
    } catch (...) {
        return VL_KEYKIT_ERR_INTERNAL;
    }
}

vl_keykit_seed* newSeed(RecoverySeed seed) {
    auto* out = new (std::nothrow) vl_keykit_seed{std::move(seed)};
    if (!out) fail(VL_KEYKIT_ERR_OUT_OF_MEMORY);
    return out;
}

// Sets *out to NULL first, so a failure leaves no stale handle behind.
template <typename Handle>
Handle** handleOut(Handle** out) {
    need(out);
    *out = nullptr;
    return out;
}

// A one-time key's handle: the secret, and its public key derived once.
vl_keykit_credential_key* newCredentialKey(SecretBytes secret) {
    const auto pub = kev1::publicKeyOf(kev1::Suite::X25519, secret.bytes());
    auto* out = new (std::nothrow) vl_keykit_credential_key{.secret = std::move(secret), .public_key = {}};
    if (!out) fail(VL_KEYKIT_ERR_OUT_OF_MEMORY);
    if (pub.size() != out->public_key.size()) {
        delete out;
        fail(VL_KEYKIT_ERR_INTERNAL);
    }
    std::memcpy(out->public_key.data(), pub.data(), pub.size());
    return out;
}

credential::Context credentialContextIn(const char* installationId, const std::size_t installationIdLen,
                                        const uint8_t* vaultUid, const char* keyId, const std::size_t keyIdLen) {
    credential::Context c{.installation_id = std::string(textIn(installationId, installationIdLen)),
                          .vault_uid = fixedIn<16>(vaultUid),
                          .key_id = std::string(textIn(keyId, keyIdLen))};
    credential::validate(c);
    return c;
}

std::vector<account::SignedStatement> chainIn(const vl_keykit_signed_statement* chain, const std::size_t count) {
    if (count && !chain) fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
    std::vector<account::SignedStatement> out;
    out.reserve(count);
    for (std::size_t i = 0; i < count; ++i) {
        account::SignedStatement s{.statement = std::string(textIn(chain[i].statement, chain[i].statement_len)),
                                   .signature = fixedIn<account::kSignatureSize>(chain[i].signature)};
        if (chain[i].previous_signature) s.previous_signature = fixedIn<account::kSignatureSize>(chain[i].previous_signature);
        out.push_back(std::move(s));
    }
    return out;
}

std::vector<account::VerifiedGeneration> verifiedChain(const vl_keykit_signed_statement* chain, const std::size_t count,
                                                       const char* publicId, const std::size_t publicIdLen,
                                                       std::size_t* failedIndex) {
    if (failedIndex) *failedIndex = std::numeric_limits<std::size_t>::max();
    const auto items = chainIn(chain, count);
    const auto id = textIn(publicId, publicIdLen);
    try {
        return account::verifyChain(items, id);
    } catch (const account::Error& e) {
        if (failedIndex && e.index()) *failedIndex = *e.index();
        throw;
    }
}

}

}

namespace vlkk = vl::keykit;
namespace vlkk_capi = vl::keykit::capi;

extern "C" {

const char* vl_keykit_status_name(const vl_keykit_status status) {
    for (const auto& [code, name] : vlkk_capi::kStatusNames)
        if (code == status) return name;
    return "unknown";
}

const char* vl_keykit_version(void) { return VL_KEYKIT_VERSION; }

// ---- seed ----

vl_keykit_status vl_keykit_seed_generate(vl_keykit_seed** out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        auto** slot = vlkk_capi::handleOut(out);  // first: in `a = b`, b is evaluated before a
        *slot = vlkk_capi::newSeed(vlkk::RecoverySeed::generate());
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_seed_parse(const char* text, const size_t textLen, vl_keykit_seed** out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        auto** slot = vlkk_capi::handleOut(out);
        *slot = vlkk_capi::newSeed(vlkk::RecoverySeed::parse(vlkk_capi::textIn(text, textLen)));
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_seed_export_text(const vl_keykit_seed* seed, char* out, size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        std::string text = vlkk_capi::seedIn(seed).text();
        const vlkk_capi::WipeText wipeText{text};
        return vlkk_capi::putText(text, out, outLen);
    });
}

vl_keykit_status vl_keykit_seed_public_keys(const vl_keykit_seed* seed, uint8_t x25519Public[32],
                                            uint8_t ed25519Public[32]) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto& s = vlkk_capi::seedIn(seed);
        if (x25519Public) vlkk_capi::fixedOut<32>(s.x25519PublicKey(), x25519Public);
        if (ed25519Public) vlkk_capi::fixedOut<32>(s.ed25519PublicKey(), ed25519Public);
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_seed_matches(const vl_keykit_seed* seed, const char* statement, const size_t statementLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto& s = vlkk_capi::seedIn(seed);
        vlkk_capi::requireSeed(s, vlkk_capi::statementIn(statement, statementLen));
        return VL_KEYKIT_OK;
    });
}

void vl_keykit_seed_free(vl_keykit_seed* seed) { delete seed; }

// ---- statements ----

vl_keykit_status vl_keykit_statement_build(const vl_keykit_seed* seed, const char* publicId, const size_t publicIdLen,
                                           const uint32_t generation, const uint8_t* previousFingerprint,
                                           const int32_t reason, char* out, size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto& s = vlkk_capi::seedIn(seed);
        if (reason < VL_KEYKIT_REASON_INITIAL || reason > VL_KEYKIT_REASON_COMPROMISE)
            vlkk_capi::fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
        std::optional<vlkk::account::Fingerprint> previous;
        if (previousFingerprint) previous = vlkk_capi::fixedIn<vlkk::account::kFingerprintSize>(previousFingerprint);
        const auto statement = vlkk::account::statementFor(s, vlkk_capi::textIn(publicId, publicIdLen), generation,
                                                           previous, static_cast<vlkk::account::Reason>(reason));
        return vlkk_capi::putText(vlkk::account::encode(statement), out, outLen);
    });
}

vl_keykit_status vl_keykit_statement_sign(const char* statement, const size_t statementLen, const vl_keykit_seed* seed,
                                          const vl_keykit_seed* previous, uint8_t signature[64],
                                          uint8_t previousSignature[64]) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto st = vlkk_capi::statementIn(statement, statementLen);
        const auto& s = vlkk_capi::seedIn(seed);
        vlkk_capi::need(signature);
        vlkk_capi::requireSeed(s, st);
        const vlkk::RecoverySeed* before = nullptr;
        if (previous) {
            vlkk_capi::need(previousSignature);
            if (st.generation < 2) vlkk_capi::fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
            before = &previous->seed;
            // The previous generation's statement, as far as its fingerprint goes (its first five lines).
            const vlkk::account::KeyStatement prior{
                .public_id = st.public_id,
                .generation = st.generation - 1,
                .x25519_public = vlkk_capi::fixedIn<32>(before->x25519PublicKey().data()),
                .ed25519_public = vlkk_capi::fixedIn<32>(before->ed25519PublicKey().data())};
            if (vlkk::account::fingerprint(prior) != *st.previous) vlkk_capi::fail(VL_KEYKIT_ERR_SEED_MISMATCH);
        }
        const auto signedStatement = vlkk::account::sign(st, s, before);
        std::memcpy(signature, signedStatement.signature.data(), signedStatement.signature.size());
        if (before) std::memcpy(previousSignature, signedStatement.previous_signature->data(), 64);
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_statement_parse(const char* statement, const size_t statementLen,
                                           vl_keykit_statement_info* out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto st = vlkk_capi::statementIn(statement, statementLen);
        vlkk_capi::need(out);
        vl_keykit_statement_info info{};
        const auto id = vlkk::account::parsePublicId(st.public_id);
        if (!id) vlkk_capi::fail(VL_KEYKIT_ERR_INTERNAL);
        std::memcpy(info.public_id, id->data(), id->size());
        info.generation = st.generation;
        info.reason = static_cast<int32_t>(st.reason);
        std::memcpy(info.x25519_public, st.x25519_public.data(), 32);
        std::memcpy(info.ed25519_public, st.ed25519_public.data(), 32);
        info.has_previous = st.previous ? 1 : 0;
        if (st.previous) std::memcpy(info.previous_fingerprint, st.previous->data(), 16);
        const auto fp = vlkk::account::fingerprint(st);
        std::memcpy(info.fingerprint, fp.data(), fp.size());
        *out = info;
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_fingerprint_text(const uint8_t fingerprint[16], char* out, size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto fp = vlkk_capi::fixedIn<vlkk::account::kFingerprintSize>(fingerprint);
        return vlkk_capi::putText(vlkk::account::fingerprintText(fp), out, outLen);
    });
}

vl_keykit_status vl_keykit_fingerprint_parse(const char* text, const size_t textLen, const int32_t lenient,
                                             uint8_t fingerprint[16]) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto t = vlkk_capi::textIn(text, textLen);
        vlkk_capi::need(fingerprint);
        const auto fp = vlkk::account::parseFingerprint(t, lenient != 0);
        if (!fp) return VL_KEYKIT_ERR_BAD_FORMAT;
        std::memcpy(fingerprint, fp->data(), fp->size());
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_public_id_bytes(const char* publicId, const size_t publicIdLen, uint8_t out[16]) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto t = vlkk_capi::textIn(publicId, publicIdLen);
        vlkk_capi::need(out);
        const auto id = vlkk::account::parsePublicId(t);
        if (!id) return VL_KEYKIT_ERR_BAD_FORMAT;
        std::memcpy(out, id->data(), id->size());
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_chain_verify(const vl_keykit_signed_statement* chain, const size_t count,
                                        const char* publicId, const size_t publicIdLen, vl_keykit_generation* out,
                                        size_t* failedIndex) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto verified = vlkk_capi::verifiedChain(chain, count, publicId, publicIdLen, failedIndex);
        if (out) {
            for (std::size_t i = 0; i < verified.size(); ++i) {
                const auto& g = verified[i];
                vl_keykit_generation row{};
                row.generation = g.statement.generation;
                row.reason = static_cast<int32_t>(g.statement.reason);
                row.link = static_cast<int32_t>(g.link);
                std::memcpy(row.fingerprint, g.fingerprint.data(), 16);
                std::memcpy(row.x25519_public, g.statement.x25519_public.data(), 32);
                std::memcpy(row.ed25519_public, g.statement.ed25519_public.data(), 32);
                out[i] = row;
            }
        }
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_chain_follow(const vl_keykit_signed_statement* chain, const size_t count,
                                        const char* publicId, const size_t publicIdLen, const uint32_t pinGeneration,
                                        const uint8_t pinFingerprint[16], uint32_t* accepted, uint32_t* newest) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const vlkk::account::Pin pin{.generation = pinGeneration,
                                     .fingerprint = vlkk_capi::fixedIn<16>(pinFingerprint)};
        vlkk_capi::need(accepted);
        vlkk_capi::need(newest);
        const auto verified = vlkk_capi::verifiedChain(chain, count, publicId, publicIdLen, nullptr);
        const auto result = vlkk::account::follow(pin, verified);
        *accepted = result.accepted;
        *newest = result.newest;
        return VL_KEYKIT_OK;
    });
}

// ---- holder proofs ----

vl_keykit_status vl_keykit_holder_proof_sign(const char* statement, const size_t statementLen,
                                             const vl_keykit_seed* seed, const char* installationId,
                                             const size_t installationIdLen, const uint16_t suite,
                                             const uint8_t* holderPublicKey, const size_t holderPublicKeyLen,
                                             uint8_t proof[64]) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto st = vlkk_capi::statementIn(statement, statementLen);
        const auto& s = vlkk_capi::seedIn(seed);
        vlkk_capi::need(proof);
        const auto installation = vlkk_capi::textIn(installationId, installationIdLen);
        const auto key = vlkk_capi::bytesIn(holderPublicKey, holderPublicKeyLen);
        // The input checks come first, as for the verifier; then the seed.
        (void)vlkk::account::holderMessage(st, installation, static_cast<vlkk::kev1::Suite>(suite), key);
        vlkk_capi::requireSeed(s, st);
        const auto sig = vlkk::account::signHolderProof(st, s, installation, static_cast<vlkk::kev1::Suite>(suite), key);
        std::memcpy(proof, sig.data(), sig.size());
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_holder_proof_verify(const char* statement, const size_t statementLen,
                                               const char* installationId, const size_t installationIdLen,
                                               const uint16_t suite, const uint8_t* holderPublicKey,
                                               const size_t holderPublicKeyLen, const uint8_t proof[64]) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto st = vlkk_capi::statementIn(statement, statementLen);
        const auto sig = vlkk_capi::fixedIn<vlkk::account::kSignatureSize>(proof);
        vlkk::account::checkHolderProof(st, vlkk_capi::textIn(installationId, installationIdLen),
                                        static_cast<vlkk::kev1::Suite>(suite),
                                        vlkk_capi::bytesIn(holderPublicKey, holderPublicKeyLen), sig);
        return VL_KEYKIT_OK;
    });
}

// ---- KAK1 ----

vl_keykit_status vl_keykit_kak1_wrap(const vl_keykit_seed* seed, const char* statement, const size_t statementLen,
                                     const uint16_t suite, const uint8_t* holderPublicKey,
                                     const size_t holderPublicKeyLen, uint8_t* out, size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto& s = vlkk_capi::seedIn(seed);
        const auto st = vlkk_capi::statementIn(statement, statementLen);
        vlkk_capi::need(outLen);
        vlkk_capi::requireSeed(s, st);
        const auto env = vlkk::kak1::wrap(s, st, static_cast<vlkk::kev1::Suite>(suite),
                                          vlkk_capi::bytesIn(holderPublicKey, holderPublicKeyLen));
        return vlkk_capi::put(env, out, outLen);
    });
}

vl_keykit_status vl_keykit_kak1_unwrap(const uint8_t* envelope, const size_t envelopeLen,
                                       const uint8_t* holderSecretKey, const size_t holderSecretKeyLen,
                                       const uint16_t suite, const char* statement, const size_t statementLen,
                                       vl_keykit_seed** out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        auto** slot = vlkk_capi::handleOut(out);
        const auto env = vlkk_capi::bytesIn(envelope, envelopeLen);
        const auto sk = vlkk_capi::bytesIn(holderSecretKey, holderSecretKeyLen);
        const auto st = vlkk_capi::statementIn(statement, statementLen);
        *slot = vlkk_capi::newSeed(vlkk::kak1::unwrap(env, sk, static_cast<vlkk::kev1::Suite>(suite), st));
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_kak1_unwrap_with(const uint8_t* envelope, const size_t envelopeLen,
                                            const uint8_t* holderPublicKey, const size_t holderPublicKeyLen,
                                            const uint16_t suite, const char* statement, const size_t statementLen,
                                            const vl_keykit_agree_fn agree, void* context, vl_keykit_seed** out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        auto** slot = vlkk_capi::handleOut(out);
        if (!agree) vlkk_capi::fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
        const auto env = vlkk_capi::bytesIn(envelope, envelopeLen);
        const auto pk = vlkk_capi::bytesIn(holderPublicKey, holderPublicKeyLen);
        const auto st = vlkk_capi::statementIn(statement, statementLen);
        bool refused = false;
        const vlkk::kak1::Agreement agreement =
            [&](const std::span<const uint8_t> epk) -> std::optional<vlkk::SecretBytes> {
            std::array<uint8_t, VL_KEYKIT_SHARED_SECRET_SIZE> z{};
            const vlkk::detail::WipeOnExit<std::array<uint8_t, VL_KEYKIT_SHARED_SECRET_SIZE>> wipeZ{z};
            if (agree(context, epk.data(), epk.size(), z.data()) != 0) {
                refused = true;
                return std::nullopt;
            }
            return vlkk::SecretBytes(z);
        };
        try {
            *slot = vlkk_capi::newSeed(
                vlkk::kak1::unwrapWith(env, pk, static_cast<vlkk::kev1::Suite>(suite), st, agreement));
        } catch (const vlkk::kak1::Error& e) {
            if (refused && e.code() == vlkk::kak1::ErrorCode::BadEphemeral) return VL_KEYKIT_ERR_AGREEMENT_FAILED;
            throw;
        }
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_kak1_inspect(const uint8_t* envelope, const size_t envelopeLen, vl_keykit_kak1_header* out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto h = vlkk::kak1::inspect(vlkk_capi::bytesIn(envelope, envelopeLen));
        vlkk_capi::need(out);
        vl_keykit_kak1_header header{};
        header.suite = h.suite;
        header.generation = h.generation;
        std::memcpy(header.public_id, h.public_id.data(), 16);
        std::memcpy(header.fingerprint, h.fingerprint.data(), 16);
        std::memcpy(header.recipient_id, h.recipient_id.data(), 32);
        *out = header;
        return VL_KEYKIT_OK;
    });
}

// ---- vault labels ----

vl_keykit_status vl_keykit_label_seal(const char* name, const size_t nameLen, const char* statement,
                                      const size_t statementLen, const uint8_t vaultUid[16], uint8_t* out,
                                      size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto n = vlkk_capi::textIn(name, nameLen);
        const auto st = vlkk_capi::statementIn(statement, statementLen);
        const auto uid = vlkk_capi::fixedIn<16>(vaultUid);
        vlkk_capi::need(outLen);
        return vlkk_capi::put(vlkk::label::seal(n, st, uid), out, outLen);
    });
}

vl_keykit_status vl_keykit_label_open(const uint8_t* sealed, const size_t sealedLen, const vl_keykit_seed* seed,
                                      const char* statement, const size_t statementLen, const uint8_t vaultUid[16],
                                      char* name, size_t* nameLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto bytes = vlkk_capi::bytesIn(sealed, sealedLen);
        const auto& s = vlkk_capi::seedIn(seed);
        const auto st = vlkk_capi::statementIn(statement, statementLen);
        const auto uid = vlkk_capi::fixedIn<16>(vaultUid);
        vlkk_capi::need(nameLen);
        const auto secret = s.x25519SecretKey();
        return vlkk_capi::putText(vlkk::label::open(bytes, secret.bytes(), st, uid), name, nameLen);
    });
}

// ---- recovery policy ----

vl_keykit_status vl_keykit_policy_sign(const vl_keykit_seed* seed, const char* statement, const size_t statementLen,
                                       const uint32_t sequence, const char* issuedAt, const size_t issuedAtLen,
                                       const vl_keykit_policy_recipient* recipients, const size_t recipientCount,
                                       char* policy, size_t* policyLen, uint8_t signature[64]) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto& s = vlkk_capi::seedIn(seed);
        const auto st = vlkk_capi::statementIn(statement, statementLen);
        vlkk_capi::need(policyLen);
        vlkk_capi::need(signature);
        if (recipientCount && !recipients) vlkk_capi::fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
        if (recipientCount > vlkk::account::kMaxPolicyRecipients) vlkk_capi::fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
        vlkk_capi::requireSeed(s, st);
        vlkk::account::RecoveryPolicy p{.public_id = st.public_id,
                                        .sequence = sequence,
                                        .generation = st.generation,
                                        .issued_at = std::string(vlkk_capi::textIn(issuedAt, issuedAtLen))};
        for (std::size_t i = 0; i < recipientCount; ++i)
            p.recipients.push_back({.x25519_public = vlkk_capi::fixedIn<32>(recipients[i].x25519_public),
                                    .label = std::string(vlkk_capi::textIn(recipients[i].label, recipients[i].label_len))});
        const auto signedPolicy = vlkk::account::signPolicy(p, s, st);
        const auto status = vlkk_capi::putText(signedPolicy.policy, policy, policyLen);
        if (status == VL_KEYKIT_OK) std::memcpy(signature, signedPolicy.signature.data(), signedPolicy.signature.size());
        return status;
    });
}

vl_keykit_status vl_keykit_policy_verify(const char* policy, const size_t policyLen, const uint8_t signature[64],
                                         const char* statement, const size_t statementLen, vl_keykit_policy_info* out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const vlkk::account::SignedPolicy sp{.policy = std::string(vlkk_capi::textIn(policy, policyLen)),
                                             .signature = vlkk_capi::fixedIn<64>(signature)};
        const auto st = vlkk_capi::statementIn(statement, statementLen);
        vlkk_capi::need(out);
        const auto v = vlkk::account::verifyPolicy(sp, st);
        vl_keykit_policy_info info{};
        info.sequence = v.policy.sequence;
        info.generation = v.policy.generation;
        info.recipient_count = static_cast<uint32_t>(v.policy.recipients.size());
        std::memcpy(info.hash, v.hash.data(), v.hash.size());
        *out = info;
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_policy_recipient_at(const char* policy, const size_t policyLen, const size_t index,
                                               uint8_t x25519Public[32], char* label, size_t* labelLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto p = vlkk::account::parsePolicy(vlkk_capi::textIn(policy, policyLen));
        vlkk_capi::need(x25519Public);
        vlkk_capi::need(labelLen);
        if (index >= p.recipients.size()) vlkk_capi::fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
        const auto& r = p.recipients[index];
        const auto status = vlkk_capi::putText(r.label, label, labelLen);
        if (status == VL_KEYKIT_OK) std::memcpy(x25519Public, r.x25519_public.data(), r.x25519_public.size());
        return status;
    });
}

// ---- KEV1 and vault keys ----

vl_keykit_status vl_keykit_kev1_unwrap(const uint8_t* envelope, const size_t envelopeLen, const vl_keykit_seed* seed,
                                       const uint8_t vaultUid[16], vl_keykit_vault_key** out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        auto** slot = vlkk_capi::handleOut(out);
        const auto env = vlkk_capi::bytesIn(envelope, envelopeLen);
        const auto& s = vlkk_capi::seedIn(seed);
        const auto uid = vlkk_capi::fixedIn<16>(vaultUid);
        const auto secret = s.x25519SecretKey();
        auto unwrapped = vlkk::kev1::unwrap(env, secret.bytes(), vlkk::kev1::Suite::X25519, uid);
        auto* key = new (std::nothrow)
            vl_keykit_vault_key{.key = std::move(unwrapped.key), .version = unwrapped.key_version, .vault = uid};
        if (!key) vlkk_capi::fail(VL_KEYKIT_ERR_OUT_OF_MEMORY);
        *slot = key;
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_kev1_wrap(const vl_keykit_vault_key* key, const uint16_t suite,
                                     const uint8_t* recipientPublicKey, const size_t recipientPublicKeyLen,
                                     uint8_t* out, size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        vlkk_capi::need(key);
        vlkk_capi::need(outLen);
        const auto env = vlkk::kev1::wrap(key->key.bytes(), static_cast<vlkk::kev1::Suite>(suite), key->version,
                                          key->vault, vlkk_capi::bytesIn(recipientPublicKey, recipientPublicKeyLen));
        return vlkk_capi::put(env, out, outLen);
    });
}

uint32_t vl_keykit_vault_key_version(const vl_keykit_vault_key* key) { return key ? key->version : 0; }

void vl_keykit_vault_key_free(vl_keykit_vault_key* key) { delete key; }

vl_keykit_status vl_keykit_kev1_inspect(const uint8_t* envelope, const size_t envelopeLen, vl_keykit_kev1_header* out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto h = vlkk::kev1::inspect(vlkk_capi::bytesIn(envelope, envelopeLen));
        vlkk_capi::need(out);
        vl_keykit_kev1_header header{};
        header.suite = h.suite;
        header.purpose = h.purpose;
        header.recipient_class = h.recipient_class;
        header.key_version = h.key_version;
        std::memcpy(header.vault_uid, h.vault_uid.data(), 16);
        std::memcpy(header.recipient_id, h.recipient_id.data(), 32);
        *out = header;
        return VL_KEYKIT_OK;
    });
}

int32_t vl_keykit_kev1_skipped_by_restore(const vl_keykit_status status) {
    if (status < 300 || status > VL_KEYKIT_ERR_KEV1_BAD_KEY_VERSION) return 0;
    return vlkk::kev1::skippedByRestore(static_cast<vlkk::kev1::ErrorCode>(status - 300)) ? 1 : 0;
}

vl_keykit_status vl_keykit_recipient_id(const uint8_t* publicKey, const size_t publicKeyLen, uint8_t out[32]) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto key = vlkk_capi::bytesIn(publicKey, publicKeyLen);
        vlkk_capi::need(out);
        const auto id = vlkk::kev1::recipientId(key);
        std::memcpy(out, id.data(), id.size());
        return VL_KEYKIT_OK;
    });
}

// ---- comparison codes ----

vl_keykit_status vl_keykit_request_code(const char* requestId, const size_t requestIdLen, const char* payload,
                                        const size_t payloadLen, char* out, size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        return vlkk_capi::putText(vlkk::codes::requestCode(vlkk_capi::textIn(requestId, requestIdLen),
                                                           vlkk_capi::textIn(payload, payloadLen)),
                                  out, outLen);
    });
}

vl_keykit_status vl_keykit_transfer_code(const char* publicId, const size_t publicIdLen, const uint8_t* temporaryKey,
                                         const size_t temporaryKeyLen, char* out, size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        return vlkk_capi::putText(vlkk::codes::transferCode(vlkk_capi::textIn(publicId, publicIdLen),
                                                            vlkk_capi::bytesIn(temporaryKey, temporaryKeyLen)),
                                  out, outLen);
    });
}

vl_keykit_status vl_keykit_restore_code(const char* vaultUid, const size_t vaultUidLen, const uint8_t* temporaryKey,
                                        const size_t temporaryKeyLen, char* out, size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        return vlkk_capi::putText(vlkk::codes::restoreCode(vlkk_capi::textIn(vaultUid, vaultUidLen),
                                                           vlkk_capi::bytesIn(temporaryKey, temporaryKeyLen)),
                                  out, outLen);
    });
}

// ---- sealed storage credentials ----

vl_keykit_status vl_keykit_credential_key_generate(vl_keykit_credential_key** out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        auto** slot = vlkk_capi::handleOut(out);
        *slot = vlkk_capi::newCredentialKey(vlkk::SecretBytes::random(vlkk::kev1::kX25519KeySize));
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_credential_key_from_secret(const uint8_t secretKey[32], vl_keykit_credential_key** out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        auto** slot = vlkk_capi::handleOut(out);
        vlkk_capi::need(secretKey);
        *slot = vlkk_capi::newCredentialKey(vlkk::SecretBytes(std::span<const uint8_t>(secretKey, vlkk::kev1::kX25519KeySize)));
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_credential_key_public(const vl_keykit_credential_key* key, uint8_t publicKey[32]) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        vlkk_capi::need(key);
        vlkk_capi::need(publicKey);
        std::memcpy(publicKey, key->public_key.data(), key->public_key.size());
        return VL_KEYKIT_OK;
    });
}

void vl_keykit_credential_key_free(vl_keykit_credential_key* key) { delete key; }

vl_keykit_status vl_keykit_credential_open(const uint8_t* sealed, const size_t sealedLen,
                                           const vl_keykit_credential_key* key, const char* installationId,
                                           const size_t installationIdLen, const uint8_t vaultUid[16],
                                           const char* keyId, const size_t keyIdLen, vl_keykit_credential** out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        auto** slot = vlkk_capi::handleOut(out);
        const auto bytes = vlkk_capi::bytesIn(sealed, sealedLen);
        vlkk_capi::need(key);
        const auto context = vlkk_capi::credentialContextIn(installationId, installationIdLen, vaultUid, keyId, keyIdLen);
        auto secret = vlkk::credential::open(bytes, key->secret.bytes(), context);
        auto* opened = new (std::nothrow) vl_keykit_credential{.secret = std::move(secret)};
        if (!opened) vlkk_capi::fail(VL_KEYKIT_ERR_OUT_OF_MEMORY);
        *slot = opened;
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_credential_secret(const vl_keykit_credential* credential, uint8_t* out, size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        vlkk_capi::need(credential);
        return vlkk_capi::put(credential->secret.bytes(), out, outLen);
    });
}

void vl_keykit_credential_free(vl_keykit_credential* credential) { delete credential; }

vl_keykit_status vl_keykit_credential_seal(const uint8_t* secret, const size_t secretLen, const char* installationId,
                                           const size_t installationIdLen, const uint8_t vaultUid[16],
                                           const char* keyId, const size_t keyIdLen, const uint8_t publicKey[32],
                                           uint8_t* out, size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        const auto bytes = vlkk_capi::bytesIn(secret, secretLen);
        const auto context = vlkk_capi::credentialContextIn(installationId, installationIdLen, vaultUid, keyId, keyIdLen);
        const auto pk = vlkk_capi::fixedIn<32>(publicKey);
        vlkk_capi::need(outLen);
        return vlkk_capi::put(vlkk::credential::seal(bytes, context, pk), out, outLen);
    });
}

}

// ---- key provenance ----

vl_keykit_status vl_keykit_key_check(const uint8_t* key, const size_t keyLen, const uint64_t vaultId,
                                     const uint32_t version, char* out, size_t* outLen) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        return vlkk_capi::putText(vlkk::provenance::keyCheck(vlkk_capi::bytesIn(key, keyLen), vaultId, version), out,
                                  outLen);
    });
}

vl_keykit_status vl_keykit_attestation_public_key(const uint8_t* seed, const size_t seedLen, uint8_t out[32]) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        if (!out) vlkk_capi::fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
        vlkk_capi::fixedOut<32>(vlkk::provenance::attestationPublicKey(vlkk_capi::bytesIn(seed, seedLen)), out);
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_attest(const uint8_t* seed, const size_t seedLen, const char* nodeId, const size_t nodeIdLen,
                                  const uint64_t vaultId, const uint32_t version, const char* keyCheck,
                                  const size_t keyCheckLen, uint8_t signature[64]) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        if (!signature) vlkk_capi::fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
        vlkk_capi::fixedOut<64>(vlkk::provenance::attest(vlkk_capi::bytesIn(seed, seedLen),
                                                         vlkk_capi::textIn(nodeId, nodeIdLen), vaultId, version,
                                                         vlkk_capi::textIn(keyCheck, keyCheckLen)),
                                signature);
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_attestation_verify(const uint8_t* publicKey, const size_t publicKeyLen, const char* nodeId,
                                              const size_t nodeIdLen, const uint64_t vaultId, const uint32_t version,
                                              const char* keyCheck, const size_t keyCheckLen, const uint8_t* signature,
                                              const size_t signatureLen, int* valid) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        if (!valid) vlkk_capi::fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
        *valid = vlkk::provenance::verifyAttestation(
                     vlkk_capi::bytesIn(publicKey, publicKeyLen), vlkk_capi::textIn(nodeId, nodeIdLen), vaultId, version,
                     vlkk_capi::textIn(keyCheck, keyCheckLen), vlkk_capi::bytesIn(signature, signatureLen))
                     ? 1
                     : 0;
        return VL_KEYKIT_OK;
    });
}

vl_keykit_status vl_keykit_mac_origin_vault_id(const uint8_t vaultUid[16], uint32_t* out) {
    return vlkk_capi::guarded([&]() -> vl_keykit_status {
        if (!vaultUid || !out) vlkk_capi::fail(VL_KEYKIT_ERR_INVALID_ARGUMENT);
        *out = vlkk::provenance::macOriginVaultId(vlkk_capi::fixedIn<16>(vaultUid));
        return VL_KEYKIT_OK;
    });
}
