// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "sealing.hpp"

#include <openssl/bn.h>
#include <openssl/core_names.h>
#include <openssl/ec.h>
#include <openssl/evp.h>
#include <openssl/obj_mac.h>
#include <openssl/param_build.h>
#include <openssl/params.h>

#include <algorithm>
#include <climits>
#include <memory>
#include <stdexcept>

namespace vl::keykit::detail {

namespace {

struct PkeyCtxDeleter {
    void operator()(EVP_PKEY_CTX* p) const noexcept { EVP_PKEY_CTX_free(p); }
};
struct CipherCtxDeleter {
    void operator()(EVP_CIPHER_CTX* p) const noexcept { EVP_CIPHER_CTX_free(p); }
};
struct BnDeleter {
    void operator()(BIGNUM* p) const noexcept { BN_clear_free(p); }
};
struct GroupDeleter {
    void operator()(EC_GROUP* p) const noexcept { EC_GROUP_free(p); }
};
struct PointDeleter {
    void operator()(EC_POINT* p) const noexcept { EC_POINT_free(p); }
};
struct ParamBldDeleter {
    void operator()(OSSL_PARAM_BLD* p) const noexcept { OSSL_PARAM_BLD_free(p); }
};
struct ParamDeleter {
    void operator()(OSSL_PARAM* p) const noexcept { OSSL_PARAM_free(p); }
};

bool allZero(const std::span<const uint8_t> bytes) {
    uint8_t acc = 0;
    for (const auto b : bytes) acc = static_cast<uint8_t>(acc | b);
    return acc == 0;
}

Pkey x25519Key(const std::span<const uint8_t> bytes, const bool secret) {
    if (bytes.size() != kev1::kX25519KeySize) return nullptr;
    return Pkey(secret ? EVP_PKEY_new_raw_private_key(EVP_PKEY_X25519, nullptr, bytes.data(), bytes.size())
                       : EVP_PKEY_new_raw_public_key(EVP_PKEY_X25519, nullptr, bytes.data(), bytes.size()));
}

Pkey p256Key(const std::span<const uint8_t> scalar, const std::span<const uint8_t> point) {
    if (point.size() != kev1::kP256PointSize || point[0] != 0x04) return nullptr;
    {
        // EVP_PKEY_fromdata doesn't check that the point is on the curve; this does.
        const std::unique_ptr<EC_GROUP, GroupDeleter> group(EC_GROUP_new_by_curve_name(NID_X9_62_prime256v1));
        const std::unique_ptr<EC_POINT, PointDeleter> p(group ? EC_POINT_new(group.get()) : nullptr);
        if (!p || EC_POINT_oct2point(group.get(), p.get(), point.data(), point.size(), nullptr) != 1 ||
            EC_POINT_is_on_curve(group.get(), p.get(), nullptr) != 1)
            return nullptr;
    }
    const std::unique_ptr<OSSL_PARAM_BLD, ParamBldDeleter> bld(OSSL_PARAM_BLD_new());
    if (!bld) return nullptr;
    std::unique_ptr<BIGNUM, BnDeleter> k;
    if (OSSL_PARAM_BLD_push_utf8_string(bld.get(), OSSL_PKEY_PARAM_GROUP_NAME, "prime256v1", 0) != 1 ||
        OSSL_PARAM_BLD_push_octet_string(bld.get(), OSSL_PKEY_PARAM_PUB_KEY, point.data(), point.size()) != 1)
        return nullptr;
    if (!scalar.empty()) {
        k.reset(BN_bin2bn(scalar.data(), static_cast<int>(scalar.size()), nullptr));
        if (!k || OSSL_PARAM_BLD_push_BN(bld.get(), OSSL_PKEY_PARAM_PRIV_KEY, k.get()) != 1) return nullptr;
    }
    const std::unique_ptr<OSSL_PARAM, ParamDeleter> params(OSSL_PARAM_BLD_to_param(bld.get()));
    const std::unique_ptr<EVP_PKEY_CTX, PkeyCtxDeleter> ctx(EVP_PKEY_CTX_new_from_name(nullptr, "EC", nullptr));
    if (!params || !ctx || EVP_PKEY_fromdata_init(ctx.get()) != 1) return nullptr;
    EVP_PKEY* raw = nullptr;
    if (EVP_PKEY_fromdata(ctx.get(), &raw, scalar.empty() ? EVP_PKEY_PUBLIC_KEY : EVP_PKEY_KEYPAIR, params.get()) != 1)
        return nullptr;
    return Pkey(raw);
}

}

std::size_t epkSize(const kev1::Suite suite) noexcept {
    return suite == kev1::Suite::X25519 ? kev1::kX25519KeySize : kev1::kP256PointSize;
}

bool knownSuite(const uint16_t suite) noexcept {
    return suite == static_cast<uint16_t>(kev1::Suite::X25519) || suite == static_cast<uint16_t>(kev1::Suite::P256);
}

std::vector<uint8_t> p256Point(const std::span<const uint8_t> scalar) {
    if (scalar.size() != kev1::kP256ScalarSize) throw std::invalid_argument("a P-256 secret key is a 32-byte scalar");
    const std::unique_ptr<EC_GROUP, GroupDeleter> group(EC_GROUP_new_by_curve_name(NID_X9_62_prime256v1));
    const std::unique_ptr<BIGNUM, BnDeleter> k(BN_bin2bn(scalar.data(), static_cast<int>(scalar.size()), nullptr));
    if (!group || !k) throw std::runtime_error("OpenSSL P-256 setup failed");
    if (BN_is_zero(k.get()) || BN_cmp(k.get(), EC_GROUP_get0_order(group.get())) >= 0)
        throw std::invalid_argument("the P-256 secret key is out of range");
    const std::unique_ptr<EC_POINT, PointDeleter> point(EC_POINT_new(group.get()));
    if (!point || EC_POINT_mul(group.get(), point.get(), k.get(), nullptr, nullptr, nullptr) != 1)
        throw std::runtime_error("P-256 point multiplication failed");
    std::vector<uint8_t> out(kev1::kP256PointSize);
    if (EC_POINT_point2oct(group.get(), point.get(), POINT_CONVERSION_UNCOMPRESSED, out.data(), out.size(), nullptr) !=
        kev1::kP256PointSize)
        throw std::runtime_error("P-256 point encoding failed");
    return out;
}

Pkey secretKey(const kev1::Suite suite, const std::span<const uint8_t> sk) {
    if (suite == kev1::Suite::X25519) return x25519Key(sk, true);
    return p256Key(sk, p256Point(sk));
}

Pkey publicKey(const kev1::Suite suite, const std::span<const uint8_t> pk) {
    return suite == kev1::Suite::X25519 ? x25519Key(pk, false) : p256Key({}, pk);
}

std::optional<SecretBytes> agree(EVP_PKEY* mine, EVP_PKEY* peer) {
    if (!mine || !peer) return std::nullopt;
    const std::unique_ptr<EVP_PKEY_CTX, PkeyCtxDeleter> ctx(EVP_PKEY_CTX_new_from_pkey(nullptr, mine, nullptr));
    std::size_t len = 0;
    if (!ctx || EVP_PKEY_derive_init(ctx.get()) != 1 || EVP_PKEY_derive_set_peer(ctx.get(), peer) != 1 ||
        EVP_PKEY_derive(ctx.get(), nullptr, &len) != 1 || len == 0 || len > 66)
        return std::nullopt;
    std::array<uint8_t, 66> z{};
    const WipeOnExit<std::array<uint8_t, 66>> wipeZ{z};
    if (EVP_PKEY_derive(ctx.get(), z.data(), &len) != 1 || len == 0 || len > z.size()) return std::nullopt;
    const std::span<const uint8_t> out(z.data(), len);
    if (allZero(out)) return std::nullopt;
    return SecretBytes(out);
}

SecretBytes ephemeralSecret(const kev1::Suite suite, const std::span<const uint8_t> forTesting) {
    if (!forTesting.empty()) return SecretBytes(forTesting);
    const std::size_t n = suite == kev1::Suite::X25519 ? kev1::kX25519KeySize : kev1::kP256ScalarSize;
    // A P-256 scalar must be below the group order; retrying a rejected draw keeps it uniform.
    for (int attempt = 0;; ++attempt) {
        auto esk = SecretBytes::random(n);
        if (suite == kev1::Suite::X25519) return esk;
        try {
            (void)p256Point(esk.bytes());
            return esk;
        } catch (const std::invalid_argument&) {
            if (attempt > 16) throw;
        }
    }
}

SecretBytes deriveKey(const std::span<const uint8_t> z, const std::span<const uint8_t> epk,
                      const std::span<const uint8_t> rpk, const std::string_view label,
                      const std::span<const uint8_t> prefix) {
    std::vector<uint8_t> salt(epk.begin(), epk.end());
    append(salt, rpk);
    std::vector<uint8_t> info(label.begin(), label.end());
    append(info, prefix);
    std::array<uint8_t, 32> out{};
    const WipeOnExit<std::array<uint8_t, 32>> wipeOut{out};
    hkdfSha256(z, salt, info, out);
    return SecretBytes(out);
}

std::vector<uint8_t> aeadSeal(const std::span<const uint8_t> key, const std::span<const uint8_t> plaintext,
                              const std::span<const uint8_t> aad) {
    if (key.size() != 32 || plaintext.size() > INT_MAX - kGcmTag || aad.size() > INT_MAX)
        throw std::invalid_argument("AES-256-GCM: bad key or input size");
    const std::unique_ptr<EVP_CIPHER_CTX, CipherCtxDeleter> ctx(EVP_CIPHER_CTX_new());
    const std::array<uint8_t, 12> nonce{};
    std::vector<uint8_t> out(plaintext.size() + kGcmTag);
    int len = 0;
    int total = 0;
    const bool ok =
        ctx && EVP_EncryptInit_ex(ctx.get(), EVP_aes_256_gcm(), nullptr, key.data(), nonce.data()) == 1 &&
        EVP_EncryptUpdate(ctx.get(), nullptr, &len, aad.data(), static_cast<int>(aad.size())) == 1 &&
        EVP_EncryptUpdate(ctx.get(), out.data(), &len, plaintext.data(), static_cast<int>(plaintext.size())) == 1 &&
        (total = len, EVP_EncryptFinal_ex(ctx.get(), out.data() + total, &len) == 1) &&
        EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_GET_TAG, static_cast<int>(kGcmTag), out.data() + plaintext.size()) ==
            1;
    if (!ok) {
        wipe(out);
        throw std::runtime_error("AES-256-GCM encryption failed");
    }
    return out;
}

std::optional<SecretBytes> aeadOpen(const std::span<const uint8_t> key, const std::span<const uint8_t> sealed,
                                    const std::span<const uint8_t> aad) {
    if (key.size() != 32 || sealed.size() < kGcmTag || sealed.size() > INT_MAX || aad.size() > INT_MAX)
        return std::nullopt;
    const std::size_t n = sealed.size() - kGcmTag;
    const std::unique_ptr<EVP_CIPHER_CTX, CipherCtxDeleter> ctx(EVP_CIPHER_CTX_new());
    const std::array<uint8_t, 12> nonce{};
    std::vector<uint8_t> out(n + 1);  // never empty, so data() is valid for a zero-length plaintext
    const WipeOnExit<std::vector<uint8_t>> wipeOut{out};
    std::array<uint8_t, kGcmTag> tag{};
    std::ranges::copy(sealed.subspan(n), tag.begin());
    int len = 0;
    int total = 0;
    const bool ok = ctx && EVP_DecryptInit_ex(ctx.get(), EVP_aes_256_gcm(), nullptr, key.data(), nonce.data()) == 1 &&
                    EVP_DecryptUpdate(ctx.get(), nullptr, &len, aad.data(), static_cast<int>(aad.size())) == 1 &&
                    EVP_DecryptUpdate(ctx.get(), out.data(), &len, sealed.data(), static_cast<int>(n)) == 1 &&
                    (total = len, true) &&
                    EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_TAG, static_cast<int>(kGcmTag), tag.data()) == 1 &&
                    EVP_DecryptFinal_ex(ctx.get(), out.data() + total, &len) == 1;
    if (!ok) return std::nullopt;
    return SecretBytes(std::span<const uint8_t>(out.data(), n));
}

bool isStrictX25519PublicKey(const std::span<const uint8_t> pk) {
    if (pk.size() != kev1::kX25519KeySize) return false;
    // Little-endian u; p = 2^255 - 19 is ed ff .. ff 7f. Refuse the top bit and u >= p (one spelling per key).
    if (pk[31] & 0x80) return false;
    if (pk[31] == 0x7f && std::all_of(pk.begin() + 1, pk.begin() + 31, [](const uint8_t b) { return b == 0xff; }) &&
        pk[0] >= 0xed)
        return false;
    // Low order: X25519 with any clamped scalar (a multiple of the cofactor) is all zero exactly for these points.
    static constexpr std::array<uint8_t, 32> kProbe{9};
    const auto mine = x25519Key(kProbe, true);
    const auto peer = x25519Key(pk, false);
    return agree(mine.get(), peer.get()).has_value();
}

}
