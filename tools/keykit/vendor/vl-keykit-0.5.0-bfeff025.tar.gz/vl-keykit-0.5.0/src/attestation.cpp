// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/attestation.hpp"

#include "openssl.hpp"

#include <openssl/core_names.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/params.h>

#include <memory>

namespace vl::keykit::provenance {

std::string_view errorCodeName(const ErrorCode code) {
    switch (code) {
        case ErrorCode::BadKey: return "bad_key";
        case ErrorCode::BadVaultId: return "bad_vault_id";
        case ErrorCode::BadNodeId: return "bad_node_id";
        case ErrorCode::BadKeyCheck: return "bad_key_check";
        case ErrorCode::BadSeed: return "bad_seed";
    }
    return "bad_key";
}

Error::Error(const ErrorCode code) : std::invalid_argument(std::string(errorCodeName(code))), code_(code) {}

namespace {

constexpr char kCheckDigits[] = "0123456789abcdef";

int checkDigitValue(const char c) noexcept {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

std::array<uint8_t, kKeyCheckSize> checkBytes(const std::string_view hex) {
    std::array<uint8_t, kKeyCheckSize> out{};
    if (hex.size() != 2 * kKeyCheckSize) throw Error(ErrorCode::BadKeyCheck);
    for (std::size_t i = 0; i < out.size(); ++i) {
        const int hi = checkDigitValue(hex[2 * i]), lo = checkDigitValue(hex[2 * i + 1]);
        if (hi < 0 || lo < 0) throw Error(ErrorCode::BadKeyCheck);
        out[i] = static_cast<uint8_t>(hi << 4 | lo);
    }
    return out;
}

struct BlakeMacDeleter {
    void operator()(EVP_MAC* p) const noexcept { EVP_MAC_free(p); }
};
struct BlakeMacCtxDeleter {
    void operator()(EVP_MAC_CTX* p) const noexcept { EVP_MAC_CTX_free(p); }
};

}

std::string keyCheck(const std::span<const uint8_t> key, const uint64_t vaultId, const uint32_t version) {
    if (key.size() != kKeySize) throw Error(ErrorCode::BadKey);
    if (vaultId == 0) throw Error(ErrorCode::BadVaultId);
    std::string message(kKeyCheckDomain);
    message += std::to_string(vaultId);
    for (int shift = 24; shift >= 0; shift -= 8) message.push_back(static_cast<char>(version >> shift & 0xff));

    // Keyed BLAKE2b with a 16-byte digest, as libsodium's crypto_generichash computes it (OpenSSL's BLAKE2BMAC).
    const std::unique_ptr<EVP_MAC, BlakeMacDeleter> mac(EVP_MAC_fetch(nullptr, "BLAKE2BMAC", nullptr));
    if (!mac) throw std::runtime_error("BLAKE2BMAC is unavailable");
    const std::unique_ptr<EVP_MAC_CTX, BlakeMacCtxDeleter> ctx(EVP_MAC_CTX_new(mac.get()));
    if (!ctx) throw std::runtime_error("EVP_MAC_CTX_new failed");
    std::size_t size = kKeyCheckSize;
    const OSSL_PARAM params[] = {OSSL_PARAM_construct_size_t(OSSL_MAC_PARAM_SIZE, &size), OSSL_PARAM_construct_end()};
    std::array<uint8_t, kKeyCheckSize> digest{};
    std::size_t written = 0;
    if (EVP_MAC_init(ctx.get(), key.data(), key.size(), params) != 1 ||
        EVP_MAC_update(ctx.get(), reinterpret_cast<const uint8_t*>(message.data()), message.size()) != 1 ||
        EVP_MAC_final(ctx.get(), digest.data(), &written, digest.size()) != 1 || written != digest.size())
        throw std::runtime_error("the key check's BLAKE2b failed");
    std::string out;
    out.reserve(2 * kKeyCheckSize);
    for (const auto b : digest) {
        out.push_back(kCheckDigits[b >> 4]);
        out.push_back(kCheckDigits[b & 15]);
    }
    return out;
}

bool keyCheckEquals(const std::string_view a, const std::string_view b) noexcept {
    if (a.size() != 2 * kKeyCheckSize || b.size() != 2 * kKeyCheckSize) return false;
    return CRYPTO_memcmp(a.data(), b.data(), a.size()) == 0;
}

std::vector<uint8_t> attestationMessage(const std::string_view nodeId, const uint64_t vaultId, const uint32_t version,
                                        const std::string_view keyCheckHex) {
    if (nodeId.empty()) throw Error(ErrorCode::BadNodeId);
    if (vaultId == 0) throw Error(ErrorCode::BadVaultId);
    const auto check = checkBytes(keyCheckHex);
    std::vector<uint8_t> out(kAttestationDomain.begin(), kAttestationDomain.end());
    out.insert(out.end(), nodeId.begin(), nodeId.end());
    for (int shift = 56; shift >= 0; shift -= 8) out.push_back(static_cast<uint8_t>(vaultId >> shift));
    for (int shift = 24; shift >= 0; shift -= 8) out.push_back(static_cast<uint8_t>(version >> shift));
    out.insert(out.end(), check.begin(), check.end());
    return out;
}

std::array<uint8_t, kPublicKeySize> attestationPublicKey(const std::span<const uint8_t> seed) {
    if (seed.size() != kSeedSize) throw Error(ErrorCode::BadSeed);
    return detail::rawPublicKey(EVP_PKEY_ED25519, seed);
}

std::array<uint8_t, kSignatureSize> attest(const std::span<const uint8_t> seed, const std::string_view nodeId,
                                           const uint64_t vaultId, const uint32_t version,
                                           const std::string_view keyCheckHex) {
    if (seed.size() != kSeedSize) throw Error(ErrorCode::BadSeed);
    return detail::ed25519Sign(seed, attestationMessage(nodeId, vaultId, version, keyCheckHex));
}

bool verifyAttestation(const std::span<const uint8_t> publicKey, const std::string_view nodeId, const uint64_t vaultId,
                       const uint32_t version, const std::string_view keyCheckHex,
                       const std::span<const uint8_t> signature) noexcept {
    if (publicKey.size() != kPublicKeySize || signature.size() != kSignatureSize) return false;
    try {
        return detail::ed25519Verify(publicKey, attestationMessage(nodeId, vaultId, version, keyCheckHex), signature);
    } catch (...) {
        return false;
    }
}

uint32_t macOriginVaultId(const Uid& vaultUid) noexcept {
    const uint32_t head = static_cast<uint32_t>(vaultUid[0]) << 24 | static_cast<uint32_t>(vaultUid[1]) << 16 |
                          static_cast<uint32_t>(vaultUid[2]) << 8 | static_cast<uint32_t>(vaultUid[3]);
    return 1 + head % kMaxVaultId;
}

}
