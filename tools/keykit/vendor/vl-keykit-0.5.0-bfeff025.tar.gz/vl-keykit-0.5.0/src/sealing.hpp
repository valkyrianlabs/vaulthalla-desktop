// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#pragma once

// Private helpers shared by the sealed formats (KEV1, KAK1, vault labels, storage credentials): ECDH on X25519 or
// P-256, the HKDF-SHA-256 key derivation they all use, and AES-256-GCM with the zero nonce (every key derived here is
// single-use: it comes from a fresh ephemeral key). Not installed.

#include "openssl.hpp"
#include "vl/keykit/kev1.hpp"
#include "vl/keykit/secret.hpp"

#include <array>
#include <cstdint>
#include <optional>
#include <span>
#include <string_view>
#include <vector>

namespace vl::keykit::detail {

inline constexpr std::size_t kGcmTag = 16;

// Wipes a buffer when it leaves scope, on every path.
template <typename Buffer>
struct WipeOnExit {
    Buffer& buffer;
    ~WipeOnExit() { wipe(std::span<uint8_t>(buffer.data(), buffer.size())); }
};

[[nodiscard]] inline uint16_t be16(const uint8_t* p) {
    return static_cast<uint16_t>((static_cast<uint16_t>(p[0]) << 8) | p[1]);
}
[[nodiscard]] inline uint32_t be32(const uint8_t* p) {
    return (static_cast<uint32_t>(p[0]) << 24) | (static_cast<uint32_t>(p[1]) << 16) |
           (static_cast<uint32_t>(p[2]) << 8) | static_cast<uint32_t>(p[3]);
}
inline void putBe16(std::vector<uint8_t>& out, const uint16_t v) {
    out.push_back(static_cast<uint8_t>(v >> 8));
    out.push_back(static_cast<uint8_t>(v));
}
inline void putBe32(std::vector<uint8_t>& out, const uint32_t v) {
    for (int i = 0; i < 4; ++i) out.push_back(static_cast<uint8_t>(v >> (24 - 8 * i)));
}
inline void append(std::vector<uint8_t>& out, const std::span<const uint8_t> bytes) {
    out.insert(out.end(), bytes.begin(), bytes.end());
}

[[nodiscard]] std::size_t epkSize(kev1::Suite suite) noexcept;
[[nodiscard]] bool knownSuite(uint16_t suite) noexcept;

// The P-256 point of a scalar (uncompressed SEC1, 65 bytes). Throws std::invalid_argument for a scalar out of range.
[[nodiscard]] std::vector<uint8_t> p256Point(std::span<const uint8_t> scalar);

// EVP keys from raw bytes: an X25519 secret or public key, a P-256 scalar or uncompressed point (checked on the
// curve). nullptr when OpenSSL refuses the bytes. secretKey throws std::invalid_argument for a P-256 scalar out of range.
[[nodiscard]] Pkey secretKey(kev1::Suite suite, std::span<const uint8_t> sk);
[[nodiscard]] Pkey publicKey(kev1::Suite suite, std::span<const uint8_t> pk);

// Z: the X25519 output or the P-256 x-coordinate, in locked memory. nullopt for a missing key, a peer OpenSSL
// refuses, or an all-zero Z (a low-order X25519 point).
[[nodiscard]] std::optional<SecretBytes> agree(EVP_PKEY* mine, EVP_PKEY* peer);

// A fresh ephemeral secret for the suite (P-256: a scalar below the group order), or a copy of `forTesting` when it is
// not empty.
[[nodiscard]] SecretBytes ephemeralSecret(kev1::Suite suite, std::span<const uint8_t> forTesting);

// HKDF-SHA-256(salt = epk ‖ rpk, IKM = Z, info = label ‖ prefix), 32 bytes.
[[nodiscard]] SecretBytes deriveKey(std::span<const uint8_t> z, std::span<const uint8_t> epk,
                                    std::span<const uint8_t> rpk, std::string_view label,
                                    std::span<const uint8_t> prefix);

// AES-256-GCM under a single-use key with the zero nonce. seal returns ciphertext ‖ tag; open returns the plaintext
// in locked memory, or nullopt when `sealed` is shorter than a tag or doesn't authenticate.
[[nodiscard]] std::vector<uint8_t> aeadSeal(std::span<const uint8_t> key, std::span<const uint8_t> plaintext,
                                            std::span<const uint8_t> aad);
[[nodiscard]] std::optional<SecretBytes> aeadOpen(std::span<const uint8_t> key, std::span<const uint8_t> sealed,
                                                  std::span<const uint8_t> aad);

// A canonical X25519 public key that is not of low order: 32 bytes, u < 2^255 - 19 (so the top bit is clear), and
// X25519 with it is not all zero. The key statement and the recovery policy accept only these.
[[nodiscard]] bool isStrictX25519PublicKey(std::span<const uint8_t> pk);

}
