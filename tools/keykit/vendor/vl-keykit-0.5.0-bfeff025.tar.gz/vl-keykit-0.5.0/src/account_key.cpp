// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Valkyrian Labs LLC
#include "vl/keykit/account_key.hpp"

#include "openssl.hpp"
#include "sealing.hpp"
#include "text.hpp"
#include "vl/keykit/base64url.hpp"

#include <algorithm>
#include <utility>

namespace vl::keykit::account {

namespace {

constexpr std::array<std::pair<ErrorCode, std::string_view>, 29> kErrorNames{{
    {ErrorCode::UnsupportedVersion, "unsupported_version"},
    {ErrorCode::BadStatement, "bad_statement"},
    {ErrorCode::BadPublicId, "bad_public_id"},
    {ErrorCode::BadGeneration, "bad_generation"},
    {ErrorCode::BadBase64Url, "bad_base64url"},
    {ErrorCode::BadKey, "bad_key"},
    {ErrorCode::BadPrevious, "bad_previous"},
    {ErrorCode::BadReason, "bad_reason"},
    {ErrorCode::AccountMismatch, "account_mismatch"},
    {ErrorCode::GenerationGap, "generation_gap"},
    {ErrorCode::BadSignature, "bad_signature"},
    {ErrorCode::PreviousMismatch, "previous_mismatch"},
    {ErrorCode::BadPreviousSignature, "bad_previous_signature"},
    {ErrorCode::Rollback, "rollback"},
    {ErrorCode::PinMismatch, "pin_mismatch"},
    {ErrorCode::BadPolicy, "bad_policy"},
    {ErrorCode::BadSequence, "bad_sequence"},
    {ErrorCode::BadIssuedAt, "bad_issued_at"},
    {ErrorCode::BadRecipient, "bad_recipient"},
    {ErrorCode::RecipientIdMismatch, "recipient_id_mismatch"},
    {ErrorCode::UnsupportedSuite, "unsupported_suite"},
    {ErrorCode::UnsupportedClass, "unsupported_class"},
    {ErrorCode::BadLabel, "bad_label"},
    {ErrorCode::UnsupportedScope, "unsupported_scope"},
    {ErrorCode::UnsortedRecipients, "unsorted_recipients"},
    {ErrorCode::TooManyRecipients, "too_many_recipients"},
    {ErrorCode::GenerationMismatch, "generation_mismatch"},
    {ErrorCode::AccountKeyListed, "account_key_listed"},
    {ErrorCode::BadInstallationId, "bad_installation_id"},
}};

constexpr std::string_view kStatementVersionStem = "vhc-account-key-v";

std::string message(const ErrorCode code, const std::optional<std::size_t> index) {
    std::string out = "account key rejected: " + std::string(errorCodeName(code));
    if (index) out += " (chain position " + std::to_string(*index) + ")";
    return out;
}

// Decodes one key line: bad_base64url for text that isn't canonical base64url, bad_key for any other size.
PublicKey keyLine(const std::string_view line) {
    const auto bytes = base64UrlDecode(line);
    if (!bytes) throw Error(ErrorCode::BadBase64Url);
    if (bytes->size() != kPublicKeySize) throw Error(ErrorCode::BadKey);
    PublicKey out{};
    std::ranges::copy(*bytes, out.begin());
    return out;
}

std::optional<Reason> reasonOf(const std::string_view text) {
    if (text == "initial") return Reason::Initial;
    if (text == "routine") return Reason::Routine;
    if (text == "compromise") return Reason::Compromise;
    return std::nullopt;
}

bool reasonFits(const uint32_t generation, const Reason reason) {
    return (generation == 1) == (reason == Reason::Initial);
}

// The first five lines, joined by '\n'.
std::string fingerprintInput(const KeyStatement& s) {
    return std::string(kStatementMagic) + "\n" + s.public_id + "\n" + std::to_string(s.generation) + "\n" +
           base64UrlEncode(s.x25519_public) + "\n" + base64UrlEncode(s.ed25519_public);
}

PublicKey toKey(const std::span<const uint8_t> bytes) {
    PublicKey out{};
    if (bytes.size() != out.size()) throw std::invalid_argument("a public key is 32 bytes");
    std::ranges::copy(bytes, out.begin());
    return out;
}

void requireSeedMatches(const KeyStatement& statement, const RecoverySeed& key) {
    if (toKey(key.x25519PublicKey()) != statement.x25519_public ||
        toKey(key.ed25519PublicKey()) != statement.ed25519_public)
        throw std::invalid_argument("the seed is not this statement's key");
}

}

std::string_view errorCodeName(const ErrorCode code) {
    for (const auto& [c, name] : kErrorNames)
        if (c == code) return name;
    return "unknown";
}

Error::Error(const ErrorCode code, const std::optional<std::size_t> index)
    : std::runtime_error(message(code, index)), code_(code), index_(index) {}

std::string_view reasonName(const Reason reason) {
    switch (reason) {
        case Reason::Initial: return "initial";
        case Reason::Routine: return "routine";
        case Reason::Compromise: return "compromise";
    }
    return "unknown";
}

std::string_view linkName(const Link link) {
    switch (link) {
        case Link::Initial: return "initial";
        case Link::Rotation: return "rotation";
        case Link::Replacement: return "replacement";
    }
    return "unknown";
}

std::optional<std::array<uint8_t, 16>> parsePublicId(const std::string_view text) { return detail::parseUuid(text); }

KeyStatement statementFor(const RecoverySeed& seed, const std::string_view publicId, const uint32_t generation,
                          const std::optional<Fingerprint> previous, const Reason reason) {
    KeyStatement s{.public_id = std::string(publicId),
                   .generation = generation,
                   .x25519_public = toKey(seed.x25519PublicKey()),
                   .ed25519_public = toKey(seed.ed25519PublicKey()),
                   .previous = previous,
                   .reason = reason};
    (void)encode(s);  // validates
    return s;
}

std::string encode(const KeyStatement& s) {
    if (!detail::parseUuid(s.public_id)) throw std::invalid_argument("the account public id is not a canonical UUID");
    if (s.generation == 0) throw std::invalid_argument("generations start at 1");
    if (!detail::isStrictX25519PublicKey(s.x25519_public))
        throw std::invalid_argument("the X25519 public key is non-canonical or of low order");
    if (s.previous.has_value() != (s.generation > 1))
        throw std::invalid_argument("exactly the generations after the first name a previous fingerprint");
    if (!reasonFits(s.generation, s.reason))
        throw std::invalid_argument("generation 1 is 'initial', later ones 'routine' or 'compromise'");
    return fingerprintInput(s) + "\n" + (s.previous ? fingerprintText(*s.previous) : std::string()) + "\n" +
           std::string(reasonName(s.reason));
}

KeyStatement parseStatement(const std::string_view text) {
    const auto lines = detail::splitLines(text);
    if (lines[0] != kStatementMagic) {
        if (detail::isOtherVersion(lines[0], kStatementVersionStem)) throw Error(ErrorCode::UnsupportedVersion);
        throw Error(ErrorCode::BadStatement);
    }
    if (lines.size() != 7) throw Error(ErrorCode::BadStatement);
    if (!detail::parseUuid(lines[1])) throw Error(ErrorCode::BadPublicId);
    const auto generation = detail::parsePositive32(lines[2]);
    if (!generation) throw Error(ErrorCode::BadGeneration);
    KeyStatement s{.public_id = std::string(lines[1]), .generation = *generation};
    s.x25519_public = keyLine(lines[3]);
    if (!detail::isStrictX25519PublicKey(s.x25519_public)) throw Error(ErrorCode::BadKey);
    s.ed25519_public = keyLine(lines[4]);
    if (s.generation == 1) {
        if (!lines[5].empty()) throw Error(ErrorCode::BadPrevious);
    } else {
        s.previous = parseFingerprint(lines[5]);
        if (!s.previous) throw Error(ErrorCode::BadPrevious);
    }
    const auto reason = reasonOf(lines[6]);
    if (!reason || !reasonFits(s.generation, *reason)) throw Error(ErrorCode::BadReason);
    s.reason = *reason;
    return s;
}

Fingerprint fingerprint(const KeyStatement& statement) {
    const auto input = fingerprintInput(statement);
    const auto digest = detail::sha256(detail::viewBytes(input));
    Fingerprint out{};
    std::copy_n(digest.begin(), out.size(), out.begin());
    return out;
}

std::string fingerprintText(const Fingerprint& fp) {
    static constexpr char kDigits[] = "0123456789abcdef";
    std::string out;
    out.reserve(kFingerprintTextSize);
    for (std::size_t i = 0; i < fp.size(); ++i) {
        if (i && i % 2 == 0) out.push_back('-');
        out.push_back(kDigits[fp[i] >> 4]);
        out.push_back(kDigits[fp[i] & 0x0f]);
    }
    return out;
}

std::optional<Fingerprint> parseFingerprint(const std::string_view text, const bool lenient) {
    std::string digits;
    if (lenient) {
        for (const char c : text) {
            if (c == '-' || c == ' ') continue;
            digits.push_back(c >= 'A' && c <= 'F' ? static_cast<char>(c - 'A' + 'a') : c);
        }
    } else {
        if (text.size() != kFingerprintTextSize) return std::nullopt;
        for (std::size_t i = 0; i < text.size(); ++i) {
            if (i % 5 == 4) {
                if (text[i] != '-') return std::nullopt;
            } else {
                digits.push_back(text[i]);
            }
        }
    }
    if (digits.size() != 2 * kFingerprintSize) return std::nullopt;
    Fingerprint out{};
    for (std::size_t i = 0; i < out.size(); ++i) {
        const auto value = [](const char c) {
            return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : -1;
        };
        const int hi = value(digits[2 * i]), lo = value(digits[2 * i + 1]);
        if (hi < 0 || lo < 0) return std::nullopt;
        out[i] = static_cast<uint8_t>(hi << 4 | lo);
    }
    return out;
}

Signature signBytes(const std::span<const uint8_t> message, const RecoverySeed& key) {
    const auto seed = key.ed25519Seed();
    return detail::ed25519Sign(seed.bytes(), message);
}

bool verifyBytes(const PublicKey& ed25519Public, const std::span<const uint8_t> message, const Signature& signature) {
    return detail::ed25519Verify(ed25519Public, message, signature);
}

SignedStatement sign(const KeyStatement& statement, const RecoverySeed& key, const RecoverySeed* previous) {
    requireSeedMatches(statement, key);
    SignedStatement out{.statement = encode(statement)};
    out.signature = signBytes(detail::viewBytes(out.statement), key);
    if (previous) {
        if (statement.generation < 2) throw std::invalid_argument("generation 1 has no previous key");
        // The previous generation's statement as statementFor would have built it: only its first five lines matter.
        KeyStatement before{.public_id = statement.public_id,
                            .generation = statement.generation - 1,
                            .x25519_public = toKey(previous->x25519PublicKey()),
                            .ed25519_public = toKey(previous->ed25519PublicKey())};
        if (fingerprint(before) != *statement.previous)
            throw std::invalid_argument("the previous seed is not the previous generation's key");
        out.previous_signature = signBytes(detail::viewBytes(out.statement), *previous);
    }
    return out;
}

std::vector<VerifiedGeneration> verifyChain(const std::span<const SignedStatement> chain,
                                            const std::string_view publicId) {
    if (chain.empty()) throw Error(ErrorCode::BadStatement, 0);
    std::vector<VerifiedGeneration> out;
    out.reserve(chain.size());
    for (std::size_t i = 0; i < chain.size(); ++i) {
        const auto& item = chain[i];
        VerifiedGeneration g;
        try {
            g.statement = parseStatement(item.statement);
        } catch (const Error& e) {
            throw Error(e.code(), i);
        }
        if (g.statement.public_id != publicId) throw Error(ErrorCode::AccountMismatch, i);
        if (g.statement.generation != i + 1) throw Error(ErrorCode::GenerationGap, i);
        const auto bytes = detail::viewBytes(item.statement);
        if (!verifyBytes(g.statement.ed25519_public, bytes, item.signature)) throw Error(ErrorCode::BadSignature, i);
        g.fingerprint = fingerprint(g.statement);
        if (i == 0) {
            if (item.previous_signature) throw Error(ErrorCode::BadPreviousSignature, i);
            g.link = Link::Initial;
        } else {
            const auto& before = out.back();
            if (*g.statement.previous != before.fingerprint) throw Error(ErrorCode::PreviousMismatch, i);
            if (item.previous_signature) {
                if (!verifyBytes(before.statement.ed25519_public, bytes, *item.previous_signature))
                    throw Error(ErrorCode::BadPreviousSignature, i);
                g.link = Link::Rotation;
            } else {
                g.link = Link::Replacement;
            }
        }
        out.push_back(std::move(g));
    }
    return out;
}

FollowResult follow(const Pin& pin, const std::span<const VerifiedGeneration> chain) {
    if (pin.generation == 0 || chain.size() < pin.generation) throw Error(ErrorCode::Rollback);
    if (chain[pin.generation - 1].fingerprint != pin.fingerprint) throw Error(ErrorCode::PinMismatch, pin.generation - 1);
    FollowResult out{.accepted = pin.generation, .newest = static_cast<uint32_t>(chain.size())};
    while (out.accepted < out.newest && chain[out.accepted].link == Link::Rotation) ++out.accepted;
    return out;
}

}
