# Changelog

All notable changes to vl-keykit are recorded here. The format follows [Keep a Changelog](https://keepachangelog.com/),
and versions follow [Semantic Versioning](https://semver.org/) (before 1.0, a minor version may break the API).

## [Unreleased]

## [0.5.0]

### Added

- Key provenance, moved in from vaulthalla-server (`vault/KeyCheck`, `vault/KeyAttestation`) so a server and
  Vaulthalla Desktop produce and verify it with one implementation (vaulthalla-server
  `design/encryption/03-metadata-recovery.md` §6.5): `attestation.hpp` (`provenance::keyCheck`, keyed BLAKE2b-128
  through OpenSSL's `BLAKE2BMAC`, byte for byte libsodium's `crypto_generichash`; `keyCheckEquals`;
  `attestationMessage`; `attestationPublicKey`, `attest` and `verifyAttestation` over Ed25519; and
  `macOriginVaultId`, the origin vault id of a vault a Mac created, derived from its uid), with ordered errors
  (`provenance::ErrorCode`).
- The same in the C API: `vl_keykit_key_check`, `vl_keykit_attestation_public_key`, `vl_keykit_attest`,
  `vl_keykit_attestation_verify`, `vl_keykit_mac_origin_vault_id`; statuses 700-704 (`provenance_*`).
- `vectors/key_provenance.json` and `key_provenance_vectors.py` (17 vectors), verbatim copies of vaulthalla-server's
  `design/encryption/vectors/` (the server's documented key-check and attestation vectors, a Mac-origin attestation,
  origin vault ids and negatives), checked by `meson test` as `key-provenance-reference`. `vectors.json` is unchanged.

## [0.4.0]

### Added

- The sealed storage credential in the C API, for Vaulthalla Desktop's managed-storage client (a Mac holding a
  Desktop-only vault runs the same exchange as a server): `vl_keykit_credential_key` (a one-time X25519 key pair:
  `_generate`, `_from_secret`, `_public`, `_free`), `vl_keykit_credential_open` (the binding to installation, vault and
  key id checked) into an opaque `vl_keykit_credential` handle, `vl_keykit_credential_secret` (the secret read only
  into the caller's buffer), `vl_keykit_credential_free`, and `vl_keykit_credential_seal` (the cloud's side, for test
  doubles). Statuses 600-605 (`credential_*`, 600 + `credential::ErrorCode`), and the sizes
  `VL_KEYKIT_CREDENTIAL_SECRET_MAX_SIZE`, `_KEY_ID_MAX_SIZE`, `_SEALED_MAX_SIZE`. Tested against the vectors and
  from C (`tests/c_header_check.c`).
- `vectors/vhc.json` (202 -> 206): two storage-credential positives (an S3-style access key; a 1024-byte secret under
  a 128-character key id) and two negatives (another one-time key; a truncated tag). No existing vector changed.

## [0.3.0]

### Added

- Three formats moved in from vaulthalla-cloud, byte for byte with what the cloud verifies, with vectors in
  `vectors/vhc.json` (146 -> 202) and the Python reference extended:
  - `holder_proof.hpp`: the holder proof `vhc-account-key-holder-v1` a Desktop presents to register as a holder
    (`holderMessage`, `signHolderProof`, `checkHolderProof` with ordered errors, `verifyHolderProof`), and
    `account::ErrorCode::BadInstallationId` (appended). Stricter than the cloud's check in one way: a holder key KAK1
    can't wrap to (an X25519 key that is non-canonical or of low order, a P-256 point off the curve) is `bad_key`.
  - `key_codes.hpp`: the request, transfer and restore comparison codes (`requestCode`, `transferCode`,
    `restoreCode`), reproducing the cloud's design vectors.
  - `account::parsePublicId`: the account public id's 16 bytes, as KAK1 and vault labels bind them (both use it now).
- A C API, `vl/keykit/vl_keykit.h`, for Vaulthalla Desktop (Swift): the seed and recovery code, statements, chains
  and pins, holder proofs, KAK1 (also through a hardware-key agreement callback), vault labels, the recovery policy, a
  restore's KEV1 unwrap and re-wrap, and the comparison codes. Opaque handles wiped on free for the seed and vault
  keys, caller buffers with length in/out, stable numeric statuses with names, no exception across the boundary.
  Tested against the same vectors (`tests/test_c_api.cpp`), and compiled as C11 (`tests/c_header_check.c`).
- `scripts/build-xcframework.sh`: `VLKeykit.xcframework` for macOS, one static library with Homebrew's `openssl@3`
  libcrypto linked in (no run-time dependency on Homebrew), the C header and a `VLKeykit` module map; and
  `tests/apple/run.sh`, a Swift package that imports it. macOS only, outside the Linux CI.

### Changed

- `kak1::unwrapWith` refuses an all-zero Z from the agreement callback (`bad_ephemeral`), as `unwrap` does.
- The C API initializes OpenSSL without its configuration file (`OPENSSL_INIT_NO_LOAD_CONFIG`). The C++ API leaves
  OpenSSL's initialization to its host as before.

## [0.2.1]

### Fixed

- The library builds as one unity unit again: `account_key.cpp` and `recovery_policy.cpp` both defined a file-scope
  `kVersionStem`, which broke consumers that build subprojects with `unity=on` (vaulthalla-server). CI's release
  build is now a single unity unit, so a clash fails there.

## [0.2.0]

### Added

- The Vaulthalla Cloud account recovery key formats, with their own golden vectors (`vectors/vhc.json`, 146 vectors)
  and an independent Python reference (`vectors/vhc_vectors.py --check`, run by `meson test` as
  `vhc-vectors-reference`):
  - `account_key.hpp`: the `vhc-account-key-v1` key statement (`encode`, strict `parseStatement`, `statementFor`),
    its `fingerprint` and fingerprint text, Ed25519 signing (`sign`, `signBytes`, `verifyBytes`), `verifyChain`
    (rotations signed by both generations, replacements) and `follow` from a server's pin.
  - `recovery_policy.hpp`: the signed `vhc-recovery-policy-v1` document (`encode`, `parsePolicy`, `signPolicy`,
    `verifyPolicy` against a pinned generation), `policyHash`, and the sequence rules (`compareToFloor`,
    `isNextSequence`); the caller stores the floor.
  - `kak1.hpp`: KAK1, the account key wrapped to a holder's X25519 or P-256 key (`wrap`, `unwrap`, `unwrapWith` for a
    key that never leaves its hardware, `inspect`).
  - `vault_label.hpp`: a vault's display name sealed to the account key (`vh.vault-label.v1`), padded to 128 bytes.
  - `storage_credential.hpp`: a managed bucket's key secret sealed to a server's one-time X25519 key
    (`vhc-storage-credential-v1`), bound to the installation, vault and key id.
  - `base64url.hpp`: strict unpadded base64url.

### Changed

- KEV1's ECDH, HKDF and AES-GCM helpers are shared with the new sealed formats (`src/sealing.{hpp,cpp}`), and its
  temporaries (ephemeral secret, shared secret, wrapping key) are held in `SecretBytes`. Every KEV1 vector is
  reproduced unchanged.

## [0.1.0]

### Added

- First release, extracted from vaulthalla-server 1.22.2 (`core/{include,src}/crypto/recovery/`, `crypto/id/ObjectUid`
  and `crypto/SecretBytes`). Byte-compatible with it: every `kev1`, `recovery_seed` and `object_ids` golden vector
  is reproduced.
  - `kev1`: `wrap`, `unwrap`, `inspect`, `recipientId`, `publicKeyOf`, `kid`, `objectKey`, `skippedByRestore`, and
    the reader's ordered `ErrorCode`s.
  - `RecoverySeed`: `generate`, `parse`, `fromBytes`, `text`, and the X25519 and Ed25519 derivations.
  - The recovery kit codec (`parseKit`, `toJson`, `kitVaultFromJson`) and strict standard base64.
  - `Uid`, `newUid`, strict `toBase32` / `fromBase32`.
  - `SecretBytes` (locked, wiped, move-only), `wipe`, `equalConstantTime`, and the test wipe observer.
- `vectors/`: a verbatim copy of vaulthalla-server's golden vectors and their Python reference, checked by
  `meson test` (`vectors-reference`).

### Changed (from the vaulthalla-server code)

- OpenSSL 3 is the only crypto dependency: X25519 and Ed25519 public keys, SHA-256, the CSPRNG
  (`RAND_priv_bytes` for secrets), wiping (`OPENSSL_cleanse`) and constant-time comparison (`CRYPTO_memcmp`) no
  longer come from libsodium. Memory locking uses `mlock`.
- `kev1::wrap` takes the vault key as 32 bytes (`std::span`), and `kev1::Unwrapped::key` is `SecretBytes`, so the
  library has no key type of its own.
