# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Valkyrian Labs LLC
project('vl-keykit', 'cpp',
  version: '0.3.0',
  license: 'MIT',
  license_files: ['LICENSE'],
  meson_version: '>= 1.3.0',
  default_options: ['cpp_std=c++23', 'warning_level=3'],
)

openssl_dep = dependency('libcrypto', version: '>= 3.0')
json_dep = dependency('nlohmann_json', version: '>= 3.11')

inc = include_directories('include')

sources = files(
  'src/account_key.cpp',
  'src/c_api.cpp',
  'src/holder_proof.cpp',
  'src/kak1.cpp',
  'src/kev1.cpp',
  'src/key_codes.cpp',
  'src/kit.cpp',
  'src/openssl.cpp',
  'src/recovery_policy.cpp',
  'src/sealing.cpp',
  'src/secret.cpp',
  'src/seed.cpp',
  'src/storage_credential.cpp',
  'src/text.cpp',
  'src/uid.cpp',
  'src/vault_label.cpp',
)

vl_keykit_lib = static_library('vl-keykit', sources,
  include_directories: inc,
  cpp_args: ['-DVL_KEYKIT_VERSION="' + meson.project_version() + '"'],
  dependencies: [openssl_dep, json_dep],
  install: not meson.is_subproject(),
)

# `vectors_dir`: the golden vectors (vectors/vectors.json), for a consumer that checks its own copy against them.
vl_keykit_dep = declare_dependency(
  include_directories: inc,
  link_with: vl_keykit_lib,
  dependencies: [openssl_dep, json_dep],
  version: meson.project_version(),
  variables: {'vectors_dir': meson.current_source_dir() / 'vectors'},
)
meson.override_dependency('vl-keykit', vl_keykit_dep)

headers = files(
  'include/vl/keykit/account_key.hpp',
  'include/vl/keykit/base64url.hpp',
  'include/vl/keykit/holder_proof.hpp',
  'include/vl/keykit/kak1.hpp',
  'include/vl/keykit/kev1.hpp',
  'include/vl/keykit/key_codes.hpp',
  'include/vl/keykit/keykit.hpp',
  'include/vl/keykit/kit.hpp',
  'include/vl/keykit/recovery_policy.hpp',
  'include/vl/keykit/secret.hpp',
  'include/vl/keykit/seed.hpp',
  'include/vl/keykit/storage_credential.hpp',
  'include/vl/keykit/uid.hpp',
  'include/vl/keykit/vault_label.hpp',
  'include/vl/keykit/vl_keykit.h',
)

if not meson.is_subproject()
  install_headers(headers, subdir: 'vl/keykit')
  pkg = import('pkgconfig')
  pkg.generate(vl_keykit_lib,
    name: 'vl-keykit',
    description: 'Vaulthalla key envelopes (KEV1), recovery seed and kit, and Vaulthalla Cloud account key codecs (C++23)',
    url: 'https://github.com/valkyrianlabs/vl-keykit',
    requires: ['libcrypto >= 3.0', 'nlohmann_json >= 3.11'],
  )
endif

if get_option('tests').allowed() and not meson.is_subproject()
  gtest_dep = dependency('gtest', main: true, required: get_option('tests'))
  if gtest_dep.found()
    subdir('tests')
  endif
endif
