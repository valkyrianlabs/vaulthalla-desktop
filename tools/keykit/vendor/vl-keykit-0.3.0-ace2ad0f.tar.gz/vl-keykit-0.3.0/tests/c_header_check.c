/* SPDX-License-Identifier: MIT */
/* Copyright (c) 2026 Valkyrian Labs LLC */
/* The C API's header compiled as C11, and a few calls made from C (test_c_api.cpp runs this). */
#include "vl/keykit/vl_keykit.h"

#include <string.h>

int vl_keykit_c_header_check(void);

int vl_keykit_c_header_check(void) {
    static const char id[] = "0123456789abcdefghjkmnpqrs";
    static const char payload[] = "{\"generation\":1}";
    char code[VL_KEYKIT_CODE_TEXT_SIZE];
    size_t len = sizeof code;
    if (vl_keykit_request_code(id, sizeof id - 1, payload, sizeof payload - 1, code, &len) != VL_KEYKIT_OK) return 1;
    if (len != VL_KEYKIT_CODE_TEXT_SIZE || memcmp(code, "4c0c-4ab7-e42c-29ef", len) != 0) return 2;

    vl_keykit_seed* seed = NULL;
    if (vl_keykit_seed_generate(&seed) != VL_KEYKIT_OK || seed == NULL) return 3;
    char text[VL_KEYKIT_SEED_TEXT_SIZE];
    len = sizeof text;
    const vl_keykit_status status = vl_keykit_seed_export_text(seed, text, &len);
    memset(text, 0, sizeof text);
    vl_keykit_seed_free(seed);
    if (status != VL_KEYKIT_OK || len != VL_KEYKIT_SEED_TEXT_SIZE) return 4;

    if (strcmp(vl_keykit_status_name(VL_KEYKIT_ERR_KAK1_WRAP_AUTH_FAILED), "kak1_wrap_auth_failed") != 0) return 5;
    return 0;
}
