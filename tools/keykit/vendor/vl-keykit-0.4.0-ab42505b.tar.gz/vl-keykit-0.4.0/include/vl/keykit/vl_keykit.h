/* SPDX-License-Identifier: MIT */
/* Copyright (c) 2026 Valkyrian Labs LLC */
#ifndef VL_KEYKIT_H
#define VL_KEYKIT_H

/*
 * vl-keykit's C API: the operations a Vaulthalla Desktop performs with the account recovery key, for callers that
 * can't use C++ (Swift, through the VLKeykit module of the XCFramework). Plain C11; every function is extern "C".
 * The formats themselves are specified in the C++ headers beside this one (account_key.hpp, holder_proof.hpp,
 * recovery_policy.hpp, kak1.hpp, kev1.hpp, vault_label.hpp, key_codes.hpp, seed.hpp, storage_credential.hpp); this API
 * adds no format.
 *
 * Status codes. Every function except the few that return a value of their own (vl_keykit_version,
 * vl_keykit_status_name, vl_keykit_vault_key_version, vl_keykit_kev1_skipped_by_restore and the frees) returns a
 * vl_keykit_status. The numeric values below are stable: a value is never renumbered or reused, new ones are only
 * added. vl_keykit_status_name gives each a stable lower-case name: the format's prefix and the error's spelling in the
 * golden vectors ("kak1_wrap_auth_failed", "account_bad_signature"). No C++ exception crosses this boundary; an
 * unexpected failure is VL_KEYKIT_ERR_INTERNAL.
 *
 * Inputs. Pointers are borrowed for the duration of the call; the library keeps no reference to them. Text is UTF-8
 * passed as pointer and length (no terminating NUL is needed or read). A NULL pointer with length 0 is the empty
 * string or buffer; a required pointer that is NULL is VL_KEYKIT_ERR_INVALID_ARGUMENT. Fixed-size arrays in the
 * signatures (uint8_t fingerprint[16]) must hold that many bytes. Statements are passed as their canonical text (what
 * GET /v1/keys/account serves) and parsed strictly on every call, so a malformed one fails with its account_* status.
 *
 * Outputs. Variable-length outputs are caller-provided buffers with the length in and out: `*out_len` is the capacity
 * on entry and the length written on VL_KEYKIT_OK. When the capacity is too small the function writes nothing to the
 * buffer, sets `*out_len` to the length needed and returns VL_KEYKIT_ERR_BUFFER_TOO_SMALL (pass `out` NULL with
 * `*out_len` 0 to ask). Text outputs carry no terminating NUL. The VL_KEYKIT_*_SIZE constants bound every output.
 * Nothing is written to an output on any status other than VL_KEYKIT_OK (and `*out_len` on BUFFER_TOO_SMALL).
 *
 * Secrets. The account key (a recovery seed), vault keys, the one-time key a storage credential is sealed to and an
 * opened storage credential exist only inside opaque handles, in locked memory that is zeroed when the handle is freed.
 * The seed crosses this boundary as bytes only when the caller explicitly exports the recovery code text
 * (vl_keykit_seed_export_text), and a storage credential's secret only when the caller reads it into its own buffer for
 * immediate use (vl_keykit_credential_secret); a caller that does either wipes its buffer. Temporaries are zeroed inside
 * the library on every path. A holder's secret key passed to vl_keykit_kak1_unwrap is read during the call only and
 * stays the caller's to wipe; a key that never leaves its hardware uses vl_keykit_kak1_unwrap_with and a callback.
 *
 * Ownership. Handles returned through an `out` pointer belong to the caller and are released with their own free
 * function (vl_keykit_seed_free, vl_keykit_vault_key_free, vl_keykit_credential_key_free, vl_keykit_credential_free);
 * freeing NULL does nothing. On failure `*out` is set to NULL.
 *
 * OpenSSL. The first call initializes OpenSSL without reading its configuration file (OPENSSL_INIT_NO_LOAD_CONFIG),
 * so no openssl.cnf or OPENSSL_CONF on the machine can load providers into a process that embeds this library.
 *
 * Thread safety. The library has no mutable global state of its own. Every function may be called from any thread, concurrently.
 * A handle is immutable after it is created, so one handle may be read by several threads at once; freeing it must not
 * race with any other use of it. A callback runs synchronously on the calling thread, before the function returns.
 */

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- Sizes ------------------------------------------------------------------------------------------------------- */

#define VL_KEYKIT_SEED_TEXT_SIZE 27        /* the recovery code: 27 Crockford base32 symbols, the last a check */
#define VL_KEYKIT_PUBLIC_KEY_SIZE 32       /* X25519 or Ed25519 */
#define VL_KEYKIT_P256_POINT_SIZE 65       /* uncompressed SEC1 point */
#define VL_KEYKIT_SIGNATURE_SIZE 64        /* Ed25519 */
#define VL_KEYKIT_FINGERPRINT_SIZE 16
#define VL_KEYKIT_FINGERPRINT_TEXT_SIZE 39 /* xxxx-xxxx-xxxx-xxxx-xxxx-xxxx-xxxx-xxxx */
#define VL_KEYKIT_DIGEST_SIZE 32           /* SHA-256: recipient ids, policy hashes */
#define VL_KEYKIT_UID_SIZE 16              /* a vault uid's bytes */
#define VL_KEYKIT_PUBLIC_ID_SIZE 16        /* an account public id's bytes */
#define VL_KEYKIT_SHARED_SECRET_SIZE 32    /* Z: the X25519 output or the P-256 x-coordinate */
#define VL_KEYKIT_CODE_TEXT_SIZE 19        /* a request, transfer or restore code: xxxx-xxxx-xxxx-xxxx */
#define VL_KEYKIT_STATEMENT_MAX_SIZE 256   /* a key statement's text */
#define VL_KEYKIT_POLICY_MAX_SIZE 18432    /* a recovery policy's text with 64 recipients */
#define VL_KEYKIT_POLICY_MAX_RECIPIENTS 64
#define VL_KEYKIT_LABEL_MAX_SIZE 128       /* a vault name, in bytes of UTF-8 */
#define VL_KEYKIT_LABEL_SEALED_SIZE 240
#define VL_KEYKIT_KAK1_MAX_SIZE 179        /* 146 for X25519, 179 for P-256 */
#define VL_KEYKIT_KEV1_MAX_SIZE 183        /* 150 for X25519, 183 for P-256 */
#define VL_KEYKIT_CREDENTIAL_SECRET_MAX_SIZE 1024 /* a storage credential's secret: 1-1024 bytes */
#define VL_KEYKIT_CREDENTIAL_KEY_ID_MAX_SIZE 128  /* its key id: 1-128 printable ASCII characters */
#define VL_KEYKIT_CREDENTIAL_SEALED_MAX_SIZE 1084 /* 44 + secret + 16 */

/* ---- Status codes ------------------------------------------------------------------------------------------------ */

typedef int32_t vl_keykit_status;

enum {
    VL_KEYKIT_OK = 0,
    VL_KEYKIT_ERR_INVALID_ARGUMENT = 1, /* a NULL or ill-sized argument, or an input the writer refuses */
    VL_KEYKIT_ERR_BUFFER_TOO_SMALL = 2, /* `*out_len` holds the length needed */
    VL_KEYKIT_ERR_OUT_OF_MEMORY = 3,
    VL_KEYKIT_ERR_INTERNAL = 4,         /* an unexpected failure (OpenSSL, the CSPRNG) */
    VL_KEYKIT_ERR_AGREEMENT_FAILED = 5, /* the vl_keykit_agree_fn callback returned non-zero */
    VL_KEYKIT_ERR_BAD_FORMAT = 6,       /* fingerprint text or a public id that doesn't parse */
    VL_KEYKIT_ERR_SEED_MISMATCH = 7,    /* the seed is not the key of this statement */

    /* The recovery code (seed.hpp) */
    VL_KEYKIT_ERR_SEED_BAD_LENGTH = 100,
    VL_KEYKIT_ERR_SEED_BAD_SYMBOL = 101,
    VL_KEYKIT_ERR_SEED_BAD_CHECK = 102,

    /* The key statement, chain and pin (account_key.hpp), the recovery policy (recovery_policy.hpp) and the holder
       proof (holder_proof.hpp): 200 + account::ErrorCode */
    VL_KEYKIT_ERR_ACCOUNT_UNSUPPORTED_VERSION = 200,
    VL_KEYKIT_ERR_ACCOUNT_BAD_STATEMENT = 201,
    VL_KEYKIT_ERR_ACCOUNT_BAD_PUBLIC_ID = 202,
    VL_KEYKIT_ERR_ACCOUNT_BAD_GENERATION = 203,
    VL_KEYKIT_ERR_ACCOUNT_BAD_BASE64URL = 204,
    VL_KEYKIT_ERR_ACCOUNT_BAD_KEY = 205,
    VL_KEYKIT_ERR_ACCOUNT_BAD_PREVIOUS = 206,
    VL_KEYKIT_ERR_ACCOUNT_BAD_REASON = 207,
    VL_KEYKIT_ERR_ACCOUNT_ACCOUNT_MISMATCH = 208,
    VL_KEYKIT_ERR_ACCOUNT_GENERATION_GAP = 209,
    VL_KEYKIT_ERR_ACCOUNT_BAD_SIGNATURE = 210,
    VL_KEYKIT_ERR_ACCOUNT_PREVIOUS_MISMATCH = 211,
    VL_KEYKIT_ERR_ACCOUNT_BAD_PREVIOUS_SIGNATURE = 212,
    VL_KEYKIT_ERR_ACCOUNT_ROLLBACK = 213,
    VL_KEYKIT_ERR_ACCOUNT_PIN_MISMATCH = 214,
    VL_KEYKIT_ERR_ACCOUNT_BAD_POLICY = 215,
    VL_KEYKIT_ERR_ACCOUNT_BAD_SEQUENCE = 216,
    VL_KEYKIT_ERR_ACCOUNT_BAD_ISSUED_AT = 217,
    VL_KEYKIT_ERR_ACCOUNT_BAD_RECIPIENT = 218,
    VL_KEYKIT_ERR_ACCOUNT_RECIPIENT_ID_MISMATCH = 219,
    VL_KEYKIT_ERR_ACCOUNT_UNSUPPORTED_SUITE = 220,
    VL_KEYKIT_ERR_ACCOUNT_UNSUPPORTED_CLASS = 221,
    VL_KEYKIT_ERR_ACCOUNT_BAD_LABEL = 222,
    VL_KEYKIT_ERR_ACCOUNT_UNSUPPORTED_SCOPE = 223,
    VL_KEYKIT_ERR_ACCOUNT_UNSORTED_RECIPIENTS = 224,
    VL_KEYKIT_ERR_ACCOUNT_TOO_MANY_RECIPIENTS = 225,
    VL_KEYKIT_ERR_ACCOUNT_GENERATION_MISMATCH = 226,
    VL_KEYKIT_ERR_ACCOUNT_ACCOUNT_KEY_LISTED = 227,
    VL_KEYKIT_ERR_ACCOUNT_BAD_INSTALLATION_ID = 228,

    /* KEV1 envelopes (kev1.hpp): 300 + kev1::ErrorCode */
    VL_KEYKIT_ERR_KEV1_BAD_MAGIC = 300,
    VL_KEYKIT_ERR_KEV1_UNSUPPORTED_VERSION = 301,
    VL_KEYKIT_ERR_KEV1_UNSUPPORTED_SUITE = 302,
    VL_KEYKIT_ERR_KEV1_BAD_PURPOSE = 303,
    VL_KEYKIT_ERR_KEV1_UNSUPPORTED_RECIPIENT_CLASS = 304,
    VL_KEYKIT_ERR_KEV1_RESERVED_NONZERO = 305,
    VL_KEYKIT_ERR_KEV1_VAULT_MISMATCH = 306,
    VL_KEYKIT_ERR_KEV1_RECIPIENT_MISMATCH = 307,
    VL_KEYKIT_ERR_KEV1_BAD_LENGTH = 308,
    VL_KEYKIT_ERR_KEV1_BAD_EPHEMERAL = 309,
    VL_KEYKIT_ERR_KEV1_WRAP_AUTH_FAILED = 310,
    VL_KEYKIT_ERR_KEV1_BAD_KEY_VERSION = 311,

    /* KAK1 (kak1.hpp): 400 + kak1::ErrorCode */
    VL_KEYKIT_ERR_KAK1_BAD_MAGIC = 400,
    VL_KEYKIT_ERR_KAK1_UNSUPPORTED_VERSION = 401,
    VL_KEYKIT_ERR_KAK1_UNSUPPORTED_SUITE = 402,
    VL_KEYKIT_ERR_KAK1_ACCOUNT_MISMATCH = 403,
    VL_KEYKIT_ERR_KAK1_KEY_MISMATCH = 404,
    VL_KEYKIT_ERR_KAK1_RECIPIENT_MISMATCH = 405,
    VL_KEYKIT_ERR_KAK1_BAD_LENGTH = 406,
    VL_KEYKIT_ERR_KAK1_BAD_EPHEMERAL = 407,
    VL_KEYKIT_ERR_KAK1_WRAP_AUTH_FAILED = 408,
    VL_KEYKIT_ERR_KAK1_SEED_MISMATCH = 409,

    /* Sealed vault labels (vault_label.hpp): 500 + label::ErrorCode */
    VL_KEYKIT_ERR_LABEL_BAD_MAGIC = 500,
    VL_KEYKIT_ERR_LABEL_UNSUPPORTED_VERSION = 501,
    VL_KEYKIT_ERR_LABEL_UNSUPPORTED_SUITE = 502,
    VL_KEYKIT_ERR_LABEL_ACCOUNT_MISMATCH = 503,
    VL_KEYKIT_ERR_LABEL_VAULT_MISMATCH = 504,
    VL_KEYKIT_ERR_LABEL_KEY_MISMATCH = 505,
    VL_KEYKIT_ERR_LABEL_BAD_LENGTH = 506,
    VL_KEYKIT_ERR_LABEL_BAD_EPHEMERAL = 507,
    VL_KEYKIT_ERR_LABEL_AUTH_FAILED = 508,
    VL_KEYKIT_ERR_LABEL_BAD_LABEL = 509,

    /* Sealed storage credentials (storage_credential.hpp): 600 + credential::ErrorCode */
    VL_KEYKIT_ERR_CREDENTIAL_BAD_MAGIC = 600,
    VL_KEYKIT_ERR_CREDENTIAL_UNSUPPORTED_VERSION = 601,
    VL_KEYKIT_ERR_CREDENTIAL_UNSUPPORTED_SUITE = 602,
    VL_KEYKIT_ERR_CREDENTIAL_BAD_LENGTH = 603,
    VL_KEYKIT_ERR_CREDENTIAL_BAD_EPHEMERAL = 604,
    VL_KEYKIT_ERR_CREDENTIAL_AUTH_FAILED = 605
};

/* The status's stable name ("ok", "kak1_wrap_auth_failed"); "unknown" for a value this version doesn't define. Never
   NULL; the string is static. */
const char* vl_keykit_status_name(vl_keykit_status status);

/* The library's version ("0.4.0"), static. */
const char* vl_keykit_version(void);

/* ---- Enumerations ------------------------------------------------------------------------------------------------ */

enum {
    VL_KEYKIT_SUITE_X25519 = 1, /* X25519 + HKDF-SHA-256 + AES-256-GCM */
    VL_KEYKIT_SUITE_P256 = 2    /* P-256 ECDH (a Secure Enclave key) + HKDF-SHA-256 + AES-256-GCM */
};

enum { VL_KEYKIT_REASON_INITIAL = 0, VL_KEYKIT_REASON_ROUTINE = 1, VL_KEYKIT_REASON_COMPROMISE = 2 };

enum { VL_KEYKIT_LINK_INITIAL = 0, VL_KEYKIT_LINK_ROTATION = 1, VL_KEYKIT_LINK_REPLACEMENT = 2 };

/* ---- The account key: a recovery seed in a handle ---------------------------------------------------------------- */

typedef struct vl_keykit_seed vl_keykit_seed;

/* Creates a new account key: 16 bytes from OpenSSL's private CSPRNG. */
vl_keykit_status vl_keykit_seed_generate(vl_keykit_seed** out);

/* Parses a recovery code as a person types it: whitespace and '-' are ignored, letters may be upper case. Statuses:
   VL_KEYKIT_ERR_SEED_BAD_LENGTH, _BAD_SYMBOL, _BAD_CHECK. */
vl_keykit_status vl_keykit_seed_parse(const char* text, size_t text_len, vl_keykit_seed** out);

/* Exports the recovery code: 27 lower-case symbols, ungrouped (VL_KEYKIT_SEED_TEXT_SIZE). The only way the seed leaves
   a handle; the caller wipes the buffer when it is done showing or saving it. */
vl_keykit_status vl_keykit_seed_export_text(const vl_keykit_seed* seed, char* out, size_t* out_len);

/* The seed's X25519 recipient public key and Ed25519 signing public key; either output may be NULL. */
vl_keykit_status vl_keykit_seed_public_keys(const vl_keykit_seed* seed, uint8_t x25519_public[32],
                                            uint8_t ed25519_public[32]);

/* VL_KEYKIT_OK when the seed is the key of `statement` (a recovery code typed in, checked against the statement from
   GET /v1/keys/account), VL_KEYKIT_ERR_SEED_MISMATCH when it isn't, or the statement's parse status. */
vl_keykit_status vl_keykit_seed_matches(const vl_keykit_seed* seed, const char* statement, size_t statement_len);

/* Zeroes and frees the seed. NULL does nothing. */
void vl_keykit_seed_free(vl_keykit_seed* seed);

/* ---- Key statements, fingerprints, the chain and a pin (account_key.hpp) ----------------------------------------- */

/* The canonical statement of `seed` as generation `generation` of the account `public_id` (canonical UUID text).
   Generation 1 takes previous_fingerprint NULL and VL_KEYKIT_REASON_INITIAL; later ones the previous generation's
   fingerprint and _ROUTINE or _COMPROMISE. Output up to VL_KEYKIT_STATEMENT_MAX_SIZE bytes. */
vl_keykit_status vl_keykit_statement_build(const vl_keykit_seed* seed, const char* public_id, size_t public_id_len,
                                           uint32_t generation, const uint8_t* previous_fingerprint, int32_t reason,
                                           char* out, size_t* out_len);

/* Signs a statement with its own key `seed` and, for a rotation, with the previous generation's key `previous` (NULL
   for generation 1 and for a replacement). `previous_signature` is written when `previous` is given and may be NULL
   otherwise. VL_KEYKIT_ERR_SEED_MISMATCH when a seed isn't the statement's (or the previous generation's) key. */
vl_keykit_status vl_keykit_statement_sign(const char* statement, size_t statement_len, const vl_keykit_seed* seed,
                                          const vl_keykit_seed* previous, uint8_t signature[64],
                                          uint8_t previous_signature[64]);

typedef struct vl_keykit_statement_info {
    uint8_t public_id[16];
    uint32_t generation;
    int32_t reason; /* VL_KEYKIT_REASON_* */
    uint8_t x25519_public[32];
    uint8_t ed25519_public[32];
    int32_t has_previous; /* 1 from generation 2 */
    uint8_t previous_fingerprint[16];
    uint8_t fingerprint[16]; /* this generation's */
} vl_keykit_statement_info;

/* Parses a statement strictly (account_* statuses in the header's order) and gives its fields and fingerprint. */
vl_keykit_status vl_keykit_statement_parse(const char* statement, size_t statement_len, vl_keykit_statement_info* out);

/* The fingerprint's text (VL_KEYKIT_FINGERPRINT_TEXT_SIZE characters). */
vl_keykit_status vl_keykit_fingerprint_text(const uint8_t fingerprint[16], char* out, size_t* out_len);

/* Parses fingerprint text: the canonical form only, or with `lenient` non-zero also what a person types (upper case,
   and '-', ' ' or nothing between groups). VL_KEYKIT_ERR_BAD_FORMAT otherwise. */
vl_keykit_status vl_keykit_fingerprint_parse(const char* text, size_t text_len, int32_t lenient,
                                             uint8_t fingerprint[16]);

/* The account public id's 16 bytes (canonical UUID text only; VL_KEYKIT_ERR_BAD_FORMAT otherwise). */
vl_keykit_status vl_keykit_public_id_bytes(const char* public_id, size_t public_id_len, uint8_t out[16]);

typedef struct vl_keykit_signed_statement {
    const char* statement;
    size_t statement_len;
    const uint8_t* signature;          /* 64 bytes */
    const uint8_t* previous_signature; /* 64 bytes, or NULL when the generation has none */
} vl_keykit_signed_statement;

typedef struct vl_keykit_generation {
    uint32_t generation;
    int32_t reason; /* VL_KEYKIT_REASON_* */
    int32_t link;   /* VL_KEYKIT_LINK_*: what the chain check found */
    uint8_t fingerprint[16];
    uint8_t x25519_public[32];
    uint8_t ed25519_public[32];
} vl_keykit_generation;

/* Verifies the whole chain as the cloud serves it, generation 1 first, for the account `public_id`. On VL_KEYKIT_OK,
   `out` (may be NULL; otherwise `count` entries) receives each generation. On an account_* status, `failed_index` (may
   be NULL) is the chain position that failed; SIZE_MAX when no position applies. */
vl_keykit_status vl_keykit_chain_verify(const vl_keykit_signed_statement* chain, size_t count, const char* public_id,
                                        size_t public_id_len, vl_keykit_generation* out, size_t* failed_index);

/* Verifies the chain and follows it from a pin (the generation and fingerprint a person confirmed): `accepted` is the
   highest generation reached through signed rotations only, `newest` the chain's last. accepted < newest means
   generation accepted + 1 is a replacement waiting for a person to confirm the newest fingerprint. Statuses: those of
   vl_keykit_chain_verify, VL_KEYKIT_ERR_ACCOUNT_ROLLBACK and _PIN_MISMATCH. */
vl_keykit_status vl_keykit_chain_follow(const vl_keykit_signed_statement* chain, size_t count, const char* public_id,
                                        size_t public_id_len, uint32_t pin_generation,
                                        const uint8_t pin_fingerprint[16], uint32_t* accepted, uint32_t* newest);

/* ---- Holder proofs (holder_proof.hpp) ---------------------------------------------------------------------------- */

/* The proof for POST /v1/keys/holders: the account key `seed` of the generation `statement` signs this installation
   (26 base32 symbols) and its holder public key (VL_KEYKIT_SUITE_X25519: 32 bytes; _P256: the 65-byte point, e.g. a
   Secure Enclave key's). Statuses: VL_KEYKIT_ERR_ACCOUNT_BAD_INSTALLATION_ID, _UNSUPPORTED_SUITE, _BAD_KEY,
   VL_KEYKIT_ERR_SEED_MISMATCH. */
vl_keykit_status vl_keykit_holder_proof_sign(const char* statement, size_t statement_len, const vl_keykit_seed* seed,
                                             const char* installation_id, size_t installation_id_len, uint16_t suite,
                                             const uint8_t* holder_public_key, size_t holder_public_key_len,
                                             uint8_t proof[64]);

/* VL_KEYKIT_OK when `proof` is the statement's key signing that holder, or the first check that fails (as above, then
   VL_KEYKIT_ERR_ACCOUNT_BAD_SIGNATURE). */
vl_keykit_status vl_keykit_holder_proof_verify(const char* statement, size_t statement_len,
                                               const char* installation_id, size_t installation_id_len,
                                               uint16_t suite, const uint8_t* holder_public_key,
                                               size_t holder_public_key_len, const uint8_t proof[64]);

/* ---- KAK1: the account key wrapped to a holder (kak1.hpp) -------------------------------------------------------- */

/* Wraps the account key `seed` of generation `statement` to a holder or transfer key of `suite`. Output 146 (X25519)
   or 179 (P-256) bytes; the ephemeral key is fresh. VL_KEYKIT_ERR_SEED_MISMATCH when the seed isn't the statement's,
   VL_KEYKIT_ERR_INVALID_ARGUMENT for a key that isn't valid for its suite. */
vl_keykit_status vl_keykit_kak1_wrap(const vl_keykit_seed* seed, const char* statement, size_t statement_len,
                                     uint16_t suite, const uint8_t* holder_public_key, size_t holder_public_key_len,
                                     uint8_t* out, size_t* out_len);

/* Unwraps with a holder secret key in memory (X25519: 32 bytes; P-256: the 32-byte scalar), expecting `suite` and the
   generation `statement`. kak1_* statuses in the format's order. */
vl_keykit_status vl_keykit_kak1_unwrap(const uint8_t* envelope, size_t envelope_len,
                                       const uint8_t* holder_secret_key, size_t holder_secret_key_len,
                                       uint16_t suite, const char* statement, size_t statement_len,
                                       vl_keykit_seed** out);

/* The key agreement of a holder key that never leaves its hardware (a Secure Enclave P-256 key): Z of the holder key
   with `ephemeral_public_key` (32 bytes for X25519, the 65-byte point for P-256), written to `shared_secret` (32
   bytes: the X25519 output or the P-256 x-coordinate). Return 0 on success, anything else to refuse (the user
   cancelled, the key is gone): the unwrap then fails with VL_KEYKIT_ERR_AGREEMENT_FAILED. Called at most once per
   unwrap, synchronously, after the envelope's structure, account, generation and recipient have been checked and only
   with a point valid for the suite. `shared_secret` is the library's and is zeroed after use. */
typedef int (*vl_keykit_agree_fn)(void* context, const uint8_t* ephemeral_public_key, size_t ephemeral_public_key_len,
                                  uint8_t shared_secret[32]);

/* The same reader as vl_keykit_kak1_unwrap for a key in hardware: `holder_public_key` is its public key, `agree` its
   agreement and `context` passed through unchanged. An all-zero Z is VL_KEYKIT_ERR_KAK1_BAD_EPHEMERAL. */
vl_keykit_status vl_keykit_kak1_unwrap_with(const uint8_t* envelope, size_t envelope_len,
                                            const uint8_t* holder_public_key, size_t holder_public_key_len,
                                            uint16_t suite, const char* statement, size_t statement_len,
                                            vl_keykit_agree_fn agree, void* context, vl_keykit_seed** out);

typedef struct vl_keykit_kak1_header {
    uint16_t suite;
    uint32_t generation;
    uint8_t public_id[16];
    uint8_t fingerprint[16];
    uint8_t recipient_id[32];
} vl_keykit_kak1_header;

/* The envelope's prefix, read without a key and authenticating nothing (magic, version, suite and length checked). */
vl_keykit_status vl_keykit_kak1_inspect(const uint8_t* envelope, size_t envelope_len, vl_keykit_kak1_header* out);

/* ---- Sealed vault labels (vault_label.hpp) ----------------------------------------------------------------------- */

/* Seals a vault's name (1-128 bytes of UTF-8 without control characters) for `vault_uid` to the account key of
   `statement`. Output VL_KEYKIT_LABEL_SEALED_SIZE bytes. */
vl_keykit_status vl_keykit_label_seal(const char* name, size_t name_len, const char* statement, size_t statement_len,
                                      const uint8_t vault_uid[16], uint8_t* out, size_t* out_len);

/* Opens a sealed label with the account key `seed` of generation `statement`; the name, up to
   VL_KEYKIT_LABEL_MAX_SIZE bytes of UTF-8. label_* statuses in the format's order. */
vl_keykit_status vl_keykit_label_open(const uint8_t* sealed, size_t sealed_len, const vl_keykit_seed* seed,
                                      const char* statement, size_t statement_len, const uint8_t vault_uid[16],
                                      char* name, size_t* name_len);

/* ---- The account's recovery policy (recovery_policy.hpp) --------------------------------------------------------- */

typedef struct vl_keykit_policy_recipient {
    const uint8_t* x25519_public; /* 32 bytes */
    const char* label;            /* 1-128 bytes of UTF-8 without control characters */
    size_t label_len;
} vl_keykit_policy_recipient;

/* Builds and signs the next policy with the account key `seed` of the current generation `statement` (whose account
   and generation the policy names): `sequence` (the stored one plus one), `issued_at` ("YYYY-MM-DDTHH:MM:SSZ") and
   0-64 recipients in any order (written sorted). The policy text goes to `policy` (up to VL_KEYKIT_POLICY_MAX_SIZE
   bytes) and its signature to `signature`; on BUFFER_TOO_SMALL neither is written. */
vl_keykit_status vl_keykit_policy_sign(const vl_keykit_seed* seed, const char* statement, size_t statement_len,
                                       uint32_t sequence, const char* issued_at, size_t issued_at_len,
                                       const vl_keykit_policy_recipient* recipients, size_t recipient_count,
                                       char* policy, size_t* policy_len, uint8_t signature[64]);

typedef struct vl_keykit_policy_info {
    uint32_t sequence;
    uint32_t generation;
    uint32_t recipient_count;
    uint8_t hash[32]; /* SHA-256 of the policy's bytes */
} vl_keykit_policy_info;

/* Verifies a signed policy against the pinned generation `statement`: account_* statuses (parse errors, then
   _ACCOUNT_MISMATCH, _GENERATION_MISMATCH, _BAD_SIGNATURE, _ACCOUNT_KEY_LISTED). The sequence floor is the caller's. */
vl_keykit_status vl_keykit_policy_verify(const char* policy, size_t policy_len, const uint8_t signature[64],
                                         const char* statement, size_t statement_len, vl_keykit_policy_info* out);

/* Recipient `index` (in the policy's order) of a policy that parses: its X25519 key and label (up to
   VL_KEYKIT_LABEL_MAX_SIZE bytes). VL_KEYKIT_ERR_INVALID_ARGUMENT for an index past the last. */
vl_keykit_status vl_keykit_policy_recipient_at(const char* policy, size_t policy_len, size_t index,
                                               uint8_t x25519_public[32], char* label, size_t* label_len);

/* ---- KEV1 envelopes and vault keys: delivering a restore (kev1.hpp) ---------------------------------------------- */

typedef struct vl_keykit_vault_key vl_keykit_vault_key;

/* Opens a KEV1 envelope addressed to the account key's X25519 recipient (suite 1) for `vault_uid`. The vault key
   stays in the handle, with its key version and vault. kev1_* statuses in the format's order;
   vl_keykit_kev1_skipped_by_restore tells which a restore passes over. */
vl_keykit_status vl_keykit_kev1_unwrap(const uint8_t* envelope, size_t envelope_len, const vl_keykit_seed* seed,
                                       const uint8_t vault_uid[16], vl_keykit_vault_key** out);

/* Wraps the vault key again, under its own key version and vault, to `recipient_public_key` of `suite` (a restore's
   temporary key). Output 150 (X25519) or 183 (P-256) bytes; the ephemeral key is fresh. */
vl_keykit_status vl_keykit_kev1_wrap(const vl_keykit_vault_key* key, uint16_t suite,
                                     const uint8_t* recipient_public_key, size_t recipient_public_key_len,
                                     uint8_t* out, size_t* out_len);

/* The key version of the vault key (0 for NULL). */
uint32_t vl_keykit_vault_key_version(const vl_keykit_vault_key* key);

/* Zeroes and frees the vault key. NULL does nothing. */
void vl_keykit_vault_key_free(vl_keykit_vault_key* key);

typedef struct vl_keykit_kev1_header {
    uint16_t suite;
    uint8_t purpose;
    uint8_t recipient_class;
    uint32_t key_version;
    uint8_t vault_uid[16];
    uint8_t recipient_id[32];
} vl_keykit_kev1_header;

/* The envelope's prefix, read without a key and authenticating nothing. */
vl_keykit_status vl_keykit_kev1_inspect(const uint8_t* envelope, size_t envelope_len, vl_keykit_kev1_header* out);

/* Non-zero for the statuses a restore skips without failing (another recipient's envelope, a reserved purpose or
   recipient class). */
int32_t vl_keykit_kev1_skipped_by_restore(vl_keykit_status status);

/* SHA-256 of a public key: the recipient_id KEV1 and KAK1 envelopes carry. */
vl_keykit_status vl_keykit_recipient_id(const uint8_t* public_key, size_t public_key_len, uint8_t out[32]);

/* ---- Comparison codes (key_codes.hpp) ---------------------------------------------------------------------------- */

/* Each writes VL_KEYKIT_CODE_TEXT_SIZE characters. VL_KEYKIT_ERR_INVALID_ARGUMENT for an input key_codes.hpp refuses. */

/* A key request's code: its id (26 base32 symbols) and the payload text exactly as sent. */
vl_keykit_status vl_keykit_request_code(const char* request_id, size_t request_id_len, const char* payload,
                                        size_t payload_len, char* out, size_t* out_len);

/* A transfer's code: the account public id and the new device's temporary public key (32 or 65 bytes). */
vl_keykit_status vl_keykit_transfer_code(const char* public_id, size_t public_id_len, const uint8_t* temporary_key,
                                         size_t temporary_key_len, char* out, size_t* out_len);

/* A restore's code: the vault uid text and the receiving installation's temporary X25519 key. */
vl_keykit_status vl_keykit_restore_code(const char* vault_uid, size_t vault_uid_len, const uint8_t* temporary_key,
                                        size_t temporary_key_len, char* out, size_t* out_len);

/* ---- Sealed storage credentials: a managed bucket's key (storage_credential.hpp) --------------------------------- */

/*
 * The exchange a Mac (or a server) runs for a managed bucket's application key: make a one-time X25519 key, send its
 * public key to POST /v1/storage/vaults/{uid}/credentials, open the `sealed_secret` of the answer (base64url-decoded)
 * with that key, bound to this installation's id, the vault and the answer's `key_id`, then free the one-time key.
 * The opened secret stays in its handle; read it into a buffer only to use it at once (a request signature) and wipe
 * that buffer afterwards.
 */

typedef struct vl_keykit_credential_key vl_keykit_credential_key;

/* A new one-time X25519 key pair: 32 bytes from OpenSSL's private CSPRNG. */
vl_keykit_status vl_keykit_credential_key_generate(vl_keykit_credential_key** out);

/* The key pair of a 32-byte X25519 secret key the caller already holds (the vectors; a key kept elsewhere). The
   caller's bytes are copied into the handle and stay the caller's to wipe. */
vl_keykit_status vl_keykit_credential_key_from_secret(const uint8_t secret_key[32], vl_keykit_credential_key** out);

/* The key's X25519 public key: the `public_key` the request sends (base64url). */
vl_keykit_status vl_keykit_credential_key_public(const vl_keykit_credential_key* key, uint8_t public_key[32]);

/* Zeroes and frees the key. NULL does nothing. */
void vl_keykit_credential_key_free(vl_keykit_credential_key* key);

typedef struct vl_keykit_credential vl_keykit_credential;

/* Opens a sealed credential with the one-time key, bound to `installation_id` (this installation's 26 base32
   symbols), `vault_uid` and `key_id` (1-128 printable ASCII characters): any other binding fails authentication.
   VL_KEYKIT_ERR_INVALID_ARGUMENT for a binding outside those ranges; otherwise credential_* statuses in the format's
   order (bad_magic, unsupported_version, unsupported_suite, bad_length, bad_ephemeral, auth_failed). */
vl_keykit_status vl_keykit_credential_open(const uint8_t* sealed, size_t sealed_len, const vl_keykit_credential_key* key,
                                           const char* installation_id, size_t installation_id_len,
                                           const uint8_t vault_uid[16], const char* key_id, size_t key_id_len,
                                           vl_keykit_credential** out);

/* Copies the opened secret (1 to VL_KEYKIT_CREDENTIAL_SECRET_MAX_SIZE bytes) into the caller's buffer, by the length
   in/out convention (out NULL with *out_len 0 asks its length). The only way the secret leaves its handle. */
vl_keykit_status vl_keykit_credential_secret(const vl_keykit_credential* credential, uint8_t* out, size_t* out_len);

/* Zeroes and frees the opened credential. NULL does nothing. */
void vl_keykit_credential_free(vl_keykit_credential* credential);

/* The cloud's side, for test doubles and tools (a client never seals): seals `secret` (1-1024 bytes) under the same
   binding to `public_key` with a fresh ephemeral key. Output 44 + secret_len + 16 bytes, at most
   VL_KEYKIT_CREDENTIAL_SEALED_MAX_SIZE. VL_KEYKIT_ERR_INVALID_ARGUMENT for a secret, binding or key it refuses,
   VL_KEYKIT_ERR_CREDENTIAL_BAD_EPHEMERAL for a public key of low order. */
vl_keykit_status vl_keykit_credential_seal(const uint8_t* secret, size_t secret_len, const char* installation_id,
                                           size_t installation_id_len, const uint8_t vault_uid[16], const char* key_id,
                                           size_t key_id_len, const uint8_t public_key[32], uint8_t* out,
                                           size_t* out_len);

#ifdef __cplusplus
}
#endif

#endif
